# Factory Information

Factory Version

2.2.0

Factory Reference

main

Factory Commit

913ad02f6632f0eacadd9bb2b121af3d82e20160

Bootstrapped On

2026-09-01T00:42:07Z

Factory Repository

git@github.com:AdiShrestha/software-factory.git

Bootstrap Command

bootstrap.sh 
