# FlowGate Legacy Intake: Migration Staging

**Captured Date:** 2026-09-01
**Contract ID:** C01-03
**Target Contract:** C01-04 (Authoritative Source Scaffold and Migration)

---

## 1. Core Source Staging Matrix

The following legacy source files are approved for migration to `source/src/load_adaptive_iir/` under Contract C01-04. Behaviour must be preserved initially, with known semantic defects explicitly tagged with comments (`# KNOWN DEFECT [CHUNK-04]: ...`) and repaired only in subsequent chunks.

| Legacy Source Path | Authoritative Destination | Target Subsystem | SHA-256 (Source) | Known Defects / Migration Directives |
|---|---|---|---|---|
| `load-adaptive-iir/src/filters.py` | `source/src/load_adaptive_iir/core/filters.py` | Core DSP | `2afa89b2853426d18925dff66f77f160b81b628c2dd7acada2a0b42867a68a68` | 1. Zero-state vs warm-start initial condition semantics undefined.<br>2. Fixed EMA alpha parameter confusing pole vs smoothing constant.<br>3. Butterworth uses arbitrary `fs=100.0Hz` without timebase justification.<br>4. KAMA first-update warm-up missing.<br>5. Preserve behavior; mark defects. |
| `load-adaptive-iir/src/numba_filters.py` | `source/src/load_adaptive_iir/core/numba_filters.py` | Core DSP (Optimised) | `8e45a70f39e86e401e3d5cde35c793566f79f0f3111f194502a35ac0a43bc2a0` | 1. Dependency unpinned (requires NumPy <=2.4 on Numba 0.60).<br>2. Add optional import guard; migrate for parity verification in Chunk 04. |
| `load-adaptive-iir/src/zdomain_analysis.py` | `source/src/load_adaptive_iir/core/zdomain.py` | Core Analytical | `4dc438dffa5e30f67c6f10cabecb980fc9e1fdae37b0799851997a5f06b80d81` | 1. Frozen-time pole claims presented as time-varying global stability proofs.<br>2. Remove import-time matplotlib side effects.<br>3. Migrate pure mathematical analysis functions. |
| `load-adaptive-iir/src/load_shedding.py` | `source/src/load_adaptive_iir/runtime/shedding.py` | Runtime Shedding | `b56f34a8e66716b0fca3ef786290b5c644bcd88735396f84971df45119c922b3` | 1. Shedding policy logic to be decoupled from synthetic load generation.<br>2. Re-anchor to measured telemetry in Chunk 05. |
| `load-adaptive-iir/src/visualize.py` | `source/src/load_adaptive_iir/reporting/figures.py` | Reporting | `1792bd8a2d3a49026c1f0d2760ff2b0f590eeb9f4046e0bebc86762b1df6360e` | 1. Remove hardcoded paths and legacy result plotting.<br>2. Refactor as pure artifact-consuming plotting utility in Chunk 11. |

---

## 2. Test Suite Staging Matrix

| Legacy Test Path | Proposed Categorised Destination | Test Class | Migration Notes |
|---|---|---|---|
| `load-adaptive-iir/tests/test_filters.py` | `source/tests/unit/test_filters.py` | Unit | Update imports; retain deterministic filter response checks. |
| `load-adaptive-iir/tests/test_numba_equivalence.py` | `source/tests/unit/test_numba_equivalence.py` | Unit | Guard with numba import check. |
| `load-adaptive-iir/tests/test_filter_stability.py` | `source/tests/semantic/test_filter_stability.py` | Semantic | Retain analytical pole & impulse bounds. |
| `load-adaptive-iir/tests/test_shedding.py` | `source/tests/unit/test_shedding.py` | Unit | Retain record dropping logic tests. |
| `load-adaptive-iir/tests/test_zdomain.py` | `source/tests/semantic/test_zdomain.py` | Semantic | Retain z-transform calculations. |
| `load-adaptive-iir/tests/test_statistical_tests.py` | `source/tests/scientific/test_statistical_tests.py` | Scientific | Mark precision loss / identical-array tests with xfail pending Chunk 06 protocol. |
| `load-adaptive-iir/tests/test_bandwidth_calibration.py` | `source/tests/scientific/test_bandwidth_calibration.py` | Scientific | Remove network download dependency; mark xfail. |
| `load-adaptive-iir/tests/test_harness.py` | `source/tests/integration/test_harness.py` | Integration | Refactor to mock authentic replay. |
| `load-adaptive-iir/tests/test_detection.py` | `source/tests/scientific/test_detection.py` | Scientific | Mark xfail pending Chunk 02 real-label feasibility. |
| `load-adaptive-iir/tests/test_anomaly_injection.py` | `source/tests/scientific/test_anomaly_injection.py` | Retired / Invalid | Synthetic injection test — candidate for retirement in C01-07. |
| `load-adaptive-iir/tests/test_queue_stability_sanity.py` | `source/tests/integration/test_queue_stability.py` | Integration | Quarantine from evidence; migrate harness sanity. |
| `load-adaptive-iir/tests/test_downstream.py` | `source/tests/integration/test_downstream.py` | Integration | Pure pipeline flow checks. |
| `load-adaptive-iir/tests/test_data_pipeline.py` | `source/tests/integration/test_data_pipeline.py` | Integration | Update to reflect fail-closed transform interfaces. |
| `load-adaptive-iir/tests/test_delong.py` | `source/tests/unit/test_delong.py` | Unit | Mathematical verification of DeLong matrix algebra. |
