# Legacy Intake Modified File Diffs

| Original File | Diff File | Line Count |
|---|---|---|
| `.DS_Store` | [`_DS_Store.diff`](./_DS_Store.diff) | 3 |
| `.gitignore` | [`_gitignore.diff`](./_gitignore.diff) | 21 |
| `load-adaptive-iir/results/figures/slew_rate_sensitivity.png` | [`load-adaptive-iir_results_figures_slew_rate_sensitivity_png.diff`](./load-adaptive-iir_results_figures_slew_rate_sensitivity_png.diff) | 3 |
| `load-adaptive-iir/results/tables/slew_rate_sensitivity.csv` | [`load-adaptive-iir_results_tables_slew_rate_sensitivity_csv.diff`](./load-adaptive-iir_results_tables_slew_rate_sensitivity_csv.diff) | 14 |
| `load-adaptive-iir/src/__pycache__/delong.cpython-312.pyc` | [`load-adaptive-iir_src___pycache___delong_cpython-312_pyc.diff`](./load-adaptive-iir_src___pycache___delong_cpython-312_pyc.diff) | 3 |
| `load-adaptive-iir/src/__pycache__/fp_paradox.cpython-312.pyc` | [`load-adaptive-iir_src___pycache___fp_paradox_cpython-312_pyc.diff`](./load-adaptive-iir_src___pycache___fp_paradox_cpython-312_pyc.diff) | 3 |
| `load-adaptive-iir/src/__pycache__/numba_filters.apply_shedding_forward_fill_y-214.py312.nbi` | [`load-adaptive-iir_src___pycache___numba_filters_apply_shedding_forward_fill_y-214_py312_nbi.diff`](./load-adaptive-iir_src___pycache___numba_filters_apply_shedding_forward_fill_y-214_py312_nbi.diff) | 3 |
| `load-adaptive-iir/src/__pycache__/numba_filters.compute_kama_sc-187.py312.nbi` | [`load-adaptive-iir_src___pycache___numba_filters_compute_kama_sc-187_py312_nbi.diff`](./load-adaptive-iir_src___pycache___numba_filters_compute_kama_sc-187_py312_nbi.diff) | 3 |
| `load-adaptive-iir/src/__pycache__/numba_filters.compute_load_adaptive_alpha-107.py312.nbi` | [`load-adaptive-iir_src___pycache___numba_filters_compute_load_adaptive_alpha-107_py312_nbi.diff`](./load-adaptive-iir_src___pycache___numba_filters_compute_load_adaptive_alpha-107_py312_nbi.diff) | 3 |
| `load-adaptive-iir/src/__pycache__/numba_filters.compute_processing_mask_kernel-163.py312.nbi` | [`load-adaptive-iir_src___pycache___numba_filters_compute_processing_mask_kernel-163_py312_nbi.diff`](./load-adaptive-iir_src___pycache___numba_filters_compute_processing_mask_kernel-163_py312_nbi.diff) | 3 |
| `load-adaptive-iir/src/__pycache__/numba_filters.fixed_iir_direct_form_ii-20.py312.nbi` | [`load-adaptive-iir_src___pycache___numba_filters_fixed_iir_direct_form_ii-20_py312_nbi.diff`](./load-adaptive-iir_src___pycache___numba_filters_fixed_iir_direct_form_ii-20_py312_nbi.diff) | 3 |
| `load-adaptive-iir/src/__pycache__/numba_filters.time_varying_first_order_ema-74.py312.nbi` | [`load-adaptive-iir_src___pycache___numba_filters_time_varying_first_order_ema-74_py312_nbi.diff`](./load-adaptive-iir_src___pycache___numba_filters_time_varying_first_order_ema-74_py312_nbi.diff) | 3 |
| `load-adaptive-iir/src/__pycache__/statistical_tests.cpython-312.pyc` | [`load-adaptive-iir_src___pycache___statistical_tests_cpython-312_pyc.diff`](./load-adaptive-iir_src___pycache___statistical_tests_cpython-312_pyc.diff) | 3 |
| `load-adaptive-iir/src/fp_paradox.py` | [`load-adaptive-iir_src_fp_paradox_py.diff`](./load-adaptive-iir_src_fp_paradox_py.diff) | 68 |
| `load-adaptive-iir/src/multi_seed_evaluation.py` | [`load-adaptive-iir_src_multi_seed_evaluation_py.diff`](./load-adaptive-iir_src_multi_seed_evaluation_py.diff) | 60 |
| `load-adaptive-iir/src/statistical_tests.py` | [`load-adaptive-iir_src_statistical_tests_py.diff`](./load-adaptive-iir_src_statistical_tests_py.diff) | 98 |
| `load-adaptive-iir/notebooks/01_full_pipeline.ipynb (DELETED)` | [`DELETED_load-adaptive-iir_notebooks_01_full_pipeline_ipynb.diff`](./DELETED_load-adaptive-iir_notebooks_01_full_pipeline_ipynb.diff) | 0 |
