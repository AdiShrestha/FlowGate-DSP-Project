# FlowGate Legacy Intake: Quarantine Index

**Captured Date:** 2026-09-01
**Contract ID:** C01-03
**Owner:** Architect
**Authority Statement:** Every file listed below is preserved strictly for forensic and historical audit purposes. None of these files are authoritative, and no claim, number, or implementation detail in them may enter the authoritative research evidence package without passing through the full Software Factory evidence lifecycle.

---

## Quarantined Assets Inventory

| Original Path | Quarantined Path | Category | Size (B) | SHA-256 Hash | Authority Status | Audit Rationale |
|---|---|---|---|---|---|---|
| `build_mega_context.py` | [`project/legacy_intake/tools/build_mega_context.py`](./tools/build_mega_context.py) | `tools` | 3297 | `4787f063b54caf4129d0fa934ce5bc610242447369b6ceb2ed6f03773fea7cc2` | `LEGACY — NON-AUTHORITATIVE` | One-off context builder; historical tool |
| `dsp_project_build_prompt.md` | [`project/legacy_intake/requirements/dsp_project_build_prompt.md`](./requirements/dsp_project_build_prompt.md) | `requirements` | 23102 | `f0a8b67e2a24de829b391a818605e6da612a2444274b81b50cef0031683e8bf1` | `LEGACY — NON-AUTHORITATIVE` | Historical LLM build prompt and specification |
| `fix1.md` | [`project/legacy_intake/notes/fix1.md`](./notes/fix1.md) | `notes` | 16024 | `0ff10d33a9661647cac3456ccb700bee06f3b5cd3ee27dc604b073cb67b3973b` | `LEGACY — NON-AUTHORITATIVE` | Legacy repair instructions / notes |
| `mega_report_context.md` | [`project/legacy_intake/documents/mega_report_context.md`](./documents/mega_report_context.md) | `documents` | 585107 | `60752d58373e4b54e3a3294bad9d330b50337811ec9caf328c47c6e4fb1176f8` | `LEGACY — NON-AUTHORITATIVE` | Generated context document with stale metrics |
| `project_context.md` | [`project/legacy_intake/documents/project_context.md`](./documents/project_context.md) | `documents` | 5106 | `2247b514fa03157d3d32e094cb5e54bafa54debdd9e3f9e95e387607772a5167` | `LEGACY — NON-AUTHORITATIVE` | Legacy claims and metrics document |
| `study.md` | [`project/legacy_intake/reviews/study.md`](./reviews/study.md) | `reviews` | 52679 | `1c44ac6dd38ab03eec440486a1a257a1ddc6e80dc0d14b8416d04821d306177d` | `LEGACY — NON-AUTHORITATIVE` | Legacy adversarial analysis and suggestions |
| `load_adaptive_iir_literature_review.md` | [`project/legacy_intake/literature/load_adaptive_iir_literature_review.md`](./literature/load_adaptive_iir_literature_review.md) | `literature` | 21323 | `e10b354ec0d9b5baea445716e12d32ffbb83d08736e5a5d8a99f29eee540ecd2` | `LEGACY — NON-AUTHORITATIVE` | Literature review search lead (unverified citations) |
| `report_v2.tex` | [`project/legacy_intake/manuscripts/report_v2.tex`](./manuscripts/report_v2.tex) | `manuscripts` | 46845 | `ee468b500320c36ca5806631f295ea90baeb896b805867d866436a242fdde24f` | `LEGACY — NON-AUTHORITATIVE` | Legacy IEEE LaTeX manuscript draft |
| `ku_format.md` | [`project/legacy_intake/venue_inputs/ku_format.md`](./venue_inputs/ku_format.md) | `venue_inputs` | 38653 | `d08f9eeed4157fa1f9f546e48aff848890c85c7529d805620b32e1cd89de5482` | `LEGACY — NON-AUTHORITATIVE` | KU formatting reference notes |
| `load-adaptive-iir/README.md` | [`project/legacy_intake/documents/legacy_README.md`](./documents/legacy_README.md) | `documents` | 7105 | `2373676c2e25f80d9807fa0d3785eb00b315f32a7f3186c1889adb064f2620ea` | `LEGACY — NON-AUTHORITATIVE` | Legacy package README with simulated claims |
| `load-adaptive-iir/requirements.txt` | [`project/legacy_intake/requirements/legacy_requirements.txt`](./requirements/legacy_requirements.txt) | `requirements` | 90 | `54222f84919decf79ee467f3ab40a74a63990e1e88d8162815c135b8ce0cf9be` | `LEGACY — NON-AUTHORITATIVE` | Legacy unpinned dependencies specification |

---

## Summary of Quarantined Categories
- `tools/`: 1 file (one-off scripts)
- `requirements/`: 2 files (historical prompts and unpinned deps)
- `notes/`: 1 file (legacy fix notes)
- `documents/`: 3 files (legacy README, project contexts)
- `reviews/`: 1 file (legacy adversarial study)
- `literature/`: 1 file (unverified literature notes)
- `manuscripts/`: 1 file (legacy IEEE draft)
- `venue_inputs/`: 1 file (KU format reference)
