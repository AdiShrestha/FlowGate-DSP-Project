# FlowGate Legacy Intake: Forbidden Evidence Inventory

**Captured Date:** 2026-09-01
**Contract ID:** C01-03
**Authority:** Invariant INV-DATA-001 (No Fabricated Empirical Evidence)

---

## 1. Strictly Forbidden Legacy Modules

The following files contain synthetic data generators, simulated backpressure mechanisms, synthetic anomaly injectors, or pseudo-replication runners. **THEY MUST NEVER BE IMPORTED BY OR MIGRATED TO `source/` OR USED TO GENERATE EVIDENCE FOR PUBLICATION.**

| Forbidden Legacy File | Primary Violation | Reason for Absolute Bar |
|---|---|---|
| `load-adaptive-iir/src/demo_signals.py` | Synthetic Data Generation | Implements `generate_synthetic_signal` (random walks, sine-noise mixtures). INV-DATA-001 violation. |
| `load-adaptive-iir/src/anomaly_injection.py` | Synthetic Anomaly Injection | Injects artificial spikes/bursts into data streams. INV-DATA-001 violation. |
| `load-adaptive-iir/src/queue_simulator.py` | Queue/Load Simulation | Implements `simulate_backpressure` and synthetic queue dynamics. INV-DATA-001 violation. |
| `load-adaptive-iir/src/experiment_a_compute_cost.py` | Synthetic Fallback / Uncontrolled Timing | Uses synthetic fallbacks and uncalibrated timing loops. |
| `load-adaptive-iir/src/experiment_b_throughput_stability.py` | Simulated Throughput Model | Simulates arrival queues rather than measuring real OS processes. |
| `load-adaptive-iir/src/experiment_c_pareto.py` | Synthetic Anomaly Pareto Curve | Computes ROC-AUC curves over synthetically injected anomalies. |
| `load-adaptive-iir/src/fp_paradox.py` | Simulated False Positive Paradox | Simulates trade frequencies and synthetic alert distributions. |
| `load-adaptive-iir/src/multi_seed_evaluation.py` | Pseudo-Replication Runner | Re-evaluates identical data with 150 random seeds and claims N=150 independent trials. |
| `load-adaptive-iir/src/run_all.py` | Monolithic Demo Runner | Orchestrates execution of all synthetic experiment scripts and overwrites results. |

---

## 2. Forbidden Legacy Result Artifacts

All files located in `load-adaptive-iir/results/` (including all subdirectories: `plots/`, `tables/`, `runs/`) are classified as `forbidden-evidence`.

- **Total legacy result files:** 42 files
- **Violations:**
  - Contradictory metric values across `paired_ttest_results.csv`, `delong_results.csv`, and markdown summaries.
  - Metrics computed over generated/simulated signals.
  - Non-standard ROC-AUC calculations and statistical cancellation warnings.
- **Enforcement:**
  - Tracked in `project/legacy_intake/results_manifest/` for historical provenance.
  - Barred from entering `key_facts.md`, `source/artifacts/release/`, or publication manuscripts.
