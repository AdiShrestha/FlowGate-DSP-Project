# FlowGate Legacy Worktree Snapshot
**Captured Date:** 2026-09-01
**Contract ID:** C01-01
**Purpose:** Forensic record of starting working tree state before rehabilitation.

---

## 1. Git Repository State

- **Current Branch:** `main`
- **HEAD Commit Hash:** `f73dc1eca9e7e7b413f12d491342049d0936111c`
- **Remote URLs:**
```
origin	git@github.com:AdiShrestha/FlowGate-DSP-Project.git (fetch)
origin	git@github.com:AdiShrestha/FlowGate-DSP-Project.git (push)
```
- **Tags:** `None`
- **Tracked File Count:** 125
- **Total Tracked Files Size:** 24140828 bytes (23.02 MB)
- **Total Workspace Size:** 5128924909 bytes (4.78 GB)

### Recent Git Log (Last 10 Commits)
```
f73dc1e chore: Add Apache 2.0 license header to DeLong implementation for IEEE compliance
b9a06cd Add final experimental figures, tables, and overnight outputs
bcd176b Fix DeLong test and complete 150-seed pipeline run
0bc133d Final Hardening Pass: Pareto bug, Butterworth cold-start, BW match, and regression tests
72e2d57 enhanced pipeline performance
39bbd67 Perf fix: JIT-compile load_adaptive_ema alpha computation + adaptive timing
8386507 Add compute/throughput benefit experiments (Sections 1-8 of fix1.md)
03171f5 fix floating point bounds test add seed and tolerance
eacfa12 close all spec gaps: per type eval, full notebook, readme limitations, derivation docstring, section citations
3cbd7a8 fix brittle lambda string test replace with numeric parse
```

### Git Status (`git status --short --branch`)
```
## main...origin/main
 M .DS_Store
 M .gitignore
 D load-adaptive-iir/notebooks/01_full_pipeline.ipynb
 M load-adaptive-iir/results/figures/slew_rate_sensitivity.png
 M load-adaptive-iir/results/tables/slew_rate_sensitivity.csv
 M load-adaptive-iir/src/__pycache__/delong.cpython-312.pyc
 M load-adaptive-iir/src/__pycache__/fp_paradox.cpython-312.pyc
 M load-adaptive-iir/src/__pycache__/numba_filters.apply_shedding_forward_fill_y-214.py312.nbi
 M load-adaptive-iir/src/__pycache__/numba_filters.compute_kama_sc-187.py312.nbi
 M load-adaptive-iir/src/__pycache__/numba_filters.compute_load_adaptive_alpha-107.py312.nbi
 M load-adaptive-iir/src/__pycache__/numba_filters.compute_processing_mask_kernel-163.py312.nbi
 M load-adaptive-iir/src/__pycache__/numba_filters.fixed_iir_direct_form_ii-20.py312.nbi
 M load-adaptive-iir/src/__pycache__/numba_filters.time_varying_first_order_ema-74.py312.nbi
 M load-adaptive-iir/src/__pycache__/statistical_tests.cpython-312.pyc
 M load-adaptive-iir/src/fp_paradox.py
 M load-adaptive-iir/src/multi_seed_evaluation.py
 M load-adaptive-iir/src/statistical_tests.py
?? build_mega_context.py
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240101_20240101.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240102_20240102.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240103_20240103.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240104_20240104.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240105_20240105.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240106_20240106.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240107_20240107.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240108_20240108.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240109_20240109.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240110_20240110.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240111_20240111.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240112_20240112.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240113_20240113.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240114_20240114.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240115_20240115.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240116_20240116.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240117_20240117.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240118_20240118.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240119_20240119.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240120_20240120.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240121_20240121.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240122_20240122.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240123_20240123.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240124_20240124.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240125_20240125.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240126_20240126.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240127_20240127.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240128_20240128.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240129_20240129.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240130_20240130.parquet
?? load-adaptive-iir/data/processed/binance_BNBUSDT_20240131_20240131.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240102_20240102.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240103_20240103.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240104_20240104.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240105_20240105.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240106_20240106.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240107_20240107.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240108_20240108.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240109_20240109.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240110_20240110.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240111_20240111.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240112_20240112.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240113_20240113.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240114_20240114.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240115_20240115.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240116_20240116.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240117_20240117.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240118_20240118.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240119_20240119.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240120_20240120.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240121_20240121.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240122_20240122.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240123_20240123.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240124_20240124.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240125_20240125.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240126_20240126.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240127_20240127.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240128_20240128.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240129_20240129.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240130_20240130.parquet
?? load-adaptive-iir/data/processed/binance_BTCUSDT_20240131_20240131.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240101_20240101.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240102_20240102.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240103_20240103.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240104_20240104.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240105_20240105.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240106_20240106.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240107_20240107.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240108_20240108.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240109_20240109.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240110_20240110.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240111_20240111.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240112_20240112.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240113_20240113.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240114_20240114.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240115_20240115.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240116_20240116.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240117_20240117.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240118_20240118.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240119_20240119.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240120_20240120.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240121_20240121.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240122_20240122.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240123_20240123.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240124_20240124.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240125_20240125.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240126_20240126.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240127_20240127.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240128_20240128.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240129_20240129.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240130_20240130.parquet
?? load-adaptive-iir/data/processed/binance_ETHUSDT_20240131_20240131.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240101_20240101.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240102_20240102.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240103_20240103.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240104_20240104.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240105_20240105.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240106_20240106.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240107_20240107.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240108_20240108.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240109_20240109.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240110_20240110.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240111_20240111.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240112_20240112.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240113_20240113.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240114_20240114.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240115_20240115.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240116_20240116.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240117_20240117.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240118_20240118.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240119_20240119.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240120_20240120.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240121_20240121.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240122_20240122.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240123_20240123.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240124_20240124.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240125_20240125.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240126_20240126.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240127_20240127.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240128_20240128.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240129_20240129.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240130_20240130.parquet
?? load-adaptive-iir/data/processed/binance_SOLUSDT_20240131_20240131.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240101_20240101.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240102_20240102.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240103_20240103.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240104_20240104.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240105_20240105.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240106_20240106.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240107_20240107.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240108_20240108.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240109_20240109.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240110_20240110.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240111_20240111.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240112_20240112.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240113_20240113.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240114_20240114.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240115_20240115.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240116_20240116.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240117_20240117.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240118_20240118.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240119_20240119.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240120_20240120.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240121_20240121.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240122_20240122.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240123_20240123.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240124_20240124.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240125_20240125.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240126_20240126.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240127_20240127.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240128_20240128.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240129_20240129.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240130_20240130.parquet
?? load-adaptive-iir/data/processed/binance_XRPUSDT_20240131_20240131.parquet
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-01.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-02.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-03.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-04.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-05.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-06.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-07.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-08.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-09.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-10.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-11.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-12.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-13.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-14.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-15.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-16.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-17.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-18.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-19.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-20.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-21.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-22.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-23.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-24.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-25.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-26.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-27.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-28.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-29.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-30.zip
?? load-adaptive-iir/data/raw/BNBUSDT-trades-2024-01-31.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-02.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-03.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-04.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-05.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-06.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-07.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-08.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-09.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-10.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-11.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-12.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-13.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-14.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-15.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-16.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-17.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-18.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-19.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-20.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-21.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-22.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-23.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-24.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-25.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-26.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-27.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-28.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-29.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-30.zip
?? load-adaptive-iir/data/raw/BTCUSDT-trades-2024-01-31.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-01.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-02.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-03.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-04.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-05.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-06.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-07.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-08.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-09.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-10.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-11.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-12.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-13.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-14.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-15.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-16.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-17.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-18.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-19.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-20.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-21.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-22.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-23.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-24.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-25.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-26.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-27.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-28.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-29.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-30.zip
?? load-adaptive-iir/data/raw/ETHUSDT-trades-2024-01-31.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-01.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-02.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-03.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-04.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-05.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-06.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-07.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-08.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-09.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-10.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-11.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-12.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-13.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-14.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-15.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-16.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-17.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-18.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-19.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-20.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-21.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-22.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-23.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-24.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-25.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-26.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-27.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-28.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-29.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-30.zip
?? load-adaptive-iir/data/raw/SOLUSDT-trades-2024-01-31.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-01.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-02.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-03.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-04.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-05.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-06.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-07.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-08.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-09.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-10.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-11.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-12.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-13.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-14.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-15.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-16.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-17.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-18.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-19.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-20.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-21.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-22.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-23.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-24.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-25.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-26.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-27.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-28.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-29.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-30.zip
?? load-adaptive-iir/data/raw/XRPUSDT-trades-2024-01-31.zip
?? load-adaptive-iir/notebooks/.DS_Store
?? load-adaptive-iir/results/tables/paired_ttest_results.csv
?? load-adaptive-iir/src/__pycache__/numba_filters.apply_shedding_forward_fill_y-214.py312.2.nbc
?? load-adaptive-iir/src/__pycache__/numba_filters.compute_kama_sc-187.py312.3.nbc
?? load-adaptive-iir/src/__pycache__/numba_filters.compute_load_adaptive_alpha-107.py312.3.nbc
?? load-adaptive-iir/src/__pycache__/numba_filters.compute_processing_mask_kernel-163.py312.3.nbc
?? load-adaptive-iir/src/__pycache__/numba_filters.fixed_iir_direct_form_ii-20.py312.3.nbc
?? load-adaptive-iir/src/__pycache__/numba_filters.time_varying_first_order_ema-74.py312.3.nbc
?? load-adaptive-iir/tests/test_anomaly_injection.py
?? load-adaptive-iir/tests/test_detection.py
?? load-adaptive-iir/tests/test_filter_stability.py
?? load-adaptive-iir/tests/test_statistical_tests.py
```

---

## 2. Directory-Level Size Breakdown

| Directory Path | Size (Bytes) | Human-Readable Size | Description / Role |
|---|---|---|---|
| `.git/` | 1851825171 | 1.72 GB | Git repository database & objects |
| `load-adaptive-iir/` | 2644468085 | 2.46 GB | Legacy Python project root |
| `load-adaptive-iir/data/raw/` | 1518362110 | 1.41 GB | Raw Binance trade archives (ZIP) |
| `load-adaptive-iir/data/processed/` | 486555780 | 464.02 MB | Legacy processed Parquet datasets |
| `load-adaptive-iir/results/` | 3453748 | 3.29 MB | Legacy generated experiment results & plots |
| `Isolated-Backend/` | 496119199 | 473.14 MB | Legacy Node.js backend server |
| `React-Frontend/` | 134378055 | 128.15 MB | Legacy React web frontend |
| `project/` | 343741 | 335.68 KB | Factory project directory (nested repo) |
| `factory/` | 832515 | 813.00 KB | Software Factory v2.2.0 machinery |
| `source/` | 0 | 0.00 B | Authoritative source directory (to be populated) |

---

## 3. Working Tree Status Summary

- **Modified Tracked Files (16):**
- `.DS_Store`
- `.gitignore`
- `load-adaptive-iir/results/figures/slew_rate_sensitivity.png`
- `load-adaptive-iir/results/tables/slew_rate_sensitivity.csv`
- `load-adaptive-iir/src/__pycache__/delong.cpython-312.pyc`
- `load-adaptive-iir/src/__pycache__/fp_paradox.cpython-312.pyc`
- `load-adaptive-iir/src/__pycache__/numba_filters.apply_shedding_forward_fill_y-214.py312.nbi`
- `load-adaptive-iir/src/__pycache__/numba_filters.compute_kama_sc-187.py312.nbi`
- `load-adaptive-iir/src/__pycache__/numba_filters.compute_load_adaptive_alpha-107.py312.nbi`
- `load-adaptive-iir/src/__pycache__/numba_filters.compute_processing_mask_kernel-163.py312.nbi`
- `load-adaptive-iir/src/__pycache__/numba_filters.fixed_iir_direct_form_ii-20.py312.nbi`
- `load-adaptive-iir/src/__pycache__/numba_filters.time_varying_first_order_ema-74.py312.nbi`
- `load-adaptive-iir/src/__pycache__/statistical_tests.cpython-312.pyc`
- `load-adaptive-iir/src/fp_paradox.py`
- `load-adaptive-iir/src/multi_seed_evaluation.py`
- `load-adaptive-iir/src/statistical_tests.py`

- **Deleted Tracked Files (1):**
- `load-adaptive-iir/notebooks/01_full_pipeline.ipynb`

- **Untracked Paths Count:** 321
