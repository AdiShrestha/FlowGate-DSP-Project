# FlowGate Legacy Intake: Results Manifest

**Captured Date:** 2026-09-01
**Contract ID:** C01-03
**Classification:** `LEGACY — NON-AUTHORITATIVE / FORBIDDEN EVIDENCE`

---

## Inventory of Legacy Results

| Path | Size (Bytes) | SHA-256 Hash | Status |
|---|---|---|---|
| `load-adaptive-iir/results/bandwidth_matching_resolution.md` | 5288 | `2a1c903016f9fa792ab2a7ba29fb5e38f4d54d46aca808f0f5a668e045de52de` | `forbidden-evidence` |
| `load-adaptive-iir/results/compute_benefit_summary.md` | 2280 | `071c90d0fb7eeee27d5293ecdf7289185834e088ac85675df23b380d596c1992` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/experiment_a_compute_cost.png` | 86469 | `247c947227d90296f131f17ab7c9b2db961f591804e869c5b4664abc63795b84` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/experiment_b_max_throughput_bar.png` | 64529 | `91426105ddeaf1e54595720f4417e975dce230af108eb344614ba2eb5e772706` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/experiment_b_queue_stability.png` | 122861 | `782bca5e53ee4449d812406f41e904befe974bc36a2bc002133872dd3ff8456c` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/experiment_b_sensitivity.png` | 118359 | `1390d24815fd577a5a009b0a26d214e304a96f532e82c6be2488a4c97523a90a` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/experiment_c_pareto.png` | 117142 | `986ffdffdb65439d8a1d7bbb35db650a75be334d7e39cb090691cbcb6a2ee076` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/fp_paradox_demonstration.png` | 57284 | `55a7410defd3035946a2e3d45ab1c80568b804f01cec32086d285937722b3133` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/frequency_response_sweep.png` | 227045 | `5645dde1e99b3c1995ecdce521f4c286f65e8b8cbf194a2aca63dcd176e90eb2` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/impulse_response.png` | 76807 | `aba34f01922b5977e30f5eaff4d0b3f07f04b59635fd8a8e22a9b35459507f27` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/load_vs_anomaly_correlation.png` | 53551 | `32f82a57c6b2345eec3eeb0fc389a97d0a2d7a3f009b0ae86196127b0409072e` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/metrics_bar_comparison.png` | 94331 | `1ce0b68796533f2144f045d5e603c1a3358bbdfd67861418938f0ca5f938df27` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/pole_trajectory_vs_load.png` | 74370 | `6593174fe3be090723a98f645c828c3cd76d45c5da8bb88a25313dde31953473` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/pole_zero_sweep.png` | 68522 | `02239a9d18b6aa93bbc86d0c3d7fb5855b31345befad1cf1c13beef815ccc1eb` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/psd_comparison_real_data.png` | 142289 | `d7c48530493490eb5955f3e523e94a1b30194e0569f0e101692aba670f2fd942` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/queue_simulation.png` | 46055 | `f18ddf62dba01663c55fdf109271762c8efbeba3cba501294f8692d548bb0af9` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/roc_pr_curves.png` | 157834 | `59a0aac48e7ab35f6003b8379c035c365e38034e523a4662614712cdd38bd32f` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/slew_rate_sensitivity.png` | 40298 | `66dd2d5c7268518cbf5a03d930a8a560e9d29f45acf1d1b8d3e586acb2f5198a` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/spectrum_demo_butterworth.png` | 151160 | `10e6ae84f65ab92c9e9b73ba7d2eb8f59bf08e324c7a8b45acf0736e27e58563` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/spectrum_demo_fixed_ema.png` | 208074 | `1dacafb3ca706fb0eb0ba0e2cafc8ee6f379f00ceaf0b712984997fa1dea9447` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/spectrum_demo_kama.png` | 189584 | `bd948c0a818213ac23ed35006cf9db57fc27a47f5d274410a9db75edf9cca7fa` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/spectrum_demo_load_adaptive.png` | 201829 | `e8e870172385fe9bec6f7e4cfb7bf18ea7417c537a41f4bea307cd47df1b5853` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/step_response.png` | 35797 | `126fdd78d0ed9aa6369cdbb8144ead6a6950634e35f69a5f0f91a7c6c5d647e4` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/time_domain_comparison.png` | 685835 | `89f501b4b5e878b62ea1a35eeb6caecb7147daf9caca95273ccc742714bf5579` | `forbidden-evidence` |
| `load-adaptive-iir/results/figures/time_varying_frequency_response.png` | 100340 | `05dd299599bd0edf8a736aba38ac856970a7f1bad7a4e29d91de2d278e0c7403` | `forbidden-evidence` |
| `load-adaptive-iir/results/final_audit_checklist.md` | 3271 | `c7c3baf9feb70834491a62c461e7e1152cf76a091561dc2f1e2dd147240141eb` | `forbidden-evidence` |
| `load-adaptive-iir/results/overnight_run.log` | 62528 | `d1a8b6c1a5c1125900b07d37994de688e2ef6753fe70a420011c7a7157ac8a55` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/comparison.csv` | 1189 | `08892bda916763f63b847a60db274b64c91e8ced8f7960ddd9642704c1bc3fd1` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/comparison_level_shift.csv` | 1094 | `6b6429e3ae29a2f5984376183988a3a2e94846d45aaed022b667884ca8642783` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/comparison_point.csv` | 998 | `ac626c9bee85a85e9232e29502d613e0ac09b68bb98614d1b10e3bdb3da0ac97` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/comparison_volatility_burst.csv` | 1102 | `2d0bd9ea506ddb0f415d4a9902c0eaadcda1dc85444f950de63f5747a0489a3f` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/delong_test_results.csv` | 234 | `7b8587a3a432c92ee10edef342a4069ac07c0b7ffc6704582c646abb1ed42560` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/downstream_cost_measurement.json` | 194 | `61db2cbc67c5dbc74ca211abb59e4c781813953ce3362ee9fddba754cb4b7617` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/experiment_a_compute_cost.csv` | 1531 | `aa41713172311b5e15fa43052438dce4fb85e26543b8e1be289c59f58ed403ee` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/experiment_b_sensitivity.csv` | 1811 | `28c2b4b56c500445a8aeb883d174512337bf28d1cb8ce51ab437d7fe7bcf7532` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/experiment_b_throughput.csv` | 780 | `84024dc01a97104540f3529435a9433de6abecb655a0235fae474372be388014` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/experiment_metadata.json` | 824 | `388df9dabf2d5ba21c9a0a3a1985f666a0b8121ce37d495b7a0dd892a2bf635f` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/fp_paradox_analysis.csv` | 186 | `f82f2c595a27a10b485121853a5958d2b299545d2c80ac2b25454e532cfdd553` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/multi_seed_roc_auc.csv` | 236722 | `db027350e9bad243f498413bcc9fd1e253905fb2714b84cf561107fc33f1f106` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/multi_seed_summary.csv` | 1836 | `ed5ae169d4b99b51010cf8ff3ced778852e6cd7af097e70704d04c60014f8149` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/paired_ttest_results.csv` | 1077 | `5b3a7820e2b085e1591a6f14493196b6a1e096c86a4c42ccb2e52371d086d7ce` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/regime_classification.csv` | 10109 | `5944cac4f37cbacda5e5facec06b367ddeb9174318e38c8afcc01f1fbec6704e` | `forbidden-evidence` |
| `load-adaptive-iir/results/tables/slew_rate_sensitivity.csv` | 329 | `f8e223de73acdb16db368ac186a39787d39b20fb4465f6500234b0676d74b740` | `forbidden-evidence` |
