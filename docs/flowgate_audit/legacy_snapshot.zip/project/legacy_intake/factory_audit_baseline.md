# Factory Audit Baseline

**Captured Date:** 2026-09-01
**Contract ID:** C01-01
**Purpose:** Record mechanical Gatekeeper audit findings against legacy codebase prior to migration.

---

## 1. Gatekeeper Self-Check Output

**Command:** `python3 factory/gatekeeper.py self-check`
**Result:** 0 Implementation/Specification drift findings, 9 Heuristic warnings.

```text
Gatekeeper self-check (diagnostic only -- reports diffs, never auto-fixes)
============================================================

[Implemented vs. specified]
  No drift found.

[Artifact Lifecycle vs. operative instructions]
  No drift found.

[Version currency]
  - STALE VERSION REFERENCE: factory/gatekeeper_spec.md references version(s) ['1.3.2', '1.3.4', '1.4.2'] but VERSION is '2.2.0'. (Historical reference)
  - STALE VERSION REFERENCE: factory/factory_spec.md references version(s) ['1.2.0'] but VERSION is '2.2.0'. (Historical reference)
  - STALE VERSION REFERENCE: factory/implementor_spec.md references version(s) ['1.2.0'] but VERSION is '2.2.0'. (Historical reference)
  - STALE VERSION REFERENCE: factory/implementor_spec.md references version(s) ['1.2.0'] but VERSION is '2.2.0'. (Historical reference)
  - STALE VERSION REFERENCE: factory/dynamic_rules.md references version(s) ['1.2.0'] but VERSION is '2.2.0'. (Historical reference)
  - STALE VERSION REFERENCE: factory/gatekeeper.py references version(s) ['1.3.0'] but VERSION is '2.2.0'. (Historical reference)

[Naming-convention lint]
  - NAMING CONVENTION: factory/implementor_spec.md contains contract-ID-shaped string(s) not matching ^C\d{2}-\d{2}: ['C1-1'].
  - NAMING CONVENTION: factory/implementor_spec.md contains contract-ID-shaped string(s) not matching ^C\d{2}-\d{2}: ['C1-1'].
  - NAMING CONVENTION: factory/gatekeeper.py contains contract-ID-shaped string(s) not matching ^C\d{2}-\d{2}: ['C1-02', 'C1-2', 'C1-3', 'C3-01'].

Total findings: 9 (all classified as expected historical/example references)
```

---

## 2. Acquisition Audit Output

**Command:** `python3 factory/gatekeeper.py acquisition-audit --scripts load-adaptive-iir/src/*.py`
**Result:** 2 Hard Failures (Data-Generation Functions), 7 Textual Warnings (Simulation-Indicating Language).

### Hard Failures:
1. `DATA-GENERATION FUNCTION`: `load-adaptive-iir/src/demo_signals.py:6` (`generate_synthetic_signal`)
2. `DATA-GENERATION FUNCTION`: `load-adaptive-iir/src/queue_simulator.py:3` (`simulate_backpressure`)

### Textual Warnings:
1. `load-adaptive-iir/src/anomaly_injection.py`: contains `["synthetic"]`
2. `load-adaptive-iir/src/data_expansion.py`: contains `["generated"]`
3. `load-adaptive-iir/src/demo_signals.py`: contains `["synthetic"]`
4. `load-adaptive-iir/src/experiment_a_compute_cost.py`: contains `["synthetic"]`
5. `load-adaptive-iir/src/experiment_b_throughput_stability.py`: contains `["fallback", "simulated", "synthetic"]`
6. `load-adaptive-iir/src/experiment_c_pareto.py`: contains `["generated", "synthetic"]`
7. `load-adaptive-iir/src/run_all.py`: contains `["simulated", "synthetic"]`

---

## 3. Lint Contract Output

**Command:** `python3 factory/gatekeeper.py lint-contract --scripts load-adaptive-iir/src/*.py`
**Result:** 9 Hard Failures (Swallowed Exceptions), 0 Warnings.

### Swallowed Exceptions (Fail-Closed Violations):
1. `load-adaptive-iir/src/data_acquisition.py:63` (`except Exception:`) — silent download fallback
2. `load-adaptive-iir/src/data_expansion.py:26` (`except Exception:`) — silent expansion fallback
3. `load-adaptive-iir/src/experiment_a_compute_cost.py:62` (`except Exception:`) — silent timing fallback
4. `load-adaptive-iir/src/experiment_a_compute_cost.py:78` (`except Exception:`) — silent execution fallback
5. `load-adaptive-iir/src/experiment_b_throughput_stability.py:56` (`except Exception:`) — silent simulation fallback
6. `load-adaptive-iir/src/experiment_c_pareto.py:54` (`except Exception:`) — silent pareto fallback
7. `load-adaptive-iir/src/fp_paradox.py:19` (`bare except:`) — silent execution fallback
8. `load-adaptive-iir/src/multi_seed_evaluation.py:23` (`except Exception:`) — silent seed fallback
9. `load-adaptive-iir/src/run_all.py:135` (`except Exception:`) — silent pipeline fallback

All of these files are quarantined under C01-03 and barred from authoritative migration in C01-04/C01-06.
