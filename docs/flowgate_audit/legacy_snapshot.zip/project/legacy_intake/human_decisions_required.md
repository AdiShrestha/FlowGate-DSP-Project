# FlowGate Forensic Intake: Human Decisions Required

**Date:** 2026-09-01
**Contract ID:** C01-01
**Status:** Staged for Human / Architect Review

---

## Decision Request 1: Deleted Legacy Notebook (`01_full_pipeline.ipynb`)
- **Path:** `load-adaptive-iir/notebooks/01_full_pipeline.ipynb`
- **Git State:** `deleted` (tracked in git HEAD, deleted in working tree)
- **Context:** This notebook was previously tracked and deleted during development. It contains full pipeline demonstration code that calls legacy synthetic generators and plotting.
- **Proposed Disposition:** Preserve deletion in working tree; record historical existence in `asset_ledger.csv`; do NOT restore to `source/`.
- **Architect/Human Action:** Confirm whether to keep deleted or extract historical copy to `project/legacy_intake/documents/`.

---

## Decision Request 2: Tracked Source Modifications in `load-adaptive-iir/`
- **Modified Tracked Files:**
  - `load-adaptive-iir/src/experiment_a_compute_cost.py`
  - `load-adaptive-iir/src/experiment_b_throughput_stability.py`
  - `load-adaptive-iir/src/experiment_c_pareto.py`
  - `load-adaptive-iir/src/fp_paradox.py`
  - `load-adaptive-iir/src/multi_seed_evaluation.py`
  - `load-adaptive-iir/src/run_all.py`
  - `load-adaptive-iir/tests/test_bandwidth_calibration.py`
  - `load-adaptive-iir/tests/test_harness.py`
  - `load-adaptive-iir/tests/test_queue_stability_sanity.py`
  - `load-adaptive-iir/results/tables/paired_ttest_results.csv`
- **Diff Analysis:** Diffs have been extracted to `project/legacy_intake/diffs/`. All modified files in `src/` are part of the forbidden-evidence evaluation scripts.
- **Proposed Disposition:** Quarantine all modified experiment files to `project/legacy_intake/` without promoting changes to `source/`.
- **Architect/Human Action:** Confirm quarantine disposition.

---

## Decision Request 3: Legacy Untracked Analysis & Planning Documents
- **Files:**
  - `dsp_project_build_prompt.md`
  - `fix1.md`
  - `mega_report_context.md`
  - `project_context.md`
  - `study.md`
  - `load_adaptive_iir_literature_review.md`
  - `report_v2.tex`
  - `ku_format.md`
  - `build_mega_context.py`
- **Proposed Disposition:** Quarantine all to `project/legacy_intake/` under respective categories per C01-03 disposition matrix.
- **Architect/Human Action:** Confirm quarantine categorization.
