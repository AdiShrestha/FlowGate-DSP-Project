# FlowGate Secret and Local Path Scan

**Captured Date:** 2026-09-01
**Contract ID:** C01-01
**Scan Target:** Entire working tree (excluding `.git/`)

---

## 1. Scan Summary

- Total scanned files: ~150 text/code/document files
- Hard API Keys / Secrets Found: **0**
- Local Machine Paths (`/Users/adi/...`): Found in legacy scripts, logs, and document references.
- Email Placeholders: None requiring emergency containment.

---

## 2. Findings Inventory

| Relative File Path | Finding Category | Match Snippet (Redacted) | Action Required |
|---|---|---|---|
| `mega_report_context.md` | KU Email Placeholder | `yourname@ku.edu.np` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `build_mega_context.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `rehabilitation_plan.md` | KU Email Placeholder | `yourname@ku.edu.np` | Sanitise in Chunk 11/12 before release |
| `report_v2.tex` | KU Email Placeholder | `yourname@ku.edu.np` | Sanitise in Chunk 11/12 before release |
| `load-adaptive-iir/.myenv/lib/python3.12/site-packages/fsspec/spec.py` | Potential API Key / Secret | `password='...[REDACTED]` | Sanitise in Chunk 11/12 before release |
| `load-adaptive-iir/.myenv/lib/python3.12/site-packages/pandas/tests/io/conftest.py` | AWS Credentials Key | `AWS_ACCESS...[REDACTED]` | Sanitise in Chunk 11/12 before release |
| `load-adaptive-iir/.myenv/lib/python3.12/site-packages/pandas/tests/io/conftest.py` | AWS Credentials Key | `AWS_SECRET...[REDACTED]` | Sanitise in Chunk 11/12 before release |
| `load-adaptive-iir/.myenv/lib/python3.12/site-packages/pyarrow/tests/test_fs.py` | Potential API Key / Secret | `secret_key...[REDACTED]` | Sanitise in Chunk 11/12 before release |
| `load-adaptive-iir/.myenv/lib/python3.12/site-packages/pyarrow/tests/test_dataset.py` | Potential API Key / Secret | `secret_key...[REDACTED]` | Sanitise in Chunk 11/12 before release |
| `load-adaptive-iir/.myenv/lib/python3.12/site-packages/pyarrow/tests/test_dataset.py` | Potential API Key / Secret | `secret_key...[REDACTED]` | Sanitise in Chunk 11/12 before release |
| `load-adaptive-iir/.myenv/lib/python3.12/site-packages/pyarrow/tests/parquet/conftest.py` | AWS Credentials Key | `aws_access...[REDACTED]` | Sanitise in Chunk 11/12 before release |
| `load-adaptive-iir/.myenv/lib/python3.12/site-packages/pyarrow/tests/parquet/conftest.py` | AWS Credentials Key | `aws_secret...[REDACTED]` | Sanitise in Chunk 11/12 before release |
| `project/invariants.md` | KU Email Placeholder | `yourname@ku.edu.np` | Sanitise in Chunk 11/12 before release |
| `project/venue_requirements.md` | KU Email Placeholder | `yourname@ku.edu.np` | Sanitise in Chunk 11/12 before release |
| `project/venue_requirements.md` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `project/legacy_intake/test_baseline.md` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `project/chunks/chunk01/scripts/build_intake_artifacts.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/Desktop/DSP` | Sanitise in Chunk 11/12 before release |
| `project/chunks/chunk01/scripts/build_intake_artifacts.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/[^\s\` | Sanitise in Chunk 11/12 before release |
| `project/chunks/chunk01/scripts/build_intake_artifacts.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/...` | Sanitise in Chunk 11/12 before release |
| `project/chunks/chunk01/scripts/build_intake_artifacts.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/...`` | Sanitise in Chunk 11/12 before release |
| `project/chunks/chunk01/scripts/build_intake_artifacts.py` | Local Machine Path Leaks (/Users/adi/...) | `/Users/adi/...`` | Sanitise in Chunk 11/12 before release |
| `project/chunks/chunk01/scripts/build_intake_artifacts.py` | AWS Credentials Key | `aws_access...[REDACTED]` | Sanitise in Chunk 11/12 before release |

---

## 3. Containment Assessment

- **Critical Security Threats:** None. No live API keys, database credentials, or third-party tokens found.
- **Release Hygiene Tasks:** Local paths (e.g. `/Users/adi/...`) exist in legacy documents, docstrings, and comments. These are documented for sanitisation during Chunk 11 (Manuscript/Docs) and Chunk 12 (Release Hardening).
