# Roadmap

Status: Frozen File. Created at Project Initialization. Amended only via Architecture Amendment.

---

## Overview

The rehabilitation follows a strict 12-chunk dependency-ordered sequence. Chunks may not be merged in a way that places data acquisition, semantic correction, experimental design, execution, and publication into one review boundary. Each chunk has explicit entry/exit criteria and produces stamped, verifiable deliverables.

## Dependency Graph

```text
Project Initialization
        │
        ▼
Chunk 01  Repository + truth firewall
        │
        ▼
Chunk 02  Scope + venue + real-label feasibility
        │
        ▼
Chunk 03  Authentic acquisition + Reality Gate
        │
        ├───────────────┐
        ▼               ▼
Chunk 04 DSP semantics  Chunk 05 Measured runtime harness
        └───────┬───────┘
                ▼
Chunk 06  Frozen evaluation/statistics protocol
                │
                ▼
Chunk 07  Authentic pilot
                │
                ▼
Chunk 08  Final experiments
                │
                ▼
Chunk 09  Independent analysis + claim ledger
                │
                ├──────────────► Chunk 10 Optional app
                │                         │
                └──────────────┬──────────┘
                               ▼
Chunk 11  Manuscript/docs/reproduction
                               │
                               ▼
Chunk 12  Release certification + retrospective
```

---

## Chunk 01 — Forensic Intake, Factory Normalisation, and Truth Firewall

**Objective:** Convert the dirty legacy repository into a losslessly preserved, Factory-native, buildable baseline in which authoritative source is separated from legacy material and no production/research path can generate or substitute empirical data.

**Scientific tier:** NONE (T-DESC for inventory counts only)

**Deliverables:**
- Legacy state preservation and asset ledger (C01-01)
- Factory bootstrap and repository isolation (C01-02)
- Legacy quarantine and file-by-file disposition (C01-03)
- Authoritative `source/` scaffold and behaviour-preserving migration (C01-04)
- Git hygiene and `.gitignore` policy (C01-05)
- Non-fabrication firewall and fail-closed interfaces (C01-06)
- Deterministic build, test, and CI baseline (C01-07)
- Chunk integration, review, and baseline certification (C01-08)

**Dependencies:** Project Initialization (founding artifacts)

**Exit criteria:**
1. Factory v2.2.0 pinned and operational
2. Founding artifacts committed in nested `project/`
3. `source/` is the only authoritative code surface
4. Package builds and tests from a clean temporary environment
5. Zero synthetic generators, simulated-load evidence paths, or swallowed-exception hard failures in production/research source
6. Legacy data/results/documents preserved but unreachable from authoritative code
7. Git ignores transient material without hiding product source
8. Current dirty-state assets have a completed disposition; no user work lost
9. Every report stamped/verified; chunk report records limitations
10. Next action is Chunk 02, not an experiment run

**Estimated complexity:** High (8 contracts, legacy forensics, migration, and firewall)

---

## Chunk 02 — Scientific Scope, Venue, Literature, and Feasibility Freeze

**Objective:** Turn the broad legacy concept into a defensible research question and a negative-result-safe plan before acquiring or analysing evidence.

**Scientific tier:** T-DESC

**Deliverables:**
- Venue and deliverable decision (JIST requirements verified)
- Literature verification (bibliography ledger with DOI/URL, verified propositions)
- Research-question and title ladder (conservative → stronger, with gates)
- Real-label feasibility assessment (LOBSTER event labels, Nasdaq halt history)
- Data-rights review (Binance terms, label-source terms, redistribution)
- Methodology Adversarial Review refresh

**Dependencies:** Chunk 01 (repository stable)

**Critical decision gate:** If real labelled-event source has sufficient occurrences, timestamp alignment, negative periods, legal use, and reproducible acquisition → retain anomaly-detection evaluation. Otherwise → remove ground-truth claims; study filter behaviour and runtime trade-offs only.

**Exit criteria:** Exact venue chosen or external submission deferred; research questions frozen; claim ladder approved; real-label feasibility decided; bibliography source-backed; MAR passes; Chunk 03 source list and rights constraints explicit.

**Estimated complexity:** Medium (research-intensive, low code change)

---

## Chunk 03 — Trusted Acquisition, Provenance, Schema, and Reality Gate

**Objective:** Create immutable, checksum-verified authentic input and deterministic processing without silent gaps.

**Scientific tier:** T-DESC

**Deliverables:**
- HTTPS acquisition protocol (TLS enabled, checksum verified, fail-closed)
- Provenance schema (`data_manifest.json`, `acquisition_provenance.json`)
- Raw validation (checksums, schema, monotonic timestamps, domains, duplicates)
- Full-fidelity staging (retain raw fields for identity resolution)
- Deterministic transformation (schema-versioned, content-addressed outputs)
- Coverage report (expected vs acquired days/assets/events/gaps)
- Reality Gate decision (Architect performs, Human spot-checks)

**Dependencies:** Chunk 02 (scope frozen, data-rights reviewed)

**Exit criteria:** Reality Gate PASS for the exact dataset version, or BLOCKED with no downstream run. Signed dataset manifest becomes frozen input to later chunks.

**Estimated complexity:** High (acquisition rewrite, schema design, Reality Gate)

---

## Chunk 04 — DSP Core Semantic Correction and Analytical Validation

**Objective:** Make filter definitions mathematically explicit, timebase-correct, and independently tested before comparative experiments.

**Scientific tier:** T-DESC (mathematical properties); any comparative bandwidth statement is T-COMP

**Deliverables:**
- State/initial-condition specification for every filter
- Canonical semantic tests (impulse, step, constant, alternating, boundary, dtype, NaN/Inf)
- Timebase decision (fixed-bin or actual-Δt)
- Coefficient/pole terminology correction
- Stability analysis with bounded claims
- KAMA trace correction
- Baseline matching criteria (equivalent cutoff, memory, order)
- Independent reference verifier

**Dependencies:** Chunk 03 (authentic schema known for timebase decision)

**Exit criteria:** Semantic suite passes in clean room; no arbitrary physical sampling rate; optimised and reference implementations agree; baseline parameterisation frozen for pilot.

**Estimated complexity:** High (mathematical rigour, reference implementations)

---

## Chunk 05 — Real Replay and Measured Backpressure/Runtime Harness

**Objective:** Replace queue simulation with actual execution telemetry while keeping every input event authentic.

**Scientific tier:** T-DESC (harness validation); later comparative hypotheses are T-COMP/T-CAUSAL

**Deliverables:**
- Bounded-queue pipeline (real producer, bounded queue, consumer/filter, downstream, traces, clean termination)
- Replay schedule (derived from authentic records only)
- Open-loop protocol (immutable recorded arrival schedule across methods)
- Closed-loop protocol (randomised method order, warm-up/cooldown, resource isolation)
- Telemetry capture (monotonic timestamps, queue depth, consumer lag, CPU, RSS, etc.)
- Load-policy semantics separation (filtering vs shedding)
- Integrity accounting (every record in exactly one declared state)

**Dependencies:** Chunk 03 (verified authentic data); Chunk 04 in parallel (can share data schema knowledge)

**Prohibited:** `simulate_backpressure`, generated burst intervals, sleep-manufactured queue instability, edited queue traces, calling replay "live"

**Exit criteria:** Known-small authentic replay passes full accounting; repeated harness runs emit valid manifests; no comparative conclusion yet published.

**Estimated complexity:** High (runtime infrastructure, telemetry design)

---

## Chunk 06 — Pre-Registered Evaluation and Statistical Analysis Protocol

**Objective:** Freeze how experiments will answer the research questions before looking at final comparative results.

**Scientific tier:** Protocol governs T-COMP and possibly T-CAUSAL claims

**Deliverables:**
- Experimental-unit definition and unique unit IDs
- Temporal partitioning (training/calibration/pilot/final, non-overlap)
- Outcome definitions (mathematical, with units and edge cases)
- Real-label alignment (if labels passed Chunk 02/03)
- Baseline set (≥2 for T-COMP, ≥3 + ablations for T-CAUSAL)
- Power/sensitivity estimate from real pilot variance
- Equivalence/non-inferiority margin (if "no quality cost" desired)
- Multiplicity/model specification
- Stopping/retry policy
- Metric verifier (independent implementation on frozen small predictions)

**Dependencies:** Chunk 04 + Chunk 05 converged

**Exit criteria:** Protocol, analysis code interfaces, and configs frozen and hash-stamped before final data opened; title/claim audit passes; negative-result and no-label paths explicit.

**Estimated complexity:** High (statistical rigour, protocol design)

---

## Chunk 07 — Pilot on Authentic Data and Measured Telemetry

**Objective:** Prove the entire pipeline works on a small predesignated non-final subset; use only pilot evidence to finalise operational tolerances.

**Scientific tier:** T-DESC (pilot numbers are not final claims)

**Deliverables:**
- End-to-end pipeline execution on pilot subset
- Record accounting and run-manifest completeness verification
- Runtime variance measurement and run-count refinement
- Failure-path testing (unavailable input, checksum mismatch, partial output, metric degeneracy)
- Ablation smoke tests (adaptation vs shedding)
- Independent recomputation on pilot artifacts
- Final config freeze and pilot-data seal

**Dependencies:** Chunk 06 (protocol frozen)

**Exit criteria:** Full artifact lineage works; final run matrix feasible and frozen; pilot limitations recorded; no pilot result appears in abstract/conclusion.

**Estimated complexity:** Medium (integration testing, no new infrastructure)

---

## Chunk 08 — Final Real-Data Experiment Execution

**Objective:** Run the frozen experiment matrix on authentic observations and real runtime telemetry without interactive result-driven changes.

**Scientific tier:** T-COMP for comparisons; T-CAUSAL only for pre-registered causal/ablation question

**Deliverables:**
- Immutable run configs and input manifests materialised
- Randomised/paired run order execution with hardware/environment capture
- All attempts recorded to unique run IDs (no overwriting)
- Predeclared infrastructure retries only
- Sealed raw predictions, traces, labels, accounting, environment metadata
- Expected-vs-observed unit coverage check
- Factory mechanical gates for each comparative contract

**Dependencies:** Chunk 07 (pilot passed)

**Exit criteria:** All planned units present or handled by missingness rule; hashes verify; no config changed after seeing outcomes; raw run package independently readable.

**Estimated complexity:** Medium (execution-focused, infrastructure already built)

---

## Chunk 09 — Independent Recomputation, Statistics, and Claim Ledger

**Objective:** Convert frozen raw run evidence into defensible results and prevent report/artifact contradictions.

**Scientific tier:** Highest tier of the claims being evaluated

**Deliverables:**
- Independent recomputation (separate script, different hash from producer)
- Primary analysis execution (pre-registered grouped/paired model, CIs)
- Multiplicity and secondary outcome handling
- Equivalence decision (frozen margin/test)
- Ablation/adversarial analysis
- Claim ledger (one row per prospective public claim)
- Evidence consistency check

**Dependencies:** Chunk 08 (final runs sealed)

**Possible valid outcomes:**
- Adaptation + shedding improves resource metric within fidelity margin
- Improves resources but fails fidelity margin → trade-off conclusion
- Adaptation does not improve resources after harness overhead
- Some baselines dominate
- Labels too sparse for detector conclusions
- Negative result

All are acceptable scientific outcomes. None authorises fabricated augmentation.

**Exit criteria:** Every candidate claim supported, narrowed, or rejected; independent recomputation agrees; tables/figures generated only from verified aggregates; strongest surviving title selected from predeclared ladder.

**Estimated complexity:** High (statistical analysis, claim validation)

---

## Chunk 10 — Optional Historical-Replay Application Rehabilitation

**Objective:** Either build an honest, tested demonstration from verified artifacts or omit the app from the publication release.

**Scientific tier:** N/A (demonstration, not evidence)

**Entry gate:** Chunk 09 evidence and schemas stable; Human confirms app is worth maintenance/release surface.

**If retained:**
- Migrate API and web source under `source/app/`
- Serve only verified historical replay
- Label as "historical replay," never "LIVE"
- Show dataset/run IDs, symbol, observed time, replay speed, queue telemetry
- No injected anomalies or fabricated load
- API schema tests, WebSocket lifecycle tests, frontend tests, accessibility
- App reads immutable artifacts; cannot mutate release evidence

**If omitted:** Remove legacy app source from public release after preservation.

**Dependencies:** Chunk 09 (stable evidence + schemas)

**Estimated complexity:** Medium (if retained) / Low (if omitted)

---

## Chunk 11 — Manuscript, KU Report, Documentation, and Reproducibility Package

**Objective:** Write public material from the verified claim ledger rather than editing the legacy narrative into consistency.

**Scientific tier:** Inherits from claim tiers

**Deliverables:**
- Methods drafted from frozen protocol/config/schema artifacts
- Tables/figures from verified release aggregates
- Results from approved claim-ledger wording only
- Negative/null findings and limitations included
- KU report and/or JIST manuscript in current official format
- README quick start, architecture, provenance, reproduction guide
- License (after ownership/dependency/data review)
- CITATION.cff with verified author/identifier fields
- AI-use disclosure per JIST policy
- Automated claim/document consistency checks

**Dependencies:** Chunk 09 (claim ledger finalised); optionally Chunk 10

**Exit criteria:** No unsupported numbers/placeholders/local paths; every figure/table regenerates; bibliography verified; disclosure and rights statements complete; README reproduction works from clean clone.

**Estimated complexity:** Medium (writing-intensive, infrastructure already exists)

---

## Chunk 12 — Release Hardening, Archive, Certification, and Retrospective

**Objective:** Produce the first publication-ready release and close the rehabilitation with auditable certification.

**Scientific tier:** N/A (release engineering)

**Deliverables:**
- Clean-room clone/install/reproduce on supported environments
- CI matrix and release-build verification
- Secret, personal-path, license, dependency, vulnerability scans
- Outer repo verified clean of Factory/private artifacts
- Large data/evidence archived with persistent identifiers
- Factory release-check, acquisition audit, evidence checks, certification
- Versioned release notes
- Factory Retrospective

**Dependencies:** Chunk 11 (manuscript/docs complete)

**Exit criteria:** Release tag/artifacts reproducible, archived, checked, and claim-consistent; public clone contains no legacy synthetic evidence or private Factory material; recovery and maintenance documented.

**Estimated complexity:** Medium (verification-focused)
