# Key Facts

Status: Frozen-policy file (amended only via Architecture Amendment). Created at Project Initialization.
Checked automatically by `gatekeeper.py release-check` before any release-bound artifact.

---

> [!IMPORTANT]
> This file is deliberately sparse at Project Initialization. Only verified, source-backed facts are
> recorded here. Legacy performance values (AUC scores, throughput percentages, quality-cost claims)
> are explicitly excluded because they derive from contaminated evidence (see `project_knowledge.md`
> §5 Invalid Assumptions). New facts are added only as they pass through the evidence pipeline:
> Reality Gate → experiment → independent recomputation → claim ledger.

---

## Key Fact: Symbol Count
anchor: symbols
expected_value: 5
tolerance: 0
context: Five cryptocurrency trading pairs observed in the local archive directory structure. Exact symbols to be confirmed and certified in Chunk 03 Reality Gate. Preliminary observation: BTCUSDT, ETHUSDT, SOLUSDT, ADAUSDT, XRPUSDT.

## Key Fact: Date Range Days
anchor: trading days
expected_value: 31
tolerance: 0
context: January 2024 (31 calendar days). 155 archive files observed (5 symbols × 31 days). Exact coverage and completeness to be verified against official Binance archive listing in Chunk 03.

## Key Fact: Archive File Count
anchor: archive
expected_value: 155
tolerance: 0
context: 155 daily ZIP archives observed in the local data directory across 5 symbols and 31 days. Not yet verified against official checksums. Certified count will be established in Chunk 03.

## Key Fact: Legacy Processed Row Count
anchor: processed rows
expected_value: 73830561
tolerance: 500000
context: Approximately 73,830,561 rows in legacy processed Parquet files. This count is from legacy processing that discarded trade identity fields and is NOT certified. The certified row count will be established after Chunk 03 re-processing with full record accounting. This value is recorded only as a baseline reference, not as a claim.

## Key Fact: Factory Version
anchor: Factory
expected_value: 2.2
tolerance: 0.01
context: Software Factory v2.2.0, pinned at Project Initialization. Self-check passed with zero implementation/specification drift findings and nine heuristic warnings (historical/example references).

## Key Fact: Legacy Commit Count
anchor: commits
expected_value: 33
tolerance: 0
context: 33 visible commits on the main branch at the legacy baseline (commit f73dc1e). This count is preserved as historical record and will grow during rehabilitation.

## Key Fact: Python Test Baseline
anchor: tests passed
expected_value: 97
tolerance: 0
context: 97 tests passed with 5 warnings in the legacy test run (168.38s). This is a behavioural baseline, NOT a scientific validation. Many tests use synthetic/random fixtures, and no clean-room dependency test exists. The number will change during rehabilitation as invalid tests are retired and new semantic tests are added. Do not cite "97 tests" as evidence of correctness.

---

> [!WARNING]
> **Facts NOT recorded here (and why):**
>
> - AUC-ROC values from legacy experiments → nonstandard metric, evaluation leakage, generated labels
> - Throughput improvement percentages → simulated queue model, not measured
> - "Zero quality cost" → non-significance ≠ equivalence; contradictory result files
> - DeLong test p-values → contradictory across result files; legacy pairing invalid
> - Processed data certification → no provenance manifest; TLS disabled; identity fields discarded
>
> These values are quarantined in `project/legacy_intake/`. They may re-enter `key_facts.md` only
> after passing through the full evidence pipeline in Chunks 03–09.
