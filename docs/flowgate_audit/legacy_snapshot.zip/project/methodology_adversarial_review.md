# Methodology Adversarial Review (MAR)

Status: Created at Project Initialization. Reviewed at every Chunk Review.

**Review type:** Same-session self-adversarial review (Architect reviewing own founding artifacts)  
**Disclosure:** Per Factory v2.2.0 C55, this MAR is performed by the same Architect session that created the founding documents. This limitation is disclosed. An independent review at Chunk 02 is strongly recommended.

---

## MAR Gate 1 — Data Authenticity and Provenance

**Question:** Can every empirical input be traced to an authentic, independently verifiable source?

**Assessment:** CONDITIONAL PASS

**Evidence:**
- The project intends to use Binance public aggregate trade data, which is a real, publicly documented data source with an official repository (https://github.com/binance/binance-public-data) and published checksum files.
- However, the **current** local data is not provenance-certified:
  - No acquisition manifest exists
  - TLS verification was disabled during legacy acquisition
  - Official checksums were never retrieved or verified
  - Trade identity fields were discarded before duplicate resolution (may collapse distinct trades)
- The rehabilitation plan correctly identifies this gap and gates all experiments behind a Reality Gate (Chunk 03)

**Conditions for PASS:**
1. Chunk 03 must re-acquire or re-verify every archive against official Binance checksums
2. Full acquisition provenance must be recorded per INV-PROV-001
3. Reprocessing must retain trade identity fields through duplicate resolution
4. Reality Gate must explicitly PASS before any experiment

**Risk if unresolved:** CRITICAL — experiments use unverified data that may differ from official archives.

---

## MAR Gate 2 — Baseline Sufficiency

**Question:** Are baselines adequate for the claimed comparison level?

**Assessment:** CONDITIONAL PASS

**Evidence:**
- The founding artifacts specify:
  - B0 (fixed EMA, no shedding) — simplest reference
  - B1 (KAMA or literature-justified adaptive smoother) — signal-driven adaptation contrast
  - B2 (Butterworth or conventional filter) — standard filtering reference
  - A0 (load-adaptive, no shedding) — isolates adaptation
  - S0 (fixed, shedding only) — isolates shedding
  - AS (full system) — combined
- This matrix is structurally sufficient for T-CAUSAL claims (RQ4) if all variants are implemented and tested
- However, **baseline parameterisation** is not yet frozen:
  - Fair comparison requires matched effective cutoff/memory between a first-order and fourth-order filter
  - KAMA's ER period, fast/slow constants need literature justification
  - The current Butterworth uses `fs=100.0` which is an arbitrary physical sample rate

**Conditions for PASS:**
1. Chunk 04 must define and document fair comparison criteria
2. Butterworth parameterisation must use a justified timebase or be replaced with a fairer first-order baseline
3. At least 3 distinct baselines must survive Chunk 04 semantic validation
4. Literature justification for each baseline selection must be documented in Chunk 02

**Risk if unresolved:** HIGH — unfair comparisons invalidate T-COMP and T-CAUSAL claims.

---

## MAR Gate 3 — Statistical Power and Sample Size

**Question:** Is the sample size adequate for the claimed statistical conclusions?

**Assessment:** CONDITIONAL PASS

**Evidence:**
- Available data: 5 symbols × 31 days = 155 potential asset-days
- After temporal partitioning (training/calibration/evaluation), the evaluation set will be smaller
- With ~5 independent symbols, effective degrees of freedom are very limited for cross-symbol generalisation
- Runtime process runs can be repeated, but must model repeated measures appropriately
- Power analysis has not been performed (requires pilot variance from Chunk 07)

**Conditions for PASS:**
1. Chunk 06 must perform a power/sensitivity analysis based on actual pilot variance
2. If power is inadequate for T-COMP/T-CAUSAL, claims must be narrowed to T-DESC or descriptive case study
3. The project must not inflate sample size through pseudo-replication (seeds, resampling)
4. Statistical models must account for clustering by symbol and repeated measures across days

**Risk if unresolved:** HIGH — underpowered comparisons produce unreliable conclusions; positive results may be false positives.

---

## MAR Gate 4 — Timebase Validity

**Question:** Is the timebase well-defined and consistently applied?

**Assessment:** CONDITIONAL PASS (strong concern)

**Evidence:**
- Trade data arrives at irregular intervals with no inherent fixed sample rate
- Legacy code uses `fs=100.0` in Butterworth and `fs=1` implicitly elsewhere — both are arbitrary
- No explicit decision exists on event-time vs. physical-time analysis
- The rehabilitation plan correctly identifies this (§5.6) and defers the decision to Chunk 04

**Conditions for PASS:**
1. Chunk 04 must explicitly choose and document one of:
   - (a) Fixed-bin aggregation with declared bin size, explicit empty-bin handling, and justified effective sample rate
   - (b) Time-aware coefficient mapping (`α_i = 1 − exp(−Δt_i / τ_i)`) with analysis appropriate to irregular samples
2. No physical-frequency claim (Hz, seconds, Nyquist) may appear without a valid timebase
3. Hardcoded arbitrary `fs` values must be removed from all authoritative paths
4. INV-TIME-001 enforcement must be verified by tests

**Risk if unresolved:** HIGH — frequency/time claims are meaningless; comparative analysis may be invalid.

---

## MAR Gate 5 — Venue Publication Alignment

**Question:** Does the methodology align with the target venue's expectations and recent publications?

**Assessment:** CONDITIONAL PASS (acknowledged mismatch)

**Evidence:**
- **Target venue:** JIST (Journal of Institute of Science and Technology), a multidisciplinary science journal
- **Venue scope:** Covers computer science among other disciplines, so the topic is within scope
- **Venue alignment gap:** JIST does not typically publish DSP or adaptive filtering work. Recent volumes feature materials science, environmental science, computational chemistry, and biological sciences
- **Recent publications table:** NOT YET POPULATED — requires Chunk 02 access to NepJOL to identify and read 3 actual recent papers
- **Formatting requirements:** Verified (Times New Roman, 4,000–7,000 words, British English, A4)

**Conditions for PASS:**
1. Chunk 02 must identify and read ≥3 recent JIST papers in computational/applied science
2. Methodology and presentation must be adapted for a general science audience (clear DSP exposition)
3. If the venue mismatch is too severe (no reviewer competence, scope rejection likely), the Human should consider an alternative venue
4. The writing should not assume DSP expertise in reviewers

**Risk if unresolved:** MEDIUM — paper may be desk-rejected or assigned to non-expert reviewers. The scientific rigour is not affected by venue choice, but communication strategy must match the audience.

---

## MAR Gate 6 — Assumption Stress Testing

**Question:** What happens if key assumptions fail?

**Assessment:** PASS

**Evidence:**
- The founding artifacts explicitly classify assumptions as Verified, Hypothesis, or Invalid
- Each hypothesis has a verification plan and timeline
- Failure paths are documented:
  - No real labels → remove detection claims (Path C in venue_requirements.md)
  - No resource benefit → negative result (valid scientific outcome)
  - Fidelity margin exceeded → trade-off conclusion (no "zero quality cost")
  - Data not authentic → re-acquire or BLOCKED
  - Numba not beneficial → remove dependency
- Falsification criteria are pre-registered in `venue_requirements.md`
- The rehabilitation plan explicitly states all negative outcomes are acceptable

**No conditions — this gate passes.**

---

## MAR Gate 7 — Negative-Result Contingency

**Question:** Is the project publishable if the primary hypothesis fails?

**Assessment:** PASS

**Evidence:**
- The project has a clear title ladder (Chunk 02 will formalise):
  - **Conservative:** "Load-Driven Time-Varying IIR Filtering for Stream Processing: A Measured Comparison" (pure DSP/runtime study, no detection claims)
  - **Stronger (gated):** Adds "with Anomaly Detection Evaluation" only if real labels pass feasibility
  - **Strongest (gated):** Adds causal attribution only if ablation passes
- All of the following are explicitly acceptable outcomes:
  - Adaptation + shedding improves resources within fidelity margin → positive result
  - Improves resources but fails fidelity margin → trade-off conclusion
  - No resource improvement after overhead → negative result
  - Baselines dominate → negative result
  - Labels too sparse → narrowed scope
  - Full negative result → honest report of a null finding
- The venue (JIST) publishes research articles, not only positive results
- A rigorous DSP/runtime comparison on authentic data is publishable regardless of which method "wins"

**No conditions — this gate passes.**

---

## Hostile Reviewer Simulation

### Attack 1: "Your data provenance is absent — how do I know these are real Binance trades and not fabricated?"

**Defence:** The legacy data is currently quarantined (INV-HIST-001). Chunk 03 will re-acquire or re-verify every archive against official Binance checksums, create a full acquisition provenance manifest, and require the Reality Gate to PASS before any experiment uses the data. If verification fails, the project blocks rather than substitutes.

**Residual risk:** Binance may change their archive format, URLs, or checksum availability. The fail-closed response (INV-DATA-002) prevents silent substitution.

### Attack 2: "Your sample size is only 5 symbols × 31 days — this is tiny. How can you generalise?"

**Defence:** The founding artifacts acknowledge this limitation explicitly. The project does not claim cross-market generalisation. Statistical models will account for clustering by symbol. Power analysis (Chunk 06/07) will determine what effect sizes are detectable with this sample, and claims will be narrowed if power is inadequate. The project's scope statement explicitly limits generalisability to the observed dataset.

**Residual risk:** Reviewers may consider the sample inherently too small for any comparative claim. The mitigation is honest reporting of effect sizes with uncertainty intervals and explicit acknowledgement that results are limited to the observed market/period.

### Attack 3: "You compare a first-order adaptive filter to a fourth-order Butterworth — that's not a fair comparison."

**Defence:** The legacy Butterworth parameterisation (`order=4, cutoff_hz=1.0, fs=100.0`) is acknowledged as unfair in the rehabilitation plan (§5.6). Chunk 04 must define fair comparison criteria (equivalent effective cutoff, equivalent memory, order/latency constraints) and either re-parameterise the Butterworth fairly or replace it with a more appropriate first-order baseline. The comparison is not valid until the Chunk 04 baseline-matching contract is satisfied.

**Residual risk:** Any multi-order baseline comparison will require careful justification. The ablation matrix (B0/A0/S0/AS) provides within-order comparisons that avoid this issue entirely.

### Attack 4: "Your 'load-adaptive' filter just reduces α when the queue is full — but reducing α doesn't save computation. The savings come from shedding records, not from changing the coefficient."

**Defence:** This is the strongest attack and is explicitly addressed in the founding artifacts. RQ4 requires a factorial ablation separating adaptation (A0) from shedding (S0) from the combined system (AS). If the ablation shows that shedding alone achieves equivalent resource benefit, the attribution claim will be narrowed to credit shedding, not adaptation. The rehabilitation plan (§5.6) already identifies this: "changing α does not itself reduce arithmetic cost; the resource claim arises from shedding/skipping behavior and must be separated from filter adaptation." This is pre-registered as a falsification criterion.

**Residual risk:** If adaptation provides no independent resource benefit, the conceptual novelty is diminished. The project accepts this as a valid negative finding.

### Attack 5: "You claim 'measured runtime' but your replay is not truly live — you control the arrival schedule."

**Defence:** The project never claims live operation. All evidence uses historical replay, which is explicitly labelled. The replay schedule is derived from authentic recorded timestamps with a documented compression factor (if any). The comparison is valid because all methods receive the identical replay schedule (open-loop) or run under controlled conditions (closed-loop). The architecture explicitly forbids calling replay "live" (INV-SEC-001, venue_requirements.md title/claim conventions). Runtime telemetry (queue depth, consumer lag, CPU time, RSS) is measured from actual processes, not simulated.

**Residual risk:** Replay-based conclusions do not automatically transfer to production deployment with genuine live streams. This limitation is documented and the scope is explicitly bounded to "measured replay" rather than "production performance."

---

## MAR Summary

| Gate | Verdict | Blocking? |
|---|---|---|
| 1 — Data Authenticity | CONDITIONAL PASS | Blocks experiments (not Chunk 01) |
| 2 — Baseline Sufficiency | CONDITIONAL PASS | Blocks T-COMP/T-CAUSAL claims |
| 3 — Statistical Power | CONDITIONAL PASS | Blocks comparative conclusions |
| 4 — Timebase Validity | CONDITIONAL PASS | Blocks DSP claims |
| 5 — Venue Alignment | CONDITIONAL PASS | Blocks manuscript formatting |
| 6 — Assumption Stress | PASS | — |
| 7 — Negative-Result | PASS | — |

**Overall MAR verdict:** CONDITIONAL PASS — no gate blocks Chunk 01 (repository rehabilitation). Gates 1–5 must resolve to PASS by their respective chunks before comparative evidence enters the claim ledger. This is the expected state at Project Initialisation for a rehabilitation project.

**Next MAR review:** End of Chunk 02, with venue publications populated, research questions frozen, and label feasibility decided.
