# Architecture

Status: Frozen File. Created at Project Initialization. Amended only via Architecture Amendment.

---

## System Overview

FlowGate is a research software system for investigating load-driven adaptive IIR filtering on authentic financial data streams. The architecture separates concerns into five core domains: DSP core, data management, runtime infrastructure, evaluation, and reporting. Each domain enforces strict boundaries to prevent evidence contamination, ensure reproducibility, and maintain clean dependency relationships.

The system operates in two primary modes:

1. **Offline analysis:** process authentic recorded data through filter variants, collect metrics, and generate verified reports.
2. **Replay runtime:** replay authentic arrival schedules through a bounded-queue pipeline with actual execution telemetry.

An optional historical-replay application (Chunk 10) may provide a web-based visualisation if the scientific pipeline is stable.

## Architectural Principles

| ID | Principle | Enforcement |
|---|---|---|
| AP-001 | Evidence boundary: only `source/` is authoritative; legacy code is unreachable | Import-boundary test; static audit |
| AP-002 | Fail-closed error handling: no silent substitution or swallowed exceptions in evidence paths | Lint-contract; negative tests |
| AP-003 | Data provenance chain: every empirical input has a manifest → checksum → transformation → run → claim path | Schema validation; Reality Gate |
| AP-004 | Immutable runs: outputs are write-once per run ID | Run-manifest schema; filesystem checks |
| AP-005 | Typed outcomes: every operation returns a structured result, never bare success/failure | Exception hierarchy; typed returns |
| AP-006 | Component isolation: DSP core has no data/runtime/evaluation dependencies | Import graph test |
| AP-007 | Deterministic builds: locked dependencies, content-addressed outputs, no ambient state | Lock file; clean-clone CI |

## Component Architecture

```text
source/
├── src/load_adaptive_iir/
│   ├── __init__.py
│   ├── cli.py                    ── CLI entry points (typed commands)
│   ├── core/                     ── Pure DSP (filters, z-domain, stability)
│   │   ├── __init__.py
│   │   ├── filters.py            ── Fixed EMA, load-adaptive EMA, KAMA
│   │   ├── numba_filters.py      ── JIT kernels (if retained after parity check)
│   │   ├── zdomain.py            ── Analytical z-domain properties
│   │   └── reference.py          ── Independent reference implementations
│   ├── data/                     ── Acquisition + provenance + transformation
│   │   ├── __init__.py
│   │   ├── acquire.py            ── Fail-closed HTTPS acquisition
│   │   ├── validate.py           ── Checksum, schema, monotonicity checks
│   │   ├── transform.py          ── Deterministic raw→processed pipeline
│   │   ├── manifest.py           ── Data/acquisition manifest schemas
│   │   └── reality_gate.py       ── Programmatic Reality Gate checks
│   ├── runtime/                  ── Bounded-queue replay + telemetry
│   │   ├── __init__.py
│   │   ├── pipeline.py           ── Producer/queue/consumer/downstream
│   │   ├── replay.py             ── Authentic arrival schedule replay
│   │   ├── shedding.py           ── Load-shedding policies
│   │   ├── telemetry.py          ── Structured trace event capture
│   │   └── accounting.py         ── Record-level fate tracking
│   ├── evaluation/               ── Metrics, statistics, protocol
│   │   ├── __init__.py
│   │   ├── metrics.py            ── Standard metric implementations
│   │   ├── statistics.py         ── Statistical tests + CI methods
│   │   ├── protocol.py           ── Temporal partitioning + unit management
│   │   ├── verifier.py           ── Independent metric recomputation
│   │   └── claim_ledger.py       ── Claim registration + status tracking
│   └── reporting/                ── Artifact-consuming report generation
│       ├── __init__.py
│       ├── figures.py            ── Figure generation from verified aggregates
│       ├── tables.py             ── Table generation from verified aggregates
│       └── manuscript.py         ── Claim-ledger-driven text assembly
├── tests/
│   ├── unit/                     ── Deterministic branch/type/error tests
│   ├── semantic/                 ── Analytically derived DSP tests
│   ├── integration/              ── Component-join tests with mocks
│   ├── scientific/               ── Protocol invariant + leakage tests
│   └── fixtures/canonical/       ── Non-empirical mathematical test vectors
├── configs/
│   ├── acquisition/              ── Data source + checksum specifications
│   ├── experiments/              ── Frozen experiment configurations
│   └── schemas/                  ── JSON schemas for manifests + configs
├── scripts/
│   ├── acquire/                  ── Data acquisition entry points
│   ├── verify/                   ── Verification + audit scripts
│   ├── reproduce/                ── Clean-room reproduction scripts
│   └── release/                  ── Release preparation + checks
├── artifacts/
│   ├── README.md                 ── Artifact policy
│   └── release/                  ── Curated, verified small release evidence
├── docs/
│   ├── manuscript/               ── Publication source (LaTeX/Markdown)
│   ├── ku_report/                ── KU project report source
│   ├── reproducibility/          ── Reproduction guide
│   └── decisions/                ── Architecture Decision Records
└── app/                          ── Optional (Chunk 10 only)
    ├── api/                      ── Historical replay API
    └── web/                      ── Web frontend
```

## Dependency Rules

### Internal dependency graph (allowed imports)

```text
core/          ← no internal dependencies (pure DSP math)
data/          ← core/ (for manifest schemas only, not filter logic)
runtime/       ← core/, data/ (for manifest refs)
evaluation/    ← core/ (for metric defs), data/ (for manifest refs)
reporting/     ← evaluation/ (for verified aggregates), data/ (for manifest refs)
cli.py         ← all components (orchestration only)
app/           ← runtime/, evaluation/, reporting/ (if retained)
```

### Forbidden dependencies

- `core/` must not import `data/`, `runtime/`, `evaluation/`, or `reporting/`
- `evaluation/` must not import `runtime/` (evaluation is replay-agnostic)
- No component may import from legacy paths (`load-adaptive-iir/src/`)
- No experiment/report entry point may import test fixtures
- No component may import `numpy.random` for evidence generation (only for declared stochastic algorithms with recorded seeds)

### External dependencies

| Package | Purpose | Version policy | Retention condition |
|---|---|---|---|
| numpy | Array computation | Pinned major.minor | Always |
| scipy | Signal processing, statistics | Pinned major.minor | Always |
| numba | JIT-compiled kernels | Pinned major.minor | Only if parity + measured benefit verified (Chunk 04) |
| matplotlib | Figure generation | Pinned major.minor | Always |
| pandas | Data I/O (Parquet) | Pinned major.minor | Always |
| rrcf | Robust Random Cut Forest | Pinned | Only if baseline decision retains it (Chunk 06) |
| pytest | Testing | Dev dependency | Always |
| mypy | Type checking | Dev dependency | Always |
| ruff | Linting + formatting | Dev dependency | Always |

All versions locked via `uv.lock` or equivalent deterministic lock file.

## Data Flow

```text
Official Binance Archive  ──HTTPS+TLS──►  acquire.py
         │                                    │
         │ official .CHECKSUM                 │ acquisition_provenance.json
         ▼                                    ▼
    Checksum Verify  ───────────────►  data/raw/ (immutable)
                                          │
                                          │ validate.py (schema, monotonic, domain)
                                          ▼
                                     data/staged/ (validated decompression)
                                          │
                                          │ transform.py (deterministic, content-addressed)
                                          ▼
                                     data/processed/ (analysis-ready)
                                          │
                                          │ data_manifest.json + Reality Gate
                                          ▼
                                     VerifiedDatasetRef (typed handle)
                                          │
                        ┌─────────────────┼─────────────────┐
                        ▼                 ▼                 ▼
                   Offline Analysis   Replay Pipeline   Evaluation Protocol
                        │                 │                 │
                        │    telemetry    │    metrics      │
                        ▼                 ▼                 ▼
                   artifacts/runs/<run-id>/
                        │
                        │ independent recomputation
                        ▼
                   claim_ledger.csv
                        │
                        │ verified aggregates only
                        ▼
                   Manuscript / Report / Figures / Tables
```

## Error Boundaries

| Boundary | Behaviour | Example |
|---|---|---|
| Data acquisition | Fail-closed → `BlockedExternalDependency` | Checksum mismatch, TLS failure, HTTP error |
| Data transformation | Fail-closed → row-accounting imbalance error | Schema mismatch, duplicate-identity conflict |
| Reality Gate | FAIL → no downstream experiment permitted | Missing provenance, incomplete coverage |
| Experiment execution | Fail → attempt recorded with failure reason; no overwrite | Process crash, resource exhaustion |
| Metric computation | Fail → degenerate-detection error | All-equal predictions, NaN propagation |
| Report generation | Fail → missing claim-ledger entry error | Unverified metric, missing artifact |

## Evidence Boundary

The repository has exactly one authoritative code surface: `source/`. The following are explicitly **not** authoritative:

- `load-adaptive-iir/` (legacy implementation — quarantined)
- `project/legacy_intake/` (historical audit material)
- `Isolated-Backend/` (legacy demo — quarantined)
- `React-Frontend/` (legacy UI — quarantined)
- Any file under `project/` (Factory-private planning/evidence)

## Future Extension Points

| Point | Description | Gate |
|---|---|---|
| Multi-pole adaptive filters | Extend `core/` with higher-order variants | New Architecture Amendment |
| Cross-market generalisation | Add acquisition configs for additional exchanges | New data-rights review + Reality Gate |
| Historical replay app | `app/api/` + `app/web/` serving verified artifacts | Chunk 10 entry gate (Chunk 09 stable) |
| Live streaming connector | Separate from historical replay; never labelled "LIVE" for historical data | Explicit scope expansion + security review |
