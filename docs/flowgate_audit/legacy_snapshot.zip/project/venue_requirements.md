# Venue Requirements

Status: Frozen File (same policy as architecture.md). Created at Project Initialization. Reviewed at MAR. Checked for drift at every Chunk Review.

---

## Target Venue

**Journal of Institute of Science and Technology (JIST)** — Institute of Science and Technology (IOST), Tribhuvan University, Nepal.

- **Type:** Peer-reviewed, multidisciplinary, open-access
- **Publisher:** IOST, Tribhuvan University
- **Index:** Nepal Journals Online (NepJOL)
- **URL:** https://www.nepjol.info/index.php/JIST
- **Scope:** Mathematics, Physics, Chemistry, Computer Science, Environmental Science, Botany, Microbiology, Statistics, Geology, and related applied sciences
- **Language:** English (preferably British)
- **Format:** Times New Roman; Title 12pt uppercase; Subtitles 10pt sentence case; Body 10pt; Table/figure captions 9.5pt bold
- **Layout:** Double-spaced, ≥3cm margins, A4 paper
- **Length:** Research articles 4,000–7,000 words (or 5–10 pages including figures/tables)
- **Page numbers:** Required on every page
- **Section numbering:** Do not number titles and subtitles
- **Figures/Tables:** Inserted in main text at appropriate positions; high-quality JPEG/TIFF submitted separately
- **Submission:** Online via NepJOL portal; email (journal@iost.tu.edu.np) as fallback
- **Review:** Peer-reviewed
- **Access:** Open access

> [!IMPORTANT]
> **Venue fit disclosure:** JIST is a multidisciplinary science journal. Recent volumes (29–31, 2024–2026) are dominated by materials science, environmental science, computational chemistry (DFT), and biological sciences. Digital signal processing and adaptive filtering papers are atypical for this venue. The project's computational/applied science framing (time-series processing, algorithm comparison, measured runtime analysis) falls within the journal's computer science scope, but the reviewer pool may not have deep DSP expertise. This is documented honestly and influences the writing approach: clear exposition of DSP concepts for a general science audience.

## Recent Venue Publications (minimum 3)

> [!NOTE]
> Because JIST does not routinely publish DSP or adaptive filtering work, the closest relevant papers from recent volumes are selected. These inform realistic baseline, sample-size, and methodology expectations for this venue rather than providing DSP-specific precedent.

| Paper | Year | Methodology | Baselines used | Sample size | Key convention worth matching |
|---|---|---|---|---|---|
| **PENDING — Chunk 02 literature verification required.** Literature search of JIST volumes 29–31 for computational/applied science papers will be conducted with access to NepJOL. Three actual papers will be read and documented here. | — | — | — | — | — |
| — | — | — | — | — | — |
| — | — | — | — | — | — |

**MAR-5 status:** CONDITIONAL PASS — venue publications table is structurally present but not yet populated with verified papers. Chunk 02 must complete this before any comparative claim is finalised. The table cannot be filled with fabricated citations.

## Minimum Expected Baselines For This Venue

Given the project's computational comparison methodology:

1. **Fixed-coefficient reference:** Fixed EMA (no adaptation, no shedding) — the simplest no-adaptation baseline
2. **Signal-driven adaptive baseline:** KAMA or equivalent literature-justified adaptive smoother — tests whether adaptation benefit is specific to load-driven control vs. general signal-driven adaptation
3. **Conventional filter baseline:** Butterworth or equivalent, with fair parameterisation (matched effective cutoff, acknowledged order/latency differences) — provides a standard filtering reference

For T-CAUSAL attribution claims (RQ4), at least three baselines plus ablation variants are required:
- B0: Fixed coefficient, no shedding
- B1: Fair conventional baseline, no shedding
- B2/A0: Adaptation-only variants
- S0: Shedding-only variant
- AS: Full system (adaptation + shedding)

## Minimum Expected Sample Sizes

Grounded in available authentic data:

- **Signal/evaluation units (asset-days):** ≤155 (5 symbols × 31 days) — actual independent count depends on experimental-unit definition and any temporal grouping
- **Runtime experimental units (process runs):** TBD after power analysis on pilot variance (Chunk 06/07) — minimum 10 paired runs per method comparison, pending power calculation
- **Real labelled events:** UNKNOWN — contingent on Chunk 02 feasibility gate. If zero suitable events, label-dependent claims are removed entirely. If < 10 events, only descriptive case study is possible.

> [!WARNING]
> With only 5 symbols and 31 days, the independent evaluation-unit count is small. The project must not inflate this by treating resampled or seed-duplicated runs as independent observations. Statistical conclusions must reflect the actual number of independent units and use appropriate grouped/repeated-measures models.

## Statistical Method Requirement

| Claim type | Research question | Statistical method |
|---|---|---|
| T-DESC (filter behaviour) | RQ1: smoothing/delay/response differences | Descriptive statistics with uncertainty intervals; no significance test required |
| T-COMP (runtime comparison) | RQ2: queue stability, latency, CPU, memory | Paired comparison (within asset-day) with bootstrap or permutation CI; multiplicity correction for secondary outcomes |
| T-COMP (fidelity margin) | RQ3: downstream fidelity within margin | Pre-specified non-inferiority or equivalence test with domain-justified margin |
| T-CAUSAL (attribution) | RQ4: which component explains the change | Factorial/ablation comparison with ≥3 baselines; interaction effects; cluster-robust or mixed-effects model for repeated measures |

## Minimum Meaningful Effect Size

| Core metric | Below-chance threshold | Minimum meaningful value | Basis |
|---|---|---|---|
| CPU time reduction per record | 0% (no improvement) | TBD — must be set after pilot variance measurement (Chunk 07) | Practical threshold: improvement must exceed instrumentation overhead, measured via no-op/reference consumer |
| Queue stability (max occupancy reduction) | 0% | TBD — domain-justified from pilot telemetry | Improvement must be observable above natural run-to-run variance |
| Fidelity metric (TBD — lag, deviation, or event metric) | Depends on metric choice | TBD — predeclared margin in Chunk 06 | Non-inferiority margin must be domain-justified, not arbitrary |

> [!NOTE]
> All "TBD" entries are honest acknowledgements that meaningful thresholds cannot be set before pilot data provides variance estimates. They will be frozen in Chunk 06 before final experiments (Chunk 08). Setting arbitrary thresholds now would violate the principle that claims follow evidence.

## Pre-Registered Falsification Criteria

| Hypothesis | Falsifying result | Action if falsified |
|---|---|---|
| Load-driven adaptation reduces runtime resource consumption | CPU time or queue stability not improved beyond instrumentation overhead on ≥3 asset-days in pilot | Reframe as negative/descriptive result; do not search for favourable windows |
| Resource benefit persists within fidelity margin | Fidelity metric exceeds pre-specified non-inferiority margin | Report as a trade-off finding; remove "no quality cost" language |
| Coefficient adaptation (not shedding) explains the benefit | Ablation shows shedding-only variant achieves equivalent or better resource benefit | Narrow attribution; credit shedding, not adaptation; do not combine into misleading composite |
| Authentic labelled events support detection evaluation | Chunk 02 finds < 3 usable real events with alignment, legal use, and temporal separation | Remove detection claims; study filter/runtime behaviour only |

## Required Ablation Types

Applicable to this project's architecture:

- **Component ablation:** Separate coefficient adaptation (A0) from load shedding (S0) from the combined system (AS) — this is the primary ablation
- **Baseline ablation:** Fixed vs. signal-driven vs. load-driven adaptation
- **Hyperparameter sensitivity:** α_min, α_max, Δα_max (slew-rate limit), queue threshold for shedding, ER period for KAMA, Butterworth order/cutoff — all named, all require sensitivity analysis

## Expected Data Properties (feeds Reality Gate)

| Property | Expected value | Basis | Status |
|---|---|---|---|
| Missing-data / gap rate | UNKNOWN — no published gap-rate statistic for Binance aggregate trades in January 2024 | No (a)/(b)/(c) basis available | UNKNOWN — Reality Gate will use conservative defaults; flagged as MAR-6 finding |
| Temporal coverage | 2024-01-01 to 2024-01-31 UTC | Observed archive file names | Unverified against official archive listing |
| Symbols present | ~5 (BTCUSDT, ETHUSDT, SOLUSDT, ADAUSDT, XRPUSDT) | Observed directory structure | Unverified; exact list must be confirmed |
| Expected daily archives per symbol | 31 | Calendar days in January 2024 | Unverified |
| Timestamp monotonicity | Monotonically non-decreasing within each daily file | Standard expectation for trade-timestamped data | Unverified — must be checked in Chunk 03 |
| Trade volume per day | UNKNOWN | No published baseline for exact daily aggregate-trade counts | UNKNOWN — Reality Gate will flag suspiciously uniform counts |
| Suspiciously good properties | Uniform daily file sizes, zero gaps, perfectly round row counts | These would suggest fabricated or pre-filtered data | Red flag if observed — requires investigation |

## Title/Claim Conventions

| Anticipated title adjective | Required validating test |
|---|---|
| "Load-adaptive" or "load-driven" | Must demonstrate coefficient changes in response to measured (not simulated) queue load |
| "Real-time" | FORBIDDEN unless actual latency measurement under realistic load meets a pre-specified threshold; historical replay is not "real-time" |
| "Anomaly detection" | Only if real labelled events pass Chunk 02 feasibility gate AND detection evaluation passes with authentic labels |
| "Zero quality cost" or "no quality cost" | Only if a pre-registered equivalence/non-inferiority test passes with a domain-justified margin |
| "Efficient" or "resource-efficient" | Must show measured (not simulated) resource reduction with attribution to the specific mechanism |

## Release Artifact Notes

Known items that must not appear in release:
- Local machine paths (e.g., `/Users/adi/Desktop/DSP Mini Project/`)
- Placeholder author information (`Aditya [Surname]`, `yourname@ku.edu.np`)
- Machine identity (hostname, MAC address)
- API keys or credentials
- Development CORS settings (`*` with credentials)
- WebSocket `localhost` addresses
- Factory-private paths (`factory/`, `project/`)
- `.DS_Store` and OS metadata
