# Project Knowledge

Status: Frozen-policy file (amended only via Architecture Amendment). Created at Project Initialization.

---

## 1. Glossary

### DSP Terms

| Term | Definition | Notes |
|---|---|---|
| IIR filter | Infinite Impulse Response filter; output depends on both current input and past outputs via feedback coefficients | The core filter type in this project; all variants are first-order (single-pole) |
| EMA | Exponential Moving Average; a first-order IIR low-pass filter: `y[n] = α·x[n] + (1−α)·y[n−1]` | Fixed-coefficient baseline; equivalent to a single-pole filter with pole at `p = 1 − α` |
| Alpha (α) | Smoothing coefficient in a first-order IIR filter; `0 < α ≤ 1` | Higher α → more weight on current sample → faster response → less smoothing. **α is the smoothing coefficient; the pole is `p = 1 − α`** |
| Pole (p) | Location of the filter's pole in the z-domain: `p = 1 − α` for first-order EMA | `0 ≤ p < 1` for stability. Legacy code sometimes confuses α and pole — this project uses explicit terminology |
| KAMA | Kaufman's Adaptive Moving Average; adapts its smoothing constant based on an efficiency ratio (direction/volatility) | Signal-driven adaptation (responds to price behaviour); contrasts with load-driven adaptation |
| Efficiency Ratio (ER) | `|price_change| / sum(|period_changes|)` over a window | ER → 1 for trending markets (fast smoothing); ER → 0 for noisy markets (slow smoothing) |
| Smoothing Constant (SC) | KAMA's adaptive α: `SC = [ER × (fast_SC − slow_SC) + slow_SC]²` | Squared to compress the range toward the slow end |
| Load-adaptive EMA | The proposed method: `α[n] = α_max − (α_max − α_min) · L[n]` with slew-rate limiting | Adapts based on normalised queue load L[n], not signal properties; widens window under backpressure |
| Slew-rate limit | Constraint `|α[n] − α[n−1]| ≤ Δα_max` per step | Prevents abrupt coefficient changes that could cause transients |
| Butterworth filter | Maximally-flat magnitude response IIR filter; typically higher-order | Used as a conventional baseline; fair comparison requires matching effective cutoff and acknowledging order/latency differences |
| Bilinear transform | Method for converting analog filter designs to digital; `s → 2/T · (z−1)/(z+1)` | Used in the current Butterworth implementation; requires a meaningful sample rate |
| Group delay | Frequency-dependent delay through a filter; for first-order EMA at DC: `τ_g(0) = (1−α)/α` | Measure of filter latency |
| BIBO stability | Bounded-Input, Bounded-Output stability; guaranteed for first-order if `|p| < 1` per step (frozen-time) | A per-step frozen-time bound is necessary but may not be sufficient for global stability of a time-varying system — separate analysis required |
| Timebase | Whether the filter's discrete index represents event-count or physical time | Critical decision (Chunk 04): event-time analysis vs. physical-time with explicit Δt handling |

### Runtime/Streaming Terms

| Term | Definition | Notes |
|---|---|---|
| Backpressure | Condition where a consumer cannot keep up with the producer's input rate | The load signal driving adaptive coefficient selection |
| Queue depth | Number of items currently in the bounded processing queue | Measured from the actual process, not simulated |
| Consumer lag | Time difference between the most recent queued item and the most recently processed item | Telemetry metric for runtime evaluation |
| Load shedding | Deliberately dropping or deferring records when queue pressure exceeds a threshold | Distinct from coefficient adaptation; both contribute to resource savings but must be measured separately |
| Replay | Re-execution of authentic recorded arrival schedules through the processing pipeline | Always historical; never labelled "live" |
| Open-loop replay | Replay an immutable recorded schedule identically across all methods for paired comparison | Ensures comparable input across methods |
| Closed-loop replay | Run complete systems with randomised method order, warm-up/cooldown, resource isolation | Measures actual system-level performance |

### Statistical/Evaluation Terms

| Term | Definition | Notes |
|---|---|---|
| Experimental unit | The independent unit of observation (e.g., asset-day, event episode, process run) | Must be defined before execution; duplicates/resamples are never independent units |
| Temporal partitioning | Separation of data into non-overlapping training/calibration/pilot/evaluation periods | INV-EVAL-001: calibration must never overlap evaluation |
| Equivalence test | Statistical test to show two methods perform within a pre-specified practical margin | Non-significance of a difference test does NOT establish equivalence |
| Non-inferiority | One-sided test showing a method is no worse than a reference by more than a margin | Requires a pre-specified, domain-justified margin |
| Claim ledger | Registry mapping every prospective public claim to its supporting evidence, statistical test, and approved wording | The single source of truth for what the manuscript may state |
| Reality Gate | Architect-performed verification that empirical data is authentic, complete, and correctly transformed | Must PASS before any experiment uses the data for evidence |

### Factory Terms

| Term | Definition | Notes |
|---|---|---|
| Chunk | A planned unit of work with explicit entry/exit criteria, contracts, and review | 12 chunks in the rehabilitation roadmap |
| Contract | A specific deliverable within a chunk, with owner, risk tier, claim tier, allowed files, and verification | Implementor executes one at a time; Architect reviews |
| Claim tier | Classification of evidence strength: NONE, T-DESC, T-COMP, T-CAUSAL | Higher tiers require more baselines, statistical rigour, and ablations |
| Gatekeeper | Factory's mechanical verification tool (`gatekeeper.py`) | Does not replace Architect's manual responsibilities |
| DROP_HERE / TAKE_THIS | Mailbox directories for Architect→Implementor (DROP_HERE) and Implementor→Architect (TAKE_THIS) file transfer | Ignored by outer repository |

---

## 2. Domain Knowledge

### IIR Filtering on Irregular Time Series

Financial market trade data arrives at irregular intervals. Applying discrete-time IIR filters (designed for uniform sampling) to such data requires one of two explicit strategies:

1. **Event-time analysis:** Each trade is one discrete step regardless of wall-clock time elapsed. Filter behaviour is analysed in terms of event count, not physical frequency. Conventional Hz-based frequency analysis is invalid without a meaningful sample rate.

2. **Physical-time analysis:** Aggregate trades into fixed time bins (e.g., 100ms, 1s), handle empty bins explicitly, and use the bin rate as the sample frequency. Alternatively, use time-aware coefficient mapping: `α_i = 1 − exp(−Δt_i / τ_i)` to handle variable inter-arrival times.

**Decision status:** UNRESOLVED — frozen in Chunk 04.

### Binance Aggregate Trade Data

- **Source:** Binance public data repository (https://data.binance.vision/)
- **Format:** Daily ZIP archives containing CSV with columns: `agg_trade_id`, `price`, `quantity`, `first_trade_id`, `last_trade_id`, `timestamp`, `is_buyer_maker`, `is_best_match`
- **Current coverage:** 5 symbols (likely BTCUSDT, ETHUSDT, SOLUSDT, ADAUSDT, XRPUSDT), 31 days (January 2024), 155 archives
- **Processed rows:** approximately 73,830,561 (legacy processing retained only `timestamp` and `price`, discarding trade identity fields)
- **Known issues:**
  - No acquisition provenance manifest exists
  - TLS verification was disabled in legacy acquisition code
  - Trade identity fields were discarded before duplicate resolution (may collapse distinct trades)
  - No official checksum verification was performed
  - Data redistribution rights are unreviewed

**Authenticity status:** QUARANTINED — requires re-verification against official checksums (Chunk 03).

### Load-Adaptive Filtering Concept

The core hypothesis: when a streaming system experiences backpressure (high queue depth), the filter coefficient α can be reduced (widening the smoothing window, reducing computational load on downstream processes) as a graceful degradation strategy. This is conceptually distinct from:

- **Signal-driven adaptation (KAMA):** adapts based on price behaviour (trending vs. noisy), independent of processing load
- **Pure load shedding:** drops records entirely, independent of filtering
- **Combined system:** both coefficient adaptation AND selective record shedding, requiring ablation to attribute observed benefits

**Key scientific question:** Does changing α actually reduce computational cost, or does the cost arise from shedding/skipping behaviour? These must be measured and attributed separately.

---

## 3. Datasets

### Primary Dataset: Binance Aggregate Trades (January 2024)

| Property | Value | Status |
|---|---|---|
| Provider | Binance | Verified (public data repository exists) |
| Data type | Aggregate trade records | Verified from schema |
| Symbols | 5 (exact list to be confirmed from archives) | Unverified |
| Date range | January 1–31, 2024 | Unverified |
| Archive count | 155 | Observed |
| Raw row count | Unknown (processed count: ~73.8M) | Unverified |
| Processed row count | ~73,830,561 | Observed (legacy processing, not certified) |
| Official checksums | Available (.CHECKSUM files) | Not yet retrieved or verified |
| Redistribution rights | Unreviewed | BLOCKED — requires Chunk 02 review |
| Acquisition provenance | None | Must be created in Chunk 03 |
| Reality Gate status | NOT PASSED | Blocks experimental use |

### Candidate Label Sources (Contingent — Chunk 02)

| Source | Type | Status |
|---|---|---|
| LOBSTER event type 7 (halt/resume) | Market halt events | Feasibility unassessed |
| Nasdaq historical halt data | Halt reason codes | Feasibility unassessed |

**Decision gate:** If no suitable real-label source passes feasibility in Chunk 02, all anomaly-detection evaluation claims are removed.

---

## 4. Standards and References

| Standard/Reference | Relevance | Status |
|---|---|---|
| DSP first-order IIR filter theory | Core mathematical foundation | Established; requires timebase-correct application |
| Kaufman's KAMA (1995, 2013) | Signal-driven adaptive baseline | Literature verification needed (Chunk 02) |
| DeLong et al. (1988) AUC comparison | Statistical comparison of ROC curves | Applicable only if ROC-AUC is a valid primary metric |
| Binance API documentation | Data source specification | Must be verified from primary source |
| JIST author guidelines | Publication formatting and requirements | Verified via NepJOL (2026 retrieval) |
| Software Factory v2.2.0 specification | Project governance | Pinned and operational |

---

## 5. Assumptions

### Verified

| ID | Assumption | Evidence |
|---|---|---|
| A-V-001 | Binance public data repository provides daily aggregate trade archives | Official documentation + observed archives |
| A-V-002 | The project uses Python as its primary implementation language | Existing codebase + repository structure |
| A-V-003 | Software Factory v2.2.0 is available and operational | Bootstrap completed; self-check passed |

### Hypotheses (require verification)

| ID | Assumption | Verification plan |
|---|---|---|
| A-H-001 | Load-driven coefficient adaptation provides measurable resource benefit | Chunk 05 measured telemetry + Chunk 08 final experiments |
| A-H-002 | The resource benefit persists within a predeclared fidelity margin | Chunk 06 equivalence/non-inferiority protocol + Chunk 09 analysis |
| A-H-003 | Authentic labels exist with sufficient coverage for detection evaluation | Chunk 02 feasibility gate |
| A-H-004 | The current local data matches official Binance archives | Chunk 03 checksum verification + Reality Gate |
| A-H-005 | Numba JIT provides measurable performance benefit for filter kernels | Chunk 04 parity check + benchmark |

### Invalid (legacy claims not supported by current evidence)

| ID | Legacy claim | Reason for invalidation |
|---|---|---|
| A-I-001 | "97 tests pass" validates the science | Tests use synthetic/random fixtures; no clean-room dependency test; no prevention of fallback to generated data |
| A-I-002 | AUC-ROC values from legacy experiments are valid | Nonstandard metric implementation; evaluation leakage; labels derived from the method under evaluation |
| A-I-003 | "Zero quality cost" is demonstrated | Non-significance ≠ equivalence; no predeclared margin; contradictory result files |
| A-I-004 | "+92.6% throughput improvement" is measured | Based on simulated queue/throughput model, not measured runtime |
| A-I-005 | The project is "100% complete" and "publication-ready" | Worktree is dirty; science contains multiple integrity defects; no clean-room reproduction |
| A-I-006 | 150 seeds = 150 independent trials | Pseudo-replication; ~96 unique asset-days; seeds reused across regimes |
| A-I-007 | Processed data (73.8M rows) is certified authentic | No provenance manifest; TLS disabled; identity fields discarded before dedup |
