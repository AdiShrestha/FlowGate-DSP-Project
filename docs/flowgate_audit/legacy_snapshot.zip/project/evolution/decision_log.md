# FlowGate Project Architecture & Evolution Decision Log

## Decision: C01-03 Legacy Quarantine Execution & Disposition Confirmation
- **Date:** 2026-09-01 08:44:03 UTC
- **Author:** Architect
- **Contract:** C01-03
- **Decision:** Executed quarantine of 11 legacy planning/prompt/review documents into `project/legacy_intake/` under 8 categories with SHA-256 validation and `LEGACY — NON-AUTHORITATIVE` tagging. Established explicit migration staging for C01-04 covering 5 core DSP modules and test suite with known-defect directives. Formally classified 9 synthetic generator/simulation scripts and 43 result files as `forbidden-evidence`.
- **Reason:** Enforce Invariant INV-DATA-001 (No Fabricated Evidence) and INV-HIST-001 (Legacy Material Quarantine) before authoritative migration begins.
- **Alternatives Considered:** Leaving legacy files in place without quarantine (rejected: risk of accidental import or evidence contamination).
- **Expected Effect:** Implementor in C01-04 has a crystal-clear, verified boundary and migration list to populate `source/` cleanly.
