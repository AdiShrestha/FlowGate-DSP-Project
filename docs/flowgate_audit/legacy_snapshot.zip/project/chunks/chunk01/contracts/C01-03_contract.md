# Contract C01-03 — Legacy Quarantine and File-by-File Disposition

## Contract ID
C01-03

## Objective
Separate what informs rehabilitation from what is allowed to ship. Apply the disposition matrix from the rehabilitation plan to every legacy file, preserving useful audit material in `project/legacy_intake/` while staging reusable code for migration in C01-04. No file is deleted; no legacy result enters the authoritative surface.

## Context
After C01-01's asset ledger classifies every file and C01-02 establishes the Factory structure, this contract executes the actual quarantine. This is the highest-risk contract in Chunk 01 because it involves moving user work and classifying evidence — errors here could lose intended user contributions or allow legacy contamination.

## Dependencies
- C01-01 (asset ledger must be complete with Human decisions resolved)
- C01-02 (Factory structure must exist for quarantine destinations)

## Risk Tier
High — user work and evidence classification involved. Architect specifies all dispositions; Implementor moves only explicitly approved paths.

## Implementation Owner
Architect specifies the disposition for each file/group. Implementor executes only approved moves.

## Scientific Claim Tier
NONE

## Allowed Files
- `project/legacy_intake/**`
- `project/chunks/chunk01/reports/C01-03/**`
- `project/chunks/chunk01/notes/**`

## Frozen Files
- `factory/**`
- `source/**` (not yet populated — C01-04's job)

## Inputs
- C01-01 asset ledger with Human decisions resolved
- Rehabilitation plan §10 disposition matrix
- Current working tree

## Outputs

### 1. Quarantine Index (`project/legacy_intake/quarantine_index.md`)
For each file moved to `project/legacy_intake/`, record:
- Original path
- Destination path in `project/legacy_intake/`
- Category: `documents/`, `manuscripts/`, `results_manifest/`, `reviews/`, `literature/`, `venue_inputs/`, `notes/`, `tools/`, `requirements/`
- Content hash (SHA-256)
- `LEGACY — NON-AUTHORITATIVE` label
- Why this file is preserved (audit value)

### 2. Quarantined Legacy Documents
Move the following to `project/legacy_intake/` (per rehabilitation plan §10):

| Source | Destination | Category |
|---|---|---|
| `build_mega_context.py` | `project/legacy_intake/tools/` | One-off context assembly |
| `dsp_project_build_prompt.md` | `project/legacy_intake/requirements/` | Historical specification input |
| `fix1.md` | `project/legacy_intake/notes/` | Legacy repair instructions |
| `mega_report_context.md` | `project/legacy_intake/documents/` | Generated narrative context |
| `project_context.md` | `project/legacy_intake/documents/` | Stale claims document |
| `study.md` | `project/legacy_intake/reviews/` | Adversarial observations |
| `load_adaptive_iir_literature_review.md` | `project/legacy_intake/literature/` | Literature summary (search seed only) |
| `report_v2.tex` | `project/legacy_intake/manuscripts/` | Legacy IEEE manuscript |
| `ku_format.md` | `project/legacy_intake/venue_inputs/` | KU formatting reference |
| `load-adaptive-iir/README.md` | `project/legacy_intake/documents/` | Legacy project README |
| `load-adaptive-iir/requirements.txt` | `project/legacy_intake/requirements/` | Legacy unpinned deps |

### 3. Migration Staging List (`project/legacy_intake/migration_staging.md`)
For each file staged for C01-04 migration, record:
- Original path
- Proposed `source/` destination (per architecture.md)
- Known semantic defects to mark (xfail/quarantine from authoritative entry points)
- Content hash for later verification

Files staged for migration (per rehabilitation plan §10):

| Source | Proposed Destination | Notes |
|---|---|---|
| `load-adaptive-iir/src/filters.py` | `source/src/load_adaptive_iir/core/filters.py` | Core DSP; semantic defects marked, not fixed |
| `load-adaptive-iir/src/numba_filters.py` | `source/src/load_adaptive_iir/core/numba_filters.py` | Retain only if parity verified |
| `load-adaptive-iir/src/zdomain_analysis.py` | `source/src/load_adaptive_iir/core/zdomain.py` | Correct frozen-time/stability claims in Chunk 04 |
| `load-adaptive-iir/src/load_shedding.py` | `source/src/load_adaptive_iir/runtime/shedding.py` | Validate against measured telemetry in Chunk 05 |
| `load-adaptive-iir/src/visualize.py` | `source/src/load_adaptive_iir/reporting/figures.py` | Rewrite as artifact-consuming in Chunk 11 |
| Selected test files | `source/tests/` (categorised) | Map one-by-one per test disposition |

### 4. Retention-As-Is List
Files that remain in place (not moved):
- `rehabilitation_plan.md` — active planning document
- `load-adaptive-iir/data/` — large data directories (ledger entries + hashes only)
- `load-adaptive-iir/results/` — quarantine in place (hash/index only)
- `Isolated-Backend/` — quarantined candidate (Chunk 10 decision)
- `React-Frontend/` — quarantined candidate (Chunk 10 decision)
- `.git/` and environments — not moved

### 5. Forbidden-Evidence List (`project/legacy_intake/forbidden_evidence.md`)
Explicitly list files that must NEVER enter `source/artifacts/release/` or the claim ledger:
- `load-adaptive-iir/src/demo_signals.py` — fabricated input generation
- `load-adaptive-iir/src/anomaly_injection.py` — synthetic anomaly injection
- `load-adaptive-iir/src/queue_simulator.py` — simulated runtime evidence
- `load-adaptive-iir/src/experiment_a_compute_cost.py` — generated fallback and weak cost attribution
- `load-adaptive-iir/src/experiment_b_throughput_stability.py` — simulated queue/throughput model
- `load-adaptive-iir/src/experiment_c_pareto.py` — synthetic anomalies/load
- `load-adaptive-iir/src/fp_paradox.py` — synthetic fallback/injection/simulation
- `load-adaptive-iir/src/multi_seed_evaluation.py` — pseudo-replication
- `load-adaptive-iir/src/run_all.py` — orchestrates generated demo/fallbacks
- All files in `load-adaptive-iir/results/` — legacy generated results with contradictions

## Implementation Instructions

1. **Do not delete any original file.** Quarantine means copy-then-verify, not move-then-hope.
2. For each file being quarantined:
   a. Compute SHA-256 of the source file
   b. Copy to the destination in `project/legacy_intake/`
   c. Verify SHA-256 of the copy matches
   d. Record both hashes in the quarantine index
   e. Do NOT delete the original yet — that requires C01-05 or later Human approval
3. Do not copy large data files (raw archives, processed Parquet, environments). Record their ledger entries and hashes only.
4. For files staged for migration: do NOT move them yet. Only create the staging list with proposed destinations. C01-04 performs the actual migration.
5. Mark every file in `project/legacy_intake/` with `LEGACY — NON-AUTHORITATIVE` in the quarantine index.
6. If any file's disposition is unclear or the Human decision from C01-01 is missing, STOP and request the decision. Do not guess.
7. Do not label any legacy result as authoritative. Do not carry any number from legacy results into `key_facts.md`.

## Verification Scripts
```bash
python3 project/chunks/chunk01/scripts/verify_quarantine_manifest.py
```
This script verifies:
- Every quarantined file's hash matches its recorded value
- Every file in `project/legacy_intake/` appears in the quarantine index
- No file in `project/legacy_intake/` is labelled `authoritative`
- Forbidden-evidence files are listed and not staged for migration to `source/`
- No legacy result path is referenced by any `source/` file (if `source/` exists yet)

## Invariant Checklist
- [ ] INV-DATA-001: No fabricated evidence files staged for authoritative migration
- [ ] INV-HIST-001: All quarantined files marked LEGACY — NON-AUTHORITATIVE
- [ ] INV-CLAIM-001: No legacy result or performance number enters claim-ledger-adjacent paths

## Predicted Failure Modes
1. **Missing Human decision for ambiguous file:** STOP. Record the gap. Request Human input via `human_decisions_required.md` update.
2. **Hash mismatch after copy:** Re-copy. If persistent, investigate filesystem issue.
3. **Mixed authentic/generated result that cannot be separated:** Quarantine the entire file as `mixed`. Do not partially migrate.
4. **File locked or unreadable:** Record as `COPY-FAILED` in ledger with error. Do not skip silently.

## Definition of Done
1. Quarantine index complete — every moved file hashed and verified
2. Migration staging list created — every file proposed for C01-04 with destination and known defects
3. Forbidden-evidence list explicit — files that must never enter authoritative surface
4. No original file deleted
5. No legacy result labelled authoritative
6. All Human decisions resolved or explicitly pending
7. Contract report submitted

## Stop Condition
- Missing ledger row for a file being moved
- Hash mismatch between source and quarantine copy
- Ambiguous source ownership that cannot be resolved without Human input
- A mixed authentic/generated result that cannot be cleanly separated
- Any attempt to label a legacy result as authoritative
- Any deletion of an original file not explicitly approved

## Traces To
- INV-DATA-001 (No Fabricated Evidence)
- INV-HIST-001 (Legacy Material Quarantine)
- INV-CLAIM-001 (Claim-Ledger Governance)
- Rehabilitation plan §§9.4, 10
