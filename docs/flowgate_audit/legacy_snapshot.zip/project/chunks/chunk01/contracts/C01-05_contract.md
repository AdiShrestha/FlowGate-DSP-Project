# Contract C01-05 — Git Hygiene and Ignore Policy

## Contract ID
C01-05

## Objective
Replace the ad hoc `.gitignore` with a reviewed policy that makes Git contain durable product material and excludes machine-local/generated material — without hiding any authoritative source. Produce (but do not auto-execute) a reviewed untracking proposal for Human approval.

## Context
The repository currently tracks or exposes numerous transient artefacts: `.DS_Store`, `__pycache__/`, virtual environments, Node.js `node_modules/`, raw/processed data files, generated results, and Factory-private paths. The `.gitignore` needs a comprehensive policy that balances repository cleanliness with auditability. Untracking is high-risk because it can silently remove the only copy of a file if done incorrectly.

## Dependencies
- C01-04 (source scaffold must exist to verify ignore patterns don't hide authoritative source)

## Risk Tier
High (for untracking/destructive proposals) / Medium (for ignore edits)

## Implementation Owner
Implementor. Human approves all untracking operations.

## Scientific Claim Tier
NONE

## Allowed Files
- `.gitignore`
- `project/chunks/chunk01/reports/C01-05/**`
- `project/chunks/chunk01/scripts/**`

## Frozen Files
- `factory/**`
- `source/**`

## Inputs
- C01-04 source scaffold (to verify positive ignore tests)
- C01-01 asset ledger (to identify what's tracked vs. untracked)
- Rehabilitation plan §11 (ignore policy specification)

## Outputs

### 1. Reviewed `.gitignore`
Replace the current `.gitignore` with a comprehensive, section-commented policy:

```gitignore
# ============================================================
# FlowGate .gitignore — Reviewed Policy (Chunk 01, C01-05)
# ============================================================

# --- Python ---
__pycache__/
*.py[cod]
*$py.class
*.so
*.egg-info/
dist/
build/
*.egg

# --- Virtual Environments ---
.venv/
env/
.myenv/
venv/

# --- IDE / OS ---
.DS_Store
Thumbs.db
.idea/
.vscode/
*.swp
*.swo
*~

# --- Node.js (legacy frontend/backend) ---
node_modules/

# --- Data (too large for Git; managed by acquisition pipeline) ---
data/
load-adaptive-iir/data/

# --- Generated Results (not authoritative; reproduced from source) ---
results/
load-adaptive-iir/results/

# --- Caches ---
.mypy_cache/
.ruff_cache/
.pytest_cache/
.numba_cache/
__numba_cache__/
.hypothesis/

# --- Jupyter ---
.ipynb_checkpoints/

# --- Factory Private (nested project/ repo has its own .git) ---
project/
DROP_HERE/
TAKE_THIS/

# --- Factory Infrastructure (read-only, pinned) ---
factory/

# --- Bootstrap (one-time use) ---
bootstrap.sh
```

### 2. Ignore Matrix Verification (`project/chunks/chunk01/reports/C01-05/ignore_matrix.md`)

| Path | Expected Status | Actual Status | Pass/Fail |
|---|---|---|---|
| `.DS_Store` | Ignored | | |
| `__pycache__/test.pyc` | Ignored | | |
| `.venv/bin/python` | Ignored | | |
| `.myenv/lib/python3.x/` | Ignored | | |
| `node_modules/express/` | Ignored | | |
| `data/raw/sample.zip` | Ignored | | |
| `data/processed/sample.parquet` | Ignored | | |
| `load-adaptive-iir/data/raw/` | Ignored | | |
| `results/experiment.csv` | Ignored | | |
| `project/project_description.md` | Ignored (outer) | | |
| `factory/VERSION` | Ignored | | |
| `DROP_HERE/dropbox_manifest.json` | Ignored | | |
| `source/pyproject.toml` | **NOT Ignored** | | |
| `source/src/load_adaptive_iir/core/filters.py` | **NOT Ignored** | | |
| `source/tests/unit/test_filters.py` | **NOT Ignored** | | |
| `source/README.md` | **NOT Ignored** | | |
| `load-adaptive-iir/src/filters.py` | **NOT Ignored** (legacy source tracked until explicit untracking) | | |
| `Isolated-Backend/server.js` | **NOT Ignored** (quarantined candidate) | | |
| `React-Frontend/src/App.jsx` | **NOT Ignored** (quarantined candidate) | | |
| `rehabilitation_plan.md` | **NOT Ignored** | | |

### 3. Untracking Proposal (`project/chunks/chunk01/reports/C01-05/untracking_proposal.md`)
A reviewed, not-yet-executed list of `git rm --cached` commands for:
- `.DS_Store` files
- `__pycache__/` directories
- Generated result files currently tracked
- Environment files currently tracked
- Any other transient artefacts identified in C01-01

For each entry:
- The exact `git rm --cached` command
- Confirmation that the file exists locally (will not be deleted by untracking)
- Whether the file is needed for any active work
- Human approval status: PENDING

**Do not execute any untracking without Human approval.**

### 4. Size Report (`project/chunks/chunk01/reports/C01-05/size_report.md`)
- Before/after tracked file counts (before = current, after = projected with untracking)
- Current tracked size, projected tracked size
- Estimated clone size reduction
- `.git/` directory size and growth diagnosis (do NOT prune/gc)

## Implementation Instructions

1. Write the new `.gitignore` with all sections commented for clarity.
2. Test every row of the ignore matrix using `git check-ignore -v <path>`:
   ```bash
   git check-ignore -v .DS_Store
   git check-ignore -v __pycache__/x.pyc
   git check-ignore -v source/pyproject.toml  # Should NOT be ignored
   ```
3. Create the ignore verification script that automates the matrix check.
4. Compile the untracking proposal — list every file that is currently tracked but should be ignored.
5. For each file in the untracking proposal, verify:
   a. The file exists on the local filesystem
   b. The file would survive `git rm --cached` (not deleted from disk)
   c. No other process depends on this file being tracked
6. **Do not execute `git rm --cached` commands.** Only produce the reviewed proposal.
7. **Do not ignore `React-Frontend/` or `Isolated-Backend/` wholesale.** They remain visible (not ignored) until Chunk 10 decides their fate.
8. Measure and report `.git/` size. Do NOT run `git gc --prune=now`, `git reflog expire`, or `git filter-branch`.
9. After Human approval (obtained outside this contract), execute the approved untracking commands and verify files still exist locally.

## Verification Scripts
```bash
python3 project/chunks/chunk01/scripts/verify_ignore_matrix.py
git check-ignore -v .DS_Store __pycache__/x.pyc .venv/bin/python node_modules/x data/raw/sample.zip
# Negative checks (must NOT be ignored):
git check-ignore -v source/pyproject.toml && echo "FAIL: source ignored" || echo "PASS"
git check-ignore -v source/src/load_adaptive_iir/core/filters.py && echo "FAIL" || echo "PASS"
```

## Invariant Checklist
- [ ] INV-REPRO-001: No authoritative source is hidden by .gitignore
- [ ] INV-SEC-001: No secrets exposed by changed ignore patterns
- [ ] INV-HIST-001: Legacy source remains visible for quarantine management

## Predicted Failure Modes
1. **Ignore pattern captures authoritative source:** STOP. Narrow the pattern. Add a negative test.
2. **Untracking would remove the only copy of a file:** STOP. Verify local existence first. Never untrack without Human approval.
3. **Git object/ref corruption during investigation:** Record findings. Do NOT attempt repair.
4. **Pattern conflict between legacy and source paths:** Use path-specific patterns (not wildcards that cross boundaries).

## Definition of Done
1. `.gitignore` replaced with reviewed, section-commented policy
2. Ignore matrix tested — all expected patterns verified
3. No authoritative source path is ignored
4. Untracking proposal produced (not executed) with Human approval fields
5. Size report with before/after metrics and `.git/` diagnosis
6. Contract report submitted

## Stop Condition
- An ignore pattern captures authoritative source or evidence
- Untracking would remove the only copy of a file
- Unexpected Git object/ref behaviour
- Any command includes filesystem deletion (`rm`, `del`)
- Human approval is absent for any untracking operation

## Traces To
- NFR-001 (Clean-room reproducibility)
- INV-REPRO-001 (Builds from clean clone)
- INV-SEC-001 (No secrets in release)
- Rehabilitation plan §§9.6, 11
