# Contract C01-07 — Deterministic Build, Test, and CI Baseline

## Contract ID
C01-07

## Objective
Make mechanical correctness repeatable before scientific changes begin. Establish a complete build definition, deterministic lock workflow, categorised test markers, cache redirection, and CI-equivalent local command set. Produce a test disposition ledger mapping every legacy test to its rehabilitation status.

## Context
After C01-04 creates the source scaffold and C01-06 establishes the firewall, this contract ensures the migrated package builds, installs, and tests deterministically. The legacy test suite had 97 passing tests with 5 warnings — this contract creates a migration baseline that classifies every test honestly rather than preserving a count.

## Dependencies
- C01-04 (source scaffold and migrated code must exist)
- C01-06 (firewall tests must exist for inclusion in the test suite)

## Risk Tier
Medium

## Implementation Owner
Implementor

## Scientific Claim Tier
NONE — build infrastructure makes no scientific claims. Test results are behavioural baselines, not scientific validation.

## Allowed Files
- `source/pyproject.toml`
- `source/uv.lock` (or equivalent lock file)
- `source/tests/**`
- `source/configs/**`
- `.github/workflows/**`
- `project/chunks/chunk01/reports/C01-07/**`

## Frozen Files
- `factory/**`
- `source/src/load_adaptive_iir/core/**` (no logic changes — only build/test infrastructure)

## Inputs
- C01-04 migrated source and tests
- C01-06 firewall tests
- Legacy test baseline from C01-01 (97 tests, 5 warnings)
- Rehabilitation plan §9.8

## Outputs

### 1. Finalised `pyproject.toml`
Complete build definition including:
- Supported Python versions: `>=3.10,<3.13` (exact scope decided here)
- OS scope: macOS (primary development), Linux (CI)
- All core and dev dependencies with pinned `major.minor`
- pytest configuration section:
  ```toml
  [tool.pytest.ini_options]
  markers = [
      "unit: Deterministic branch/type/error tests",
      "semantic: Analytically derived DSP tests",
      "integration: Component-join tests with mocks",
      "scientific: Protocol invariant and leakage tests",
      "external_data: Requires authentic external data",
      "slow: Takes >10 seconds",
  ]
  testpaths = ["tests"]
  addopts = "-ra --strict-markers"
  ```
- ruff configuration section
- mypy configuration section

### 2. Deterministic Lock File
- `uv.lock` (preferred) or `requirements-lock.txt` from `pip freeze`
- Must reproduce identical dependency set from a clean environment
- Verify lock file reproduces: install from lock → run tests → same results

### 3. Test Configuration (`source/tests/conftest.py`)
- Cache redirection for Matplotlib, Numba, pytest, and other caches to temp/CI locations:
  ```python
  import os
  os.environ.setdefault("MPLCONFIGDIR", "/tmp/mpl_cache")
  os.environ.setdefault("NUMBA_CACHE_DIR", "/tmp/numba_cache")
  ```
- Disable accidental network access in unit tests (optional: use `pytest-socket` or a conftest fixture)
- Shared fixtures for deterministic test vectors (non-empirical mathematical inputs only)
- Marker auto-registration

### 4. Test Disposition Ledger (`project/chunks/chunk01/reports/C01-07/test_disposition.md`)
Map every one of the 97 legacy tests to one of:

| Status | Meaning |
|---|---|
| `retained` | Test is valid and migrated to the appropriate category |
| `rewritten` | Test logic corrected and migrated (original preserved as xfail reference) |
| `retired-invalid` | Test premise is scientifically invalid (e.g., validates fabricated evidence) — retired with reason |
| `blocked` | Test depends on data/infrastructure not yet available — deferred to later chunk |

For each test:
- Legacy test name/location
- New test name/location (if retained/rewritten)
- Status with reason
- Category assignment (unit/semantic/integration/scientific)

**Important:** Do not require synthetic/random tests merely to preserve a count of 97. Coverage is semantic, not numerical. A count of 40 retained honest tests is strictly better than 97 tests some of which validate fabricated evidence.

### 5. Warning Disposition
For each of the 5 legacy warnings:
- Identify the warning source and content
- Classify as: `expected-known` (documented, bounded), `failing-scientific-issue` (promoted to test failure), or `requires-investigation`
- Do NOT globally suppress warnings. Handle each explicitly.

### 6. CI Workflow Definition (`.github/workflows/ci.yml` or equivalent)
A local-reproducible CI definition including:
- **lint**: `ruff check src/ tests/`
- **format-check**: `ruff format --check src/ tests/`
- **type-check**: `mypy src/ --ignore-missing-imports`
- **unit-test**: `pytest tests/unit/ -x --tb=short`
- **package-build**: `pip install -e '.[dev]'` from a clean environment
- **static-audit**: `python3 factory/gatekeeper.py acquisition-audit --path source/`
- **secret-scan**: grep for API keys, tokens, local paths, email placeholders in source/

The CI definition may be a GitHub Actions YAML or a Makefile/script that runs the equivalent commands locally. Both are acceptable.

### 7. Clean Environment Verification (`project/chunks/chunk01/reports/C01-07/clean_env_test.md`)
- Create a fresh temporary virtual environment
- Install the package from source: `pip install -e '.[dev]'`
- Run: `python -c "import load_adaptive_iir; print(load_adaptive_iir.__version__)"`
- Run: `python -m pytest tests/unit/ -x --tb=short`
- Record results
- Verify no legacy directories are required

## Implementation Instructions

1. Finalise `pyproject.toml` with all sections (build system, dependencies, tool configs).
2. Create a deterministic lock file. Verify it reproduces.
3. Set up `tests/conftest.py` with cache redirection and marker registration.
4. Go through every legacy test one by one:
   a. Read the test
   b. Determine if its premise is valid (does it test real logic, or does it validate fabricated evidence?)
   c. Classify as retained/rewritten/retired-invalid/blocked
   d. If retained: place in the appropriate category, update imports
   e. If retired: record the reason, remove from the active test suite
5. Handle each warning explicitly. Do not use `filterwarnings = "ignore"` broadly.
6. Create CI-equivalent command set (script or GitHub Actions YAML).
7. Test from a clean temporary environment:
   ```bash
   python -m venv /tmp/flowgate_test_env
   source /tmp/flowgate_test_env/bin/activate
   cd source
   pip install -e '.[dev]'
   python -c "import load_adaptive_iir"
   python -m pytest tests/unit/ -x --tb=short
   deactivate
   rm -rf /tmp/flowgate_test_env
   ```
8. Verify that test execution does not write to tracked source files.
9. Verify that package import does not require data files.
10. Preserve statistical precision warnings as explicit, bounded expected warnings — not blanket suppression.

## Verification Scripts
```bash
cd source && pip install -e '.[dev]' && python -m pytest --tb=short
cd source && python -m ruff check src/ tests/
cd source && python -m mypy src/ --ignore-missing-imports
```

## Invariant Checklist
- [ ] INV-REPRO-001: Package builds and tests from a clean environment with no legacy dependencies
- [ ] INV-DATA-001: No test retained that validates fabricated evidence as authoritative

## Predicted Failure Modes
1. **Lock file cannot reproduce:** Re-generate from a clean environment. Pin exact versions.
2. **Tests depend on current virtual environment or local data:** Identify the dependency, mark the test as `blocked`, and document what it needs.
3. **Package import writes into source tree:** Find the write and redirect to a temp location.
4. **Warning suppression hides a real issue:** Handle each warning individually with documented rationale.
5. **Retired test leaves a requirement untested:** Note in the disposition ledger. The requirement should be covered by a new test in a later chunk.

## Definition of Done
1. `pyproject.toml` complete with all configuration sections
2. Lock file verified to reproduce from clean environment
3. Every legacy test classified in the disposition ledger with reason
4. All 5 warnings handled explicitly (not globally suppressed)
5. CI-equivalent local commands defined and documented
6. Clean temporary environment install and test passes
7. Package import requires no data files or legacy directories
8. Test execution does not write to tracked source files
9. New test count and categories documented
10. Contract report submitted

## Stop Condition
- Lock file cannot reproduce across environments
- Tests depend on current virtual environment or local data that cannot be redirected
- Package import writes into source tree
- Warnings are globally suppressed without individual review
- A retired invalid test leaves a corresponding requirement entirely untested with no plan to re-test

## Traces To
- NFR-001 (Clean-room reproducibility)
- INV-REPRO-001 (Clean-Room Reproducibility)
- Rehabilitation plan §9.8
