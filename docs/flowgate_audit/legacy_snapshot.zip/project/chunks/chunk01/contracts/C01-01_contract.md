# Contract C01-01 — Legacy State Preservation and Asset Ledger

## Contract ID
C01-01

## Objective
Create a trustworthy, lossless description of the repository's starting state so that later cleanup cannot erase user work or turn legacy outputs into unexplained artefacts. This is the forensic baseline for the entire rehabilitation.

## Context
The repository is currently dirty: 10 modified tracked files, 1 deleted tracked notebook, 319 untracked paths, ~4.8 GB workspace, ~1.7 GB `.git/`. A cleanup that does not first preserve this state risks losing intended user work or silently converting legacy results into unexplained artefacts. This contract produces the read-only inventory that makes all subsequent contracts safe.

## Dependencies
None — this is the first contract in Chunk 01.

## Risk Tier
Medium

## Implementation Owner
Implementor (runs read-only inventory scripts). Architect specifies the ledger schema and performs final classification.

## Scientific Claim Tier
T-DESC — literal observed counts only. No interpretation of test results as scientific validation. No performance claims.

## Allowed Files
- `project/legacy_intake/**`
- `project/chunks/chunk01/reports/C01-01/**`
- `project/chunks/chunk01/scripts/**`

## Frozen Files
- `factory/**`
- `load-adaptive-iir/**` (read-only inventory; do not modify)
- `Isolated-Backend/**` (read-only inventory; do not modify)
- `React-Frontend/**` (read-only inventory; do not modify)
- `source/**`

## Inputs
- Current working tree (all files, tracked and untracked)
- `git status`, `git log`, `git diff`, `git ls-files` output
- Factory `acquisition-audit` and `lint-contract` output from current source

## Outputs

### 1. Git/Worktree Snapshot (`project/legacy_intake/worktree_snapshot.md`)
Capture:
- `git status --short --branch` output
- Branch name, HEAD commit hash, remote URL, tags
- `git log --oneline -10` (recent history)
- Tracked file count and total tracked size
- Modified/deleted/untracked path lists (redact any secrets)
- Directory-level size breakdown: `load-adaptive-iir/`, `data/raw/`, `data/processed/`, `env/`, `.myenv/`, `Isolated-Backend/`, `React-Frontend/`, `results/`, `.git/`

### 2. Asset Ledger (`project/legacy_intake/asset_ledger.csv`)
One row per meaningful path or homogeneous generated group. Columns:

| Column | Description |
|---|---|
| `asset_id` | Logical identifier (e.g., `SRC-FILTERS-001`) |
| `original_path` | Full relative path from repo root |
| `git_state` | `tracked`, `untracked`, `modified`, `deleted` |
| `asset_type` | `source`, `test`, `document`, `raw-data`, `processed-data`, `result`, `environment`, `cache`, `application`, `config`, `unknown` |
| `size_bytes` | File size or group total |
| `hash_strategy` | `sha256-file`, `sha256-first-1mb`, `count-only`, `skip-environment` |
| `hash_value` | Hash value where applicable |
| `authenticity_state` | `not-applicable`, `unverified-authentic`, `verified-authentic`, `generated`, `mixed`, `unknown` |
| `publication_authority` | `authoritative`, `candidate`, `legacy-only`, `forbidden-evidence`, `transient` |
| `proposed_disposition` | `migrate-to-source`, `quarantine-legacy-intake`, `untrack-ignore`, `delete-after-approval`, `retain-as-is`, `pending-human-decision` |
| `human_decision_required` | `yes` / `no` |
| `decision_notes` | Reason for the proposed disposition |
| `final_migrated_path` | Initially blank; filled during C01-03/C01-04 |

### 3. Modified File Diffs (`project/legacy_intake/diffs/`)
- Text diffs for all modified tracked source and document files
- Metadata summaries for modified binary/generated files (size, type, hash change)
- Do NOT copy 1.9 GB of data into `project/`

### 4. Test Baseline Record (`project/legacy_intake/test_baseline.md`)
- Command used, environment description (Python version, OS, key packages)
- Result: `97 passed, 5 warnings in 168.38s`
- All 5 warnings listed verbatim
- Explicit statement: "This is a behavioural baseline, NOT a scientific validation"

### 5. Factory Audit Baseline (`project/legacy_intake/factory_audit_baseline.md`)
- `acquisition-audit` output: 2 hard failures, 8 warnings (list each)
- `lint-contract` output: 15 hard failures (list each with file/line)
- Self-check output: zero drift findings, 9 heuristic warnings

### 6. Secret/Path Scan (`project/legacy_intake/secret_scan.md`)
- Scan for: API keys, tokens, `.env` files, hardcoded passwords, personal filesystem paths, email placeholders (`yourname@...`), machine identity
- Report locations but redact actual secret values
- Flag any findings requiring immediate containment

### 7. Human Decision Requests (`project/legacy_intake/human_decisions_required.md`)
- Deleted notebook (`01_full_pipeline.ipynb`): preserve deletion, restore for quarantine, or migrate?
- Each modified source/test file: is this intended work or accidental generated change?
- Each ambiguous untracked document: retain, quarantine, or discard?

## Implementation Instructions

1. **Do not modify any existing file.** This contract is entirely read-only against the working tree.
2. Create an inventory script (`project/chunks/chunk01/scripts/inventory.py` or `inventory.sh`) that captures all outputs programmatically where possible.
3. For the asset ledger, group homogeneous generated files (e.g., all `.pyc` files, all `__pycache__/` directories) into single rows rather than listing each individually.
4. For large data directories (`data/raw/`, `data/processed/`), record file counts, total sizes, and sample hashes rather than hashing every file.
5. Use `sha256` for source files and documents. Use `sha256` of the first 1 MB for large data files. Use `count-only` for environment directories.
6. Record the exact commands used for every output so the inventory is reproducible.
7. Do not interpret test warnings as scientific issues or test passes as scientific validation.
8. Do not propose dispositions for files where the user's intent is unclear — mark those `pending-human-decision`.

## Verification Scripts
```bash
python3 project/chunks/chunk01/scripts/verify_ledger_counts.py
```
This script (to be created) verifies:
- Ledger row count approximately matches the number of meaningful paths in the repository
- Every tracked file appears in the ledger (or in a grouped row)
- Every modified/deleted file has a diff or metadata entry
- No file in the working tree is unaccounted for
- Aggregate counts reconcile with `git ls-files` and filesystem observations

## Invariant Checklist
- [ ] INV-HIST-001: Legacy material preserved for audit
- [ ] INV-SEC-001: Secret scan completed; no secrets in report values

## Predicted Failure Modes
1. **Hash/read failure on large files:** Fall back to `sha256-first-1mb` strategy. If file is unreadable, record `HASH-FAILED` with error.
2. **Secret discovered:** Stop immediately. Record location only (not value). Flag for Human containment decision.
3. **Cannot distinguish user work from generated output:** Mark as `pending-human-decision`. Do not guess.
4. **Path count mismatch:** Re-run inventory. If persistent, investigate and document the discrepancy.

## Definition of Done
1. All 7 output artefacts exist in `project/legacy_intake/` and `project/chunks/chunk01/reports/C01-01/`
2. Ledger covers every meaningful path; aggregate counts reconcile with Git/filesystem
3. No existing file was modified, deleted, or moved
4. Human decision requests are explicit and complete
5. Secret scan completed with no uncontained findings
6. Contract report submitted

## Stop Condition
- Hash/read failure that cannot be worked around
- Evidence of secrets requiring immediate containment beyond simple redaction
- Inability to distinguish user changes from generated changes on a critical path
- Mismatch between path counts and captured ledger that cannot be explained
- Any attempted deletion, modification, or automatic restoration of an existing file

## Traces To
- INV-HIST-001 (Legacy Material Quarantine)
- INV-SEC-001 (No Secrets in Release)
- Rehabilitation plan §§4, 8.1
