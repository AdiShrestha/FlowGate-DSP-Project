# Contract C01-06 — Non-Fabrication Firewall and Fail-Closed Interfaces

## Contract ID
C01-06

## Objective
Ensure no production/research code path can generate or substitute empirical data. Remove generated-data and simulated-backpressure functions from authoritative reachability. Add static verification, import boundaries, typed failure outcomes, and negative tests that prevent accidental revival of synthetic evidence or silent fallback.

## Context
The legacy codebase contains multiple data fabrication paths: `generate_synthetic_signal()`, `simulate_backpressure()`, anomaly injection functions, and `except Exception: pass/continue` swallowed exceptions that silently substitute generated data when authentic acquisition fails. This contract is the truth firewall — the most critical safety mechanism in the entire rehabilitation. Once this contract passes, later developers cannot accidentally reintroduce fabricated evidence without triggering a test failure.

## Dependencies
- C01-04 (authoritative source scaffold must exist)

## Risk Tier
High — policy-critical implementation where a subtle error could contaminate all downstream evidence.

## Implementation Owner
Architect — this is a High-risk contract that the Architect implements directly.

## Scientific Claim Tier
NONE — this is infrastructure, not a scientific claim. But its failure would invalidate all future scientific claims.

## Allowed Files
- `source/src/load_adaptive_iir/**`
- `source/tests/**`
- `source/configs/schemas/**`
- `project/chunks/chunk01/reports/C01-06/**`

## Frozen Files
- `factory/**`
- `project/project_description.md`
- `project/architecture.md`
- `project/invariants.md`

## Inputs
- C01-04 migrated source in `source/`
- Rehabilitation plan §9.7 (firewall requirements)
- `invariants.md` INV-DATA-001 and INV-DATA-002
- Legacy source (read-only, for reference on what to block)

## Outputs

### 1. Authoritative Code Cleanup
In `source/src/load_adaptive_iir/`:
- Remove or quarantine any function that generates synthetic signals, simulates queue depth/backpressure, injects anomalies, or creates fallback data when authentic acquisition fails
- Remove any `except Exception: pass` or `except Exception: continue` in data acquisition, transformation, or evidence paths
- Replace with typed failure outcomes using the exception hierarchy from C01-04

Functions to remove from authoritative reachability (not delete from legacy — just ensure they cannot be imported from the authoritative package):
- `generate_synthetic_signal()` and variants
- `simulate_backpressure()` and variants
- `inject_anomaly()` and variants
- Any `_fallback_to_generated()` pattern
- Any `random_walk()` or `sine_noise_mixture()` for evidence

### 2. Static Non-Fabrication Verifier (`source/tests/unit/test_firewall.py`)

<!-- MATERIALIZE: source/tests/unit/test_firewall.py -->
```python
"""
Non-fabrication firewall tests.

These tests verify that the authoritative source package cannot reach
fabricated-evidence generators, simulated-runtime functions, or
silent-substitution fallback paths.

Scientific Claim Tier: NONE (infrastructure verification)
Traces To: INV-DATA-001, INV-DATA-002
"""
import ast
import importlib
import os
import pathlib
import re
import sys

import pytest

# Authoritative source root
SOURCE_ROOT = pathlib.Path(__file__).resolve().parents[2] / "src" / "load_adaptive_iir"

# Legacy root (must not be importable from authoritative code)
LEGACY_ROOT = pathlib.Path(__file__).resolve().parents[3] / "load-adaptive-iir"

# ──────────────────────────────────────────────────────────────
# Prohibited terms in authoritative source
# ──────────────────────────────────────────────────────────────
PROHIBITED_TERMS = [
    # Data fabrication
    r"generate_synthetic",
    r"synthetic_signal",
    r"random_walk\s*\(",
    r"sine_noise_mixture",
    r"inject_anomal",
    r"fabricat(?:e|ed|ing)\s+(?:data|signal|evidence)",
    # Queue/runtime simulation
    r"simulate_backpressure",
    r"simulate_queue",
    r"simulated_load",
    r"fake_queue_depth",
    r"mock_backpressure",
    # Silent substitution
    r"fallback_to_generated",
    r"use_generated_if",
    r"substitute_synthetic",
    # Evidence laundering
    r"except\s+(?:Exception|BaseException)\s*:\s*(?:pass|continue)",
]

# Narrow allowlist: explanatory text, test docstrings, comments about prohibition
ALLOWLIST_CONTEXTS = [
    "# KNOWN DEFECT",
    "# PROHIBITED:",
    "# This test verifies that",
    '"""',
    "'''",
    "# LEGACY",
]


def _collect_python_files(root: pathlib.Path) -> list[pathlib.Path]:
    """Collect all .py files under a directory."""
    return sorted(root.rglob("*.py"))


def _is_allowlisted(line: str) -> bool:
    """Check if a line is in an allowed context (comment/docstring about prohibition)."""
    stripped = line.strip()
    return any(ctx in stripped for ctx in ALLOWLIST_CONTEXTS)


class TestProhibitedTerms:
    """Verify no prohibited fabrication/simulation terms in authoritative source."""

    @pytest.fixture(scope="class")
    def source_files(self) -> list[pathlib.Path]:
        return _collect_python_files(SOURCE_ROOT)

    def test_no_prohibited_terms_in_source(self, source_files: list[pathlib.Path]) -> None:
        violations = []
        for filepath in source_files:
            # Skip test files themselves
            if "test_firewall" in filepath.name:
                continue
            try:
                content = filepath.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for line_num, line in enumerate(content.splitlines(), 1):
                if _is_allowlisted(line):
                    continue
                for pattern in PROHIBITED_TERMS:
                    if re.search(pattern, line, re.IGNORECASE):
                        violations.append(
                            f"  {filepath.relative_to(SOURCE_ROOT)}:{line_num}: "
                            f"matched '{pattern}' in: {line.strip()[:100]}"
                        )
        assert not violations, (
            f"Prohibited fabrication/simulation terms found in authoritative source:\n"
            + "\n".join(violations)
        )


class TestSwallowedExceptions:
    """Verify no swallowed exceptions in evidence-path code."""

    @pytest.fixture(scope="class")
    def source_files(self) -> list[pathlib.Path]:
        return _collect_python_files(SOURCE_ROOT)

    def test_no_bare_except_pass(self, source_files: list[pathlib.Path]) -> None:
        """No except Exception: pass/continue in authoritative source."""
        violations = []
        for filepath in source_files:
            if "test_" in filepath.name:
                continue
            try:
                content = filepath.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for line_num, line in enumerate(content.splitlines(), 1):
                if _is_allowlisted(line):
                    continue
                if re.search(
                    r"except\s+(?:Exception|BaseException)\s*:\s*(?:pass|continue)",
                    line,
                ):
                    violations.append(
                        f"  {filepath.relative_to(SOURCE_ROOT)}:{line_num}: {line.strip()}"
                    )
        assert not violations, (
            f"Swallowed exceptions found in authoritative source:\n"
            + "\n".join(violations)
        )
```

### 3. Import Boundary Test (`source/tests/unit/test_boundaries.py`)

<!-- MATERIALIZE: source/tests/unit/test_boundaries.py -->
```python
"""
Import boundary tests.

These tests verify that the authoritative source package cannot import
from the legacy tree and that experiment commands cannot load test fixtures.

Scientific Claim Tier: NONE (infrastructure verification)
Traces To: INV-DATA-001, INV-HIST-001
"""
import ast
import pathlib

import pytest

SOURCE_ROOT = pathlib.Path(__file__).resolve().parents[2] / "src" / "load_adaptive_iir"
LEGACY_IMPORT_PATTERNS = [
    "from src.",
    "import src.",
    "from load-adaptive-iir",
    "from load_adaptive_iir_legacy",
]


def _collect_python_files(root: pathlib.Path) -> list[pathlib.Path]:
    return sorted(root.rglob("*.py"))


class TestImportBoundary:
    """Verify source/ does not import from the legacy tree."""

    @pytest.fixture(scope="class")
    def source_files(self) -> list[pathlib.Path]:
        return _collect_python_files(SOURCE_ROOT)

    def test_no_legacy_imports(self, source_files: list[pathlib.Path]) -> None:
        violations = []
        for filepath in source_files:
            try:
                content = filepath.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for line_num, line in enumerate(content.splitlines(), 1):
                for pattern in LEGACY_IMPORT_PATTERNS:
                    if pattern in line and not line.strip().startswith("#"):
                        violations.append(
                            f"  {filepath.relative_to(SOURCE_ROOT)}:{line_num}: {line.strip()}"
                        )
        assert not violations, (
            f"Legacy imports found in authoritative source:\n"
            + "\n".join(violations)
        )

    def test_no_legacy_path_in_sys_path(self) -> None:
        """Verify importing the package doesn't add legacy paths to sys.path."""
        import sys
        # Record sys.path before import
        pre_import_paths = set(sys.path)
        try:
            import load_adaptive_iir
        except ImportError:
            pytest.skip("Package not installed")
        post_import_paths = set(sys.path)
        new_paths = post_import_paths - pre_import_paths
        legacy_leaks = [p for p in new_paths if "load-adaptive-iir" in p]
        assert not legacy_leaks, f"Package import added legacy paths: {legacy_leaks}"


class TestReleaseBoundary:
    """Verify experiment/report commands cannot load test fixtures."""

    def test_no_fixture_imports_in_source(self) -> None:
        """Source code must not import from tests/fixtures/."""
        source_files = _collect_python_files(SOURCE_ROOT)
        violations = []
        for filepath in source_files:
            try:
                content = filepath.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for line_num, line in enumerate(content.splitlines(), 1):
                if "fixtures" in line and "import" in line and not line.strip().startswith("#"):
                    violations.append(
                        f"  {filepath.relative_to(SOURCE_ROOT)}:{line_num}: {line.strip()}"
                    )
        assert not violations, (
            f"Test fixture imports found in production source:\n"
            + "\n".join(violations)
        )
```

### 4. Typed Acquisition Outcomes
Ensure the exception hierarchy from C01-04 includes:

<!-- MATERIALIZE: source/src/load_adaptive_iir/data/outcomes.py -->
```python
"""
Typed outcomes for data acquisition and transformation.

Every external-source operation returns a structured result.
Failure never produces a synthetic substitute or swallowed exception.

Traces To: INV-DATA-002 (Fail-Closed External Dependencies)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any


class AcquisitionStatus(Enum):
    """Status of an acquisition operation."""
    SUCCESS = auto()
    CHECKSUM_MISMATCH = auto()
    NETWORK_UNAVAILABLE = auto()
    HTTP_ERROR = auto()
    MISSING_ARCHIVE = auto()
    SCHEMA_MISMATCH = auto()
    PARTIAL_DECOMPRESSION = auto()
    DUPLICATE_IDENTITY = auto()
    TLS_FAILURE = auto()
    UNKNOWN_ERROR = auto()


@dataclass(frozen=True)
class AcquisitionResult:
    """Structured result from an acquisition operation.
    
    Never silently substitutes data. On failure, downstream processing
    is blocked until Human intervention.
    """
    status: AcquisitionStatus
    message: str
    source_url: str = ""
    expected_checksum: str = ""
    observed_checksum: str = ""
    byte_count: int = 0
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def is_success(self) -> bool:
        return self.status == AcquisitionStatus.SUCCESS

    @property
    def is_blocked(self) -> bool:
        return not self.is_success

    def require_success(self) -> "AcquisitionResult":
        """Raise if not successful. Fail-closed pattern."""
        if not self.is_success:
            raise BlockedExternalDependency(
                f"BLOCKED — HUMAN ACTION REQUIRED: {self.status.name}: {self.message}"
            )
        return self


class BlockedExternalDependency(Exception):
    """External source failure requiring Human intervention.
    
    This exception maps to BLOCKED — HUMAN ACTION REQUIRED.
    It never produces a synthetic substitute or silent fallback.
    """
    pass


class DataIntegrityError(Exception):
    """Data integrity violation detected during transformation."""
    pass


class ManifestError(Exception):
    """Data or run manifest schema violation."""
    pass
```

### 5. Data/Run Manifest Schema Stubs (`source/configs/schemas/`)
Create JSON Schema stubs for:
- `data_manifest_schema.json` — defines required fields for dataset manifests
- `run_manifest_schema.json` — defines required fields for experiment run manifests
- `acquisition_provenance_schema.json` — defines required fields for acquisition records

These are empty-schema stubs acknowledging that current data does NOT pass them. Full population is in Chunk 03.

### 6. Negative Tests for Failure Paths (`source/tests/unit/test_fail_closed.py`)

<!-- MATERIALIZE: source/tests/unit/test_fail_closed.py -->
```python
"""
Fail-closed negative tests.

Verify that every external-source failure mode produces a structured
error, never a silent substitution or swallowed exception.

Scientific Claim Tier: NONE (infrastructure verification)
Traces To: INV-DATA-002
"""
import pytest

from load_adaptive_iir.data.outcomes import (
    AcquisitionResult,
    AcquisitionStatus,
    BlockedExternalDependency,
)


class TestAcquisitionOutcomes:
    """Verify typed acquisition outcomes behave correctly."""

    def test_success_result(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.SUCCESS,
            message="OK",
            source_url="https://example.com/data.zip",
            expected_checksum="abc123",
            observed_checksum="abc123",
            byte_count=1024,
        )
        assert result.is_success
        assert not result.is_blocked
        result.require_success()  # Should not raise

    def test_checksum_mismatch_blocks(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.CHECKSUM_MISMATCH,
            message="Expected abc123, got def456",
            expected_checksum="abc123",
            observed_checksum="def456",
        )
        assert not result.is_success
        assert result.is_blocked
        with pytest.raises(BlockedExternalDependency, match="BLOCKED"):
            result.require_success()

    def test_network_unavailable_blocks(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.NETWORK_UNAVAILABLE,
            message="Connection refused",
        )
        assert result.is_blocked
        with pytest.raises(BlockedExternalDependency, match="HUMAN ACTION REQUIRED"):
            result.require_success()

    def test_http_error_blocks(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.HTTP_ERROR,
            message="HTTP 404",
        )
        assert result.is_blocked

    def test_missing_archive_blocks(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.MISSING_ARCHIVE,
            message="Archive not found",
        )
        assert result.is_blocked

    def test_schema_mismatch_blocks(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.SCHEMA_MISMATCH,
            message="Unexpected columns",
        )
        assert result.is_blocked

    def test_partial_decompression_blocks(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.PARTIAL_DECOMPRESSION,
            message="Truncated archive",
        )
        assert result.is_blocked

    def test_duplicate_identity_blocks(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.DUPLICATE_IDENTITY,
            message="Duplicate trade IDs",
        )
        assert result.is_blocked

    def test_tls_failure_blocks(self) -> None:
        result = AcquisitionResult(
            status=AcquisitionStatus.TLS_FAILURE,
            message="Certificate verification failed",
        )
        assert result.is_blocked

    def test_all_failure_statuses_are_blocked(self) -> None:
        """Every non-SUCCESS status must be blocked."""
        for status in AcquisitionStatus:
            if status == AcquisitionStatus.SUCCESS:
                continue
            result = AcquisitionResult(
                status=status,
                message=f"Test failure: {status.name}",
            )
            assert result.is_blocked, f"{status.name} should be blocked"
            with pytest.raises(BlockedExternalDependency):
                result.require_success()
```

## Implementation Instructions

Since this is an Architect-implemented High-risk contract:

1. Review all migrated source in `source/src/load_adaptive_iir/` for prohibited patterns.
2. Remove or quarantine any fabrication/simulation/fallback functions from authoritative reachability.
3. Replace swallowed exceptions (`except Exception: pass/continue`) with typed error propagation.
4. Materialise the test files using `gatekeeper.py materialize --contract C01-06`.
5. Materialise `outcomes.py` for typed acquisition results.
6. Create JSON Schema stubs in `source/configs/schemas/`.
7. Run all verification scripts.
8. Run Factory `acquisition-audit` against `source/` — zero hard failures required.
9. Address any false-positive terminology matches by improving the verifier's allowlist with explicit, reviewed rules — not broad exclusion.
10. Write the contract report.

## Verification Scripts
```bash
python3 factory/gatekeeper.py acquisition-audit --path source/
python3 factory/gatekeeper.py lint-contract --contract C01-06
cd source && python -m pytest tests/unit/test_firewall.py tests/unit/test_boundaries.py tests/unit/test_fail_closed.py -x --tb=short -v
```

## Invariant Checklist
- [x] INV-DATA-001: Static verifier blocks prohibited terms; import boundary prevents legacy access
- [x] INV-DATA-002: Typed outcomes for every failure mode; negative tests for each
- [x] INV-HIST-001: Legacy generators unreachable from authoritative paths

## Predicted Failure Modes
1. **False positive on prohibited term in docstring/comment:** Improve allowlist with specific context. Do not add broad exclusions.
2. **Legitimate use of `random` in authoritative code (e.g., for future randomised experiment order):** Allowlist `numpy.random` only for declared stochastic algorithms with recorded seeds; block for evidence generation.
3. **A migrated function has a fallback branch that's hard to detect statically:** Add an explicit test case that exercises the branch. If the fallback exists, the test must fail.
4. **Gatekeeper acquisition-audit finds new hard failures:** Fix each one. Do not suppress without a reviewed, documented rule.

## Definition of Done
1. Zero prohibited-term matches in authoritative source (allowing only reviewed allowlist contexts)
2. Zero swallowed exceptions in authoritative source
3. Import boundary test passes — no legacy imports
4. Release boundary test passes — no fixture imports in production source
5. Typed acquisition outcomes implemented with negative tests for all failure modes
6. `acquisition-audit` against `source/` shows zero hard failures
7. Schema stubs exist (without claiming current data passes)
8. Contract report submitted with full audit output

## Stop Condition
- Any empirical command still has a generator/fallback reachable
- The verifier can be bypassed by a normal entry point
- Test fixtures can be loaded by experiment/production code
- External failure exits successfully (non-zero exit or typed error required)
- Production code catches an exception without structured propagation

## Traces To
- INV-DATA-001 (No Fabricated Evidence)
- INV-DATA-002 (Fail-Closed External Dependencies)
- INV-HIST-001 (Legacy Material Quarantine)
- NFR-002 (No fabricated evidence in authoritative paths)
- NFR-003 (Fail-closed error handling)
- Rehabilitation plan §9.7
