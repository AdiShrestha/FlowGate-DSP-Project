# Contract C01-02 — Factory Bootstrap, Repository Isolation, and Lifecycle Baseline

## Contract ID
C01-02

## Objective
Establish the exact v2.2.0 Factory structure without overwriting legacy content. Confirm the nested `project/` repository is independent and properly isolated. Commit the founding artefacts and verify Factory lifecycle commands recognise Chunk 01 as the next planned chunk.

## Context
Factory bootstrap has already been run once (bootstrap.sh executed earlier). This contract verifies that the bootstrap is complete and correct, commits the founding artefacts into the nested `project/` repository, and establishes the lifecycle baseline. The key property to verify is that `project/.git` is independent of the outer `.git` and that all Factory-private paths are properly ignored by the outer repository.

## Dependencies
- C01-01 (legacy state must be preserved before any structural changes)

## Risk Tier
Medium

## Implementation Owner
Implementor. Architect reviews Factory consistency.

## Scientific Claim Tier
NONE

## Allowed Files
- `project/**`
- `.gitignore` (append-only for Factory entries if missing)

## Frozen Files
- `factory/**` (read-only Factory infrastructure)
- `load-adaptive-iir/**`
- `source/**`

## Inputs
- Founding artefacts in `DROP_HERE/` (already sorted or to be sorted via `gatekeeper.py sort-dropbox`)
- Factory v2.2.0 files in `factory/`
- Current `.gitignore`

## Outputs

### 1. Bootstrap Verification Record (`project/chunks/chunk01/reports/C01-02/bootstrap_verification.md`)
- Factory version confirmed (2.2.0)
- All manifest-required files exist (list with hashes)
- `bootstrap.sh` command and output recorded
- Self-check output archived verbatim

### 2. Repository Isolation Proof (`project/chunks/chunk01/reports/C01-02/repo_isolation.md`)
- `git -C project rev-parse --git-dir` output (must be `.git`, not outer repo)
- `git -C project rev-parse --show-toplevel` output (must be `project/` path)
- `git check-ignore -v project/project_description.md` output (must show outer `.gitignore` ignoring it)
- `git check-ignore -v factory/VERSION` output (must show ignored)
- `git check-ignore -v DROP_HERE/dropbox_manifest.json` output (must show ignored)
- Confirmation that `project/` has its own `.git/` directory

### 3. Founding Artefact Commitment
- All 8 founding artefacts committed in nested `project/` repository:
  - `project/project_description.md`
  - `project/architecture.md`
  - `project/roadmap.md`
  - `project/project_knowledge.md`
  - `project/invariants.md`
  - `project/venue_requirements.md`
  - `project/key_facts.md`
  - `project/methodology_adversarial_review.md`
- Commit hash recorded

### 4. Lifecycle Baseline (`project/chunks/chunk01/reports/C01-02/lifecycle_baseline.md`)
- Gatekeeper status output (chunk/contract state)
- Verification that Chunk 01 is recognised as the next planned chunk
- Factory-private directory structure listing

## Implementation Instructions

1. Run `gatekeeper.py sort-dropbox` to move founding artefacts from `DROP_HERE/` to their `project/` destinations.
2. Verify sort results — every founding artefact should reach its expected `project/` location.
3. If any sort failures occur (e.g., unknown filenames), manually place the file at the correct `project/` location and document the discrepancy.
4. Confirm `project/.git` independence:
   ```bash
   git -C project rev-parse --git-dir  # should output ".git"
   git -C project rev-parse --show-toplevel  # should be the project/ absolute path
   ```
5. Verify outer repository ignores Factory-private paths:
   ```bash
   git check-ignore -v project/project_description.md
   git check-ignore -v factory/VERSION
   git check-ignore -v DROP_HERE/dropbox_manifest.json
   git check-ignore -v bootstrap.sh
   ```
6. Run Factory self-check:
   ```bash
   python3 factory/gatekeeper.py self-check
   ```
   Archive the complete output. Classify each finding:
   - Zero implementation/spec drift findings expected
   - Nine heuristic warnings expected (historical/example references) — classify each as `expected-historical` or `real-concern`
7. Commit all founding artefacts in the nested `project/` repository:
   ```bash
   python3 factory/gatekeeper.py commit-project -m "Project Initialization: founding artefacts"
   ```
   Record the commit hash.
8. Verify Gatekeeper recognises the project state:
   ```bash
   python3 factory/gatekeeper.py status
   ```
9. Create no implementation source beyond what bootstrap already created in `source/`.

## Verification Scripts
```bash
python3 factory/gatekeeper.py self-check
git -C project rev-parse --git-dir
git check-ignore -v project/project_description.md
```

## Invariant Checklist
- [ ] INV-HIST-001: Factory initialisation is recorded, not falsified
- [ ] INV-REPRO-001: Factory version pinned and recorded

## Predicted Failure Modes
1. **Sort-dropbox fails for a founding artefact:** Manually place at correct `project/` location. Document in report.
2. **Self-check reveals actual implementation/spec drift:** STOP. Report to Architect. Do not proceed.
3. **Nested repository points at outer `.git/`:** STOP. Re-initialise `project/.git` independently.
4. **Current files would be shadowed by sort:** STOP. Record conflict. Architect decision required.

## Definition of Done
1. All 8 founding artefacts committed in `project/` nested repository
2. Repository isolation verified (independent `.git/`, outer ignore confirmed)
3. Self-check passes with zero implementation/spec drift
4. Heuristic warnings classified
5. Lifecycle baseline recorded
6. Contract report submitted

## Stop Condition
- Bootstrap proposes overwriting a non-empty current path
- Factory version is not exactly the reviewed v2.2.0 snapshot
- Nested repository's `.git/` points at the outer Git directory
- Self-check reveals actual implementation/spec drift (not heuristic warnings)
- Current user files would be shadowed without a ledger decision

## Traces To
- INV-REPRO-001 (Clean-Room Reproducibility — Factory version pinning)
- INV-HIST-001 (Legacy Material Quarantine — honest migration record)
- Rehabilitation plan §§6.1, 6.2, 8.2
