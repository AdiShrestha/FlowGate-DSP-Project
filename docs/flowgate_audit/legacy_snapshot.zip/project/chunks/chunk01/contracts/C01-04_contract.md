# Contract C01-04 — Authoritative Source Scaffold and Behaviour-Preserving Migration

## Contract ID
C01-04

## Objective
Create the clean `source/` product skeleton per `architecture.md` and migrate reusable core code from the legacy tree without silently changing scientific behaviour. Known semantic defects are marked (xfail/quarantine) but not repaired — repairs belong to Chunk 04/06.

## Context
After C01-03 has classified every file and staged candidates for migration, this contract creates the actual package structure and moves code. The critical constraint is behaviour preservation: the migrated code must produce identical outputs on deterministic inputs. Scientific defects (arbitrary timebase, non-standard metrics, stability claims) are documented as known issues but not fixed here.

## Dependencies
- C01-03 (migration staging list must be complete)

## Risk Tier
Medium

## Implementation Owner
Implementor

## Scientific Claim Tier
NONE — migration preserves behaviour without validating its scientific meaning.

## Allowed Files
- `source/**`
- `project/chunks/chunk01/reports/C01-04/**`

## Frozen Files
- `factory/**`
- `project/project_description.md`
- `project/architecture.md`
- `project/invariants.md`

## Inputs
- C01-03 migration staging list
- `architecture.md` component structure
- Legacy source files in `load-adaptive-iir/src/`
- Legacy test files in `load-adaptive-iir/tests/`

## Outputs

### 1. Package Structure
Create the full `source/` skeleton per `architecture.md`:

```
source/
├── pyproject.toml              # Build definition with [project] metadata, dependencies, optional [dev] extras
├── README.md                   # Stub pointing to main README
├── src/
│   └── load_adaptive_iir/
│       ├── __init__.py         # Version, public API
│       ├── cli.py              # CLI entry points (stub)
│       ├── core/
│       │   ├── __init__.py
│       │   ├── filters.py      # Migrated from legacy filters.py
│       │   ├── numba_filters.py # Migrated if parity check passes
│       │   ├── zdomain.py      # Migrated from zdomain_analysis.py
│       │   └── reference.py    # Stub for Chunk 04 independent reference
│       ├── data/
│       │   ├── __init__.py
│       │   └── manifest.py     # Stub for data manifest schemas
│       ├── runtime/
│       │   ├── __init__.py
│       │   └── shedding.py     # Migrated from load_shedding.py
│       ├── evaluation/
│       │   └── __init__.py     # Stub for Chunk 06
│       └── reporting/
│           └── __init__.py     # Stub for Chunk 11
├── tests/
│   ├── __init__.py
│   ├── conftest.py             # Shared fixtures, markers, cache redirection
│   ├── unit/
│   │   └── __init__.py
│   ├── semantic/
│   │   └── __init__.py
│   ├── integration/
│   │   └── __init__.py
│   ├── scientific/
│   │   └── __init__.py
│   └── fixtures/
│       └── canonical/
│           └── README.md       # "Non-empirical mathematical test vectors only"
├── configs/
│   ├── acquisition/
│   ├── experiments/
│   └── schemas/
├── scripts/
│   ├── acquire/
│   ├── verify/
│   ├── reproduce/
│   └── release/
├── artifacts/
│   ├── README.md               # Artifact policy
│   └── release/
├── docs/
│   ├── manuscript/
│   ├── ku_report/
│   ├── reproducibility/
│   └── decisions/
└── app/                        # Empty — Chunk 10 only
```

### 2. `pyproject.toml`
- Package name: `load-adaptive-iir`
- Python requirement: `>=3.10` (exact scope decided in C01-07)
- Core dependencies: `numpy`, `scipy`, `pandas`, `matplotlib`
- Optional dev dependencies: `pytest`, `ruff`, `mypy`
- Optional `numba` (only if parity verified)
- Do NOT include `rrcf` — baseline decision is in Chunk 06
- Entry points: stub CLI commands
- Build system: `hatchling` or `setuptools` (Implementor's choice)

### 3. Migrated Core Code
For each file in the migration staging list:
1. Copy to the destination in `source/src/load_adaptive_iir/`
2. Update import paths from `from src.xxx` to `from load_adaptive_iir.xxx`
3. Remove any import-time side effects (plotting, data loading, experiment execution)
4. Mark known semantic defects with comments: `# KNOWN DEFECT [CHUNK-04]: <description>`
5. Do NOT fix the timebase, metrics, stability theory, or DSP semantics
6. Preserve the exact mathematical logic and output behaviour

### 4. Migrated Tests
For each legacy test file:
1. Classify per the migration staging list
2. Place in the appropriate `tests/` category (unit/semantic/integration/scientific)
3. Update imports to use the new package structure
4. Mark tests that rely on synthetic/random data with `@pytest.mark.xfail(reason="legacy synthetic fixture — Chunk 04")`
5. Mark tests that test invalid semantics with `@pytest.mark.xfail(reason="invalid premise — <description>")`
6. Do not delete any test — retire by marking, not removing

### 5. Migration Verification Record (`project/chunks/chunk01/reports/C01-04/migration_record.md`)
For each migrated file:
- Source path → destination path
- Source hash → destination hash (content hash, post-import-update)
- Behaviour comparison result on deterministic inputs (if applicable)
- Known defects marked
- Import-time side effects removed (list each)

## Implementation Instructions

1. Create the full directory skeleton first, with `__init__.py` stubs and README files.
2. Write `pyproject.toml` with minimal dependencies. Use `src/` layout (package at `src/load_adaptive_iir/`).
3. Migrate files one at a time in small, reviewable groups. Core filters first, then z-domain, then supporting modules.
4. For each migration:
   a. Copy the file
   b. Update all imports to use the new package path
   c. Remove import-time side effects (move to functions/CLI)
   d. Add `# KNOWN DEFECT` comments for each identified issue
   e. Verify the file imports cleanly: `python -c "from load_adaptive_iir.core import filters"`
5. **Do not** import from legacy directories (`load-adaptive-iir/src/`). The package must be self-contained.
6. **Do not** require data files for package import. All data access must be lazy/optional.
7. Ensure all caches (Matplotlib, Numba, pytest) can be redirected via environment variables.
8. Separate pure DSP code from data access, runtime control, evaluation, and reporting. If a legacy file mixes concerns, split it.
9. Introduce a basic exception hierarchy in `core/__init__.py` or a dedicated `exceptions.py`:
   ```python
   class FlowGateError(Exception): pass
   class BlockedExternalDependency(FlowGateError): pass
   class DataIntegrityError(FlowGateError): pass
   class ManifestError(FlowGateError): pass
   ```

## Verification Scripts
```bash
# Install in development mode and verify import
cd source && pip install -e '.[dev]' && python -c 'import load_adaptive_iir; print(load_adaptive_iir.__version__)'

# Run any migrated unit tests
cd source && python -m pytest tests/unit/ -x --tb=short

# Verify no imports from legacy tree
grep -r "from src\." source/src/ && echo "FAIL: legacy import found" || echo "PASS: no legacy imports"
grep -r "import src\." source/src/ && echo "FAIL: legacy import found" || echo "PASS: no legacy imports"
```

## Invariant Checklist
- [ ] INV-DATA-001: No fabricated-evidence generators migrated to authoritative package
- [ ] INV-HIST-001: Migration provenance recorded (source → destination with hashes)
- [ ] INV-REPRO-001: Package installs from source without legacy directories

## Predicted Failure Modes
1. **Import cycle after restructuring:** Resolve by moving shared definitions to `core/__init__.py` or a common module.
2. **Numba import fails on system without Numba:** Make Numba optional with a fallback import guard. Record as a known dependency decision.
3. **Legacy test requires generated data to pass:** Mark as xfail; do not create generated data to satisfy it.
4. **Behaviour change detected during migration:** STOP. Investigate whether the change is from import-path update or unintended logic change. If logic changed, revert and document.

## Definition of Done
1. `source/` directory structure matches `architecture.md`
2. `pyproject.toml` enables clean install in a fresh environment
3. Core filter code migrated with all imports updated
4. No import-time side effects in migrated code
5. Known semantic defects marked with `# KNOWN DEFECT [CHUNK-04]` comments
6. Migrated tests categorised and marked (xfail where appropriate)
7. Package imports without data files or legacy dependencies
8. Migration record with hashes submitted
9. Contract report submitted

## Stop Condition
- Migration requires generated data to make tests pass
- Authoritative imports reach legacy folders (`load-adaptive-iir/src/`)
- Source behaviour changes without an approved semantic requirement
- Dependency resolution is unrepeatable
- Test execution writes to tracked source files

## Traces To
- FR-001 through FR-004 (filter implementations)
- NFR-001 (clean-room reproducibility)
- INV-DATA-001 (no fabricated evidence in authoritative paths)
- INV-REPRO-001 (builds from clean clone)
- Rehabilitation plan §9.5
