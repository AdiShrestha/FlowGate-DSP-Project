# Contract C01-08 — Chunk Integration, Review, and Baseline Certification

## Contract ID
C01-08

## Objective
Integrate the previous seven contracts and decide whether scientific rehabilitation may proceed to Chunk 02. This is the Architect's final review of the entire chunk's work.

## Context
After all implementation contracts (C01-01 through C01-07) are complete, this contract performs a comprehensive integration review. It verifies that the repository has been transformed from its legacy dirty state into a Factory-native, buildable baseline with a functioning truth firewall. No scientific claims have been made; no data has been reprocessed; no algorithm has been validated.

## Dependencies
- C01-01 through C01-07 (all must be complete with submitted reports)

## Risk Tier
Medium

## Implementation Owner
Architect

## Scientific Claim Tier
NONE

## Allowed Files
- `project/chunks/chunk01/chunk_report.md`
- `project/chunks/chunk01/reports/C01-08/**`
- `project/chunks/chunk01/reality_gate_report.md`

## Frozen Files
- `factory/**`
- `source/**` (review only — no modifications)

## Inputs
- All C01-01 through C01-07 contract reports
- Current repository state (both outer and nested `project/`)
- Factory self-check output
- `key_facts.md` current content
- All founding artefacts

## Outputs

### 1. Integration Review Checklist (`project/chunks/chunk01/reports/C01-08/integration_review.md`)

#### A. Repository Structure
- [ ] Final tree matches `architecture.md` component structure
- [ ] `source/` is the only authoritative code surface
- [ ] `project/legacy_intake/` contains quarantined material, all marked non-authoritative
- [ ] No orphaned files exist outside expected locations
- [ ] Directory sizes are reasonable (no unexpected growth)

#### B. User Work Preservation
- [ ] Every moved path appears in the asset ledger (C01-01) and quarantine manifest (C01-03)
- [ ] No user work was lost (compare asset ledger with current filesystem)
- [ ] Human decisions were requested for all ambiguous files
- [ ] Deleted notebook disposition is recorded

#### C. Repository State
- [ ] Outer repository is in an understood, committed state
- [ ] Nested `project/` repository is in an understood, committed state
- [ ] Both repositories' `git status` is clean (or documented dirty items are expected)

#### D. Factory Verification
- [ ] `gatekeeper.py self-check` passes with zero implementation/spec drift
- [ ] `gatekeeper.py acquisition-audit --path source/` shows zero hard failures
- [ ] `gatekeeper.py lint-contract` against all 8 contracts shows zero hard failures
- [ ] Heuristic warnings are classified (not ignored)

#### E. Evidence Boundary
- [ ] Legacy results are unreachable from authoritative code (import boundary test passes)
- [ ] Legacy results are visibly marked non-authoritative (quarantine index labels)
- [ ] No legacy performance number has entered `key_facts.md`
- [ ] Experiment commands cannot load test fixtures (release boundary test passes)
- [ ] No fabrication/simulation terms in authoritative source (firewall test passes)

#### F. Build and Test
- [ ] Package builds and installs from a clean temporary environment
- [ ] All active tests pass (retired tests documented in disposition ledger)
- [ ] No globally suppressed warnings
- [ ] Lock file reproduces deterministically

#### G. Git Hygiene
- [ ] `.gitignore` policy is comprehensive and tested
- [ ] No authoritative source is ignored
- [ ] Untracking proposal produced (executed only with Human approval)

### 2. Reality Gate Status (`project/chunks/chunk01/reality_gate_report.md`)

```markdown
# Reality Gate Report — Chunk 01

**Status: NOT PASSED**

The Reality Gate has not been executed for publication data.
No data re-acquisition or re-verification has been performed in this chunk.
Current data is quarantined with status: UNVERIFIED.

The Reality Gate will be executed in Chunk 03 after data re-acquisition
with official checksum verification.

No text in this repository claims the data has passed the Reality Gate.
No experiment may use the current data as evidence.
```

### 3. Key Facts Audit
Verify `key_facts.md` contains:
- Only the verified baseline facts from Project Initialization
- No legacy AUC, throughput, quality-cost, or DeLong values
- No "certified" or "publication-ready" claims
- Explicitly excluded facts are still excluded

### 4. Chunk 02 Readiness Assessment
Document:
- What Chunk 02 must decide (scope freeze, venue publications, real-label feasibility, literature verification)
- What open scientific decisions exist
- What stop conditions apply to Chunk 02
- What prerequisite state Chunk 02 inherits

### 5. Chunk Report (`project/chunks/chunk01/chunk_report.md`)

Structure:
```markdown
# Chunk 01 Report — Forensic Intake, Factory Normalisation, and Truth Firewall

## Summary
[Brief description of what was accomplished]

## Contract Results

| Contract | Status | Key Findings |
|---|---|---|
| C01-01 | PASS/FAIL | [Summary] |
| C01-02 | PASS/FAIL | [Summary] |
| ... | ... | ... |

## Pass Criteria Assessment

| # | Criterion | Status | Evidence |
|---|---|---|---|
| 1 | Factory v2.2.0 pinned and operational | | self-check output |
| 2 | Founding artefacts committed | | commit hash |
| 3 | source/ is sole authoritative surface | | import boundary test |
| 4 | Clean-env build and test | | clean-env log |
| 5 | Zero fabrication paths in source | | firewall test + audit |
| 6 | Legacy preserved but unreachable | | quarantine manifest |
| 7 | Git ignores transient material | | ignore matrix |
| 8 | All assets have disposition | | ledger completeness |
| 9 | Reports stamped/verified | | report inventory |
| 10 | Next action is Chunk 02 | | readiness assessment |

## Limitations
[Honest documentation of what this chunk did NOT accomplish,
what decisions remain open, and what risks carry forward]

## Prohibited Claims
The following phrases remain prohibited until their respective
evidence gates are passed:
- "100% complete"
- "publication-ready"
- "zero quality cost"
- "real-time live anomaly detection"
- "Factory-certified"
```

## Implementation Instructions

1. Collect and read all seven contract reports (C01-01 through C01-07).
2. Work through every item in the integration review checklist. Mark each as pass/fail with evidence.
3. Re-run Factory verification commands:
   ```bash
   python3 factory/gatekeeper.py self-check
   python3 factory/gatekeeper.py acquisition-audit --path source/
   ```
4. Verify all contract reports against their artefacts — does each report accurately describe what was produced?
5. Review allowed-file diffs manually (Gatekeeper's allowed-file enforcement is not fully implemented).
6. Confirm the Reality Gate is NOT PASSED and no text claims otherwise.
7. Confirm no legacy performance number has entered `key_facts.md`.
8. Write the chunk report with honest limitations.
9. Document Chunk 02's open decisions and stop conditions.

If any pass criterion fails:
- Write a bounded fix package (`fix_package_chunk01.md`)
- The fix becomes the first contract(s) of Chunk 02 (or a re-execution within Chunk 01 if the failure is critical)
- No later chunk may work around a failed truth-firewall criterion

## Verification Scripts
```bash
python3 factory/gatekeeper.py self-check
python3 factory/gatekeeper.py acquisition-audit --path source/
```

## Invariant Checklist
- [ ] All 14 invariants from `invariants.md` assessed for this chunk
- [ ] INV-DATA-001: Confirmed no fabricated evidence in authoritative paths
- [ ] INV-HIST-001: Confirmed legacy material quarantined and marked
- [ ] INV-REPRO-001: Confirmed clean-environment build
- [ ] INV-SEC-001: Confirmed no secrets in public paths

## Predicted Failure Modes
1. **A contract report is missing or incomplete:** Request completion before proceeding. Do not certify without all reports.
2. **Import boundary test fails:** This is a critical failure. Write a fix package targeting the specific leak.
3. **Legacy number found in key_facts.md:** Remove it and document how it entered.
4. **Self-check reveals new drift:** Investigate and resolve before certifying.

## Definition of Done
1. Integration review checklist complete — all items pass or have documented fixes
2. Reality Gate status explicitly NOT PASSED
3. Key facts audit clean — no legacy performance values
4. Chunk report written with honest limitations
5. Chunk 02 readiness assessment complete
6. All 10 pass criteria assessed
7. Contract report submitted

## Stop Condition
- Any pass criterion fails without a bounded fix package
- A truth-firewall criterion (criteria 3, 5, 6) fails — this blocks ALL forward progress
- Missing contract report that cannot be recovered
- Evidence of undisclosed modifications during the chunk

## Traces To
- All founding artefact requirements (comprehensive integration review)
- Rehabilitation plan §9.9
- All 14 invariants (assessed at chunk boundary)
