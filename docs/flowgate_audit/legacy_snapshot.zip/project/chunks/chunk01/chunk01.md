# Chunk 01 — Forensic Intake, Factory Normalisation, and Truth Firewall

## Objective

Convert the dirty legacy repository into a losslessly preserved, Factory-native, buildable baseline in which authoritative source is separated from legacy material and no production/research path can generate or substitute empirical data.

## Scope

### Included

- Full legacy state preservation with asset ledger and hash-backed provenance
- Factory v2.2.0 bootstrap, repository isolation, nested Git verification
- File-by-file legacy disposition (quarantine, staging for migration, or retention)
- Authoritative `source/` scaffold with behaviour-preserving code migration
- Comprehensive `.gitignore` policy and Git hygiene (untracking, not deletion)
- Non-fabrication firewall: static verifier, import boundaries, typed failures, negative tests
- Deterministic build definition, lock file, CI baseline, and test migration ledger
- Chunk integration review and baseline certification

### Excluded

- Algorithm validation or semantic correction (Chunk 04)
- Data re-acquisition or re-processing (Chunk 03)
- Experimental design or protocol (Chunk 06)
- Manuscript or report writing (Chunk 11)
- Application rehabilitation (Chunk 10)
- History rewriting or force-push (Chunk 12, if ever)

## Repository State Required

- Outer repository on `main` branch, commit `f73dc1e` or later
- Working tree may be dirty (preservation is the first contract)
- Factory v2.2.0 files present in `factory/`
- `project/` nested repository exists with founding artifacts committed
- No active uncommitted implementation work in progress

## Deliverables

1. Legacy state preservation package and asset ledger (`C01-01`)
2. Factory bootstrap verification and founding artifact commitment (`C01-02`)
3. Legacy quarantine with source-to-destination manifest (`C01-03`)
4. Authoritative `source/` package scaffold with migrated core code (`C01-04`)
5. Reviewed `.gitignore` policy and untracking proposal (`C01-05`)
6. Non-fabrication firewall: static verifier, import/release boundary tests, typed failures (`C01-06`)
7. Deterministic build, CI baseline, and test disposition ledger (`C01-07`)
8. Chunk integration review and baseline certification report (`C01-08`)

## Success Criteria

1. Factory v2.2.0 pinned and operational (self-check passes)
2. Founding artifacts committed in nested `project/` repository
3. `source/` is the only authoritative code surface
4. Package builds and installs from a clean temporary environment
5. Zero synthetic generators, simulated-load evidence paths, silent fallbacks, or swallowed-exception hard failures in authoritative source
6. Legacy data/results/documents preserved but unreachable from authoritative code
7. Git ignores transient material without hiding product source
8. Every dirty-state asset has a completed disposition; no user work lost
9. Every contract report stamped/verified; chunk report records limitations
10. Next action is Chunk 02, not an experiment run

## Acceptance Criteria

- All 8 contract reports submitted and verified
- Gatekeeper `self-check` passes
- Gatekeeper `acquisition-audit` against `source/` shows zero hard failures
- Gatekeeper `lint-contract` against all 8 contracts shows zero hard failures
- Clean temporary environment install succeeds
- Reality Gate status explicitly says NOT PASSED for publication data
- No legacy performance number appears in `key_facts.md`

## Contract List

| ID | Title | Risk | Owner | Tier | Dependencies |
|---|---|---|---|---|---|
| C01-01 | Legacy State Preservation and Asset Ledger | Medium | Architect (spec) + Implementor (scripts) | T-DESC | None |
| C01-02 | Factory Bootstrap, Repository Isolation, and Lifecycle Baseline | Medium | Implementor | NONE | C01-01 |
| C01-03 | Legacy Quarantine and File-by-File Disposition | High | Architect (spec) + Implementor (moves) | NONE | C01-01, C01-02 |
| C01-04 | Authoritative Source Scaffold and Behaviour-Preserving Migration | Medium | Implementor | NONE | C01-03 |
| C01-05 | Git Hygiene and Ignore Policy | High (untracking) / Medium (ignores) | Implementor + Human approval | NONE | C01-04 |
| C01-06 | Non-Fabrication Firewall and Fail-Closed Interfaces | High | Architect | NONE | C01-04 |
| C01-07 | Deterministic Build, Test, and CI Baseline | Medium | Implementor | NONE | C01-04, C01-06 |
| C01-08 | Chunk Integration, Review, and Baseline Certification | Medium | Architect | NONE | C01-01 through C01-07 |

## Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| User's dirty work lost during cleanup | High | Critical | C01-01 ledger with hashes; no deletion without Human approval |
| Legacy results leak into authoritative paths | Medium | Critical | Import-boundary test; static audit; release-boundary test |
| `.gitignore` hides real source | Medium | High | Positive and negative ignore tests; C01-05 matrix |
| Migration silently changes scientific behaviour | Medium | High | Behaviour comparison on deterministic vectors; xfail markers |
| Factory private artifacts leak into outer repo | Medium | Medium | `git check-ignore` verification; release tree audit |

## References

- `rehabilitation_plan.md` §§8–11
- `architecture.md` (founding artifact)
- `invariants.md` (founding artifact)
- `factory/factory_spec.md`
- `factory/constitution.md`

## Scientific Claim Tier

**NONE** for all migration/infrastructure contracts. **T-DESC** only for C01-01's literal observed counts in the asset ledger. No detector-performance, resource, robustness, or publication conclusion may be made in this chunk.

## Explicit Non-Goals

Chunk 01 does **not**:
- Validate the algorithm or its scientific claims
- Preserve legacy metric values as authoritative
- Download or reprocess the full dataset
- Redesign the DSP equations or timebase
- Run final experiments
- Rehabilitate the UI/dashboard
- Write the final paper or KU report
