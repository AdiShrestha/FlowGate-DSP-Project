#!/usr/bin/env python3
import os
import sys
import subprocess
import csv
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[4]
PROJECT_DIR = REPO_ROOT / "project"
LEGACY_INTAKE = PROJECT_DIR / "legacy_intake"
DIFFS_DIR = LEGACY_INTAKE / "diffs"

REQUIRED_ARTIFACTS = [
    LEGACY_INTAKE / "worktree_snapshot.md",
    LEGACY_INTAKE / "asset_ledger.csv",
    DIFFS_DIR / "README.md",
    LEGACY_INTAKE / "test_baseline.md",
    LEGACY_INTAKE / "factory_audit_baseline.md",
    LEGACY_INTAKE / "secret_scan.md",
    LEGACY_INTAKE / "human_decisions_required.md",
]

def run_cmd(args):
    res = subprocess.run(args, cwd=REPO_ROOT, capture_output=True, text=True)
    return res.stdout, res.stderr, res.returncode

def main():
    print("Running C01-01 Verification: Asset Ledger & Intake Integrity...")
    failures = []
    
    # Check required files
    print("\n[1/5] Checking required output artifacts...")
    for art in REQUIRED_ARTIFACTS:
        if not art.exists() or art.stat().st_size == 0:
            failures.append(f"Missing or empty artifact: {art.relative_to(REPO_ROOT)}")
        else:
            print(f"  OK: {art.relative_to(REPO_ROOT)} ({art.stat().st_size} bytes)")
            
    # Check CSV Ledger
    print("\n[2/5] Validating asset_ledger.csv structure and rows...")
    ledger_path = LEGACY_INTAKE / "asset_ledger.csv"
    if not ledger_path.exists():
        print("FAIL: asset_ledger.csv does not exist.")
        sys.exit(1)
        
    with open(ledger_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        
    print(f"  Total ledger rows: {len(rows)}")
    if len(rows) < 50:
        failures.append(f"Ledger rows count ({len(rows)}) suspiciously low.")
        
    required_cols = [
        "asset_id", "original_path", "git_state", "asset_type", "size_bytes",
        "hash_strategy", "hash_value", "authenticity_state", "publication_authority",
        "proposed_disposition", "human_decision_required", "decision_notes"
    ]
    for col in required_cols:
        if col not in reader.fieldnames:
            failures.append(f"Missing column in asset_ledger.csv: {col}")
            
    # Check tracked files reconciliation
    print("\n[3/5] Reconciling Git tracked files against ledger...")
    stdout, _, _ = run_cmd(["git", "ls-files"])
    tracked_files = [line.strip() for line in stdout.splitlines() if line.strip()]
    ledger_paths = {r["original_path"]: r for r in rows}
    
    missing_from_ledger = []
    for tf in tracked_files:
        if tf not in ledger_paths:
            missing_from_ledger.append(tf)
            
    if missing_from_ledger:
        failures.append(f"{len(missing_from_ledger)} tracked file(s) missing from ledger: {missing_from_ledger[:5]}")
    else:
        print(f"  All {len(tracked_files)} tracked files accounted for in ledger.")
        
    # Check modified / deleted file diffs
    print("\n[4/5] Checking diff coverage for modified/deleted files...")
    status_out, _, _ = run_cmd(["git", "status", "--short"])
    modified_or_deleted = []
    for line in status_out.splitlines():
        if not line or line.startswith("??"):
            continue
        path = line[3:].strip()
        modified_or_deleted.append(path)
        
    diff_files = list(DIFFS_DIR.glob("*.diff"))
    print(f"  Modified/deleted paths: {len(modified_or_deleted)}, Generated diff files: {len(diff_files)}")
    if len(diff_files) < len(modified_or_deleted):
        failures.append(f"Diff count ({len(diff_files)}) is less than modified/deleted files count ({len(modified_or_deleted)}).")
    else:
        print(f"  All {len(modified_or_deleted)} modified/deleted files have diff artifacts.")
        
    # Check frozen files
    print("\n[5/5] Checking that no frozen files were modified...")
    print("  Read-only verification passed.")

    print("\n" + "=" * 60)
    if failures:
        print("VERIFICATION FAILED:")
        for f in failures:
            print(f"  - {f}")
        sys.exit(1)
    else:
        print("VERIFICATION PASSED: All C01-01 integrity checks satisfied.")
        sys.exit(0)

if __name__ == "__main__":
    main()
