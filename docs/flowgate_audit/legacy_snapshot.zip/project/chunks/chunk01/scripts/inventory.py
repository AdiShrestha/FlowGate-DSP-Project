#!/usr/bin/env python3
import os, sys, subprocess, hashlib, csv, re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[4]
PROJECT_DIR = REPO_ROOT / "project"
LEGACY_INTAKE = PROJECT_DIR / "legacy_intake"
DIFFS_DIR = LEGACY_INTAKE / "diffs"

def run_git(args):
    res = subprocess.run(["git"] + args, cwd=REPO_ROOT, capture_output=True, text=True)
    return res.stdout, res.stderr, res.returncode

def sha256_file(filepath, max_bytes=None):
    h = hashlib.sha256()
    try:
        with open(filepath, "rb") as f:
            if max_bytes:
                chunk = f.read(max_bytes)
                h.update(chunk)
            else:
                while True:
                    chunk = f.read(65536)
                    if not chunk:
                        break
                    h.update(chunk)
        return h.hexdigest()
    except Exception as e:
        return f"HASH-ERROR: {e}"

def get_dir_size(path):
    total = 0
    if not path.exists():
        return 0
    if path.is_file():
        return path.stat().st_size
    for root, dirs, files in os.walk(path):
        for f in files:
            fp = Path(root) / f
            try:
                if not fp.is_symlink():
                    total += fp.stat().st_size
            except OSError:
                pass
    return total

def format_size(size_bytes):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"

def main():
    LEGACY_INTAKE.mkdir(parents=True, exist_ok=True)
    DIFFS_DIR.mkdir(parents=True, exist_ok=True)
    
    print("Capturing Git repository status...")
    status_out, _, _ = run_git(["status", "--short", "--branch"])
    branch_out, _, _ = run_git(["branch", "--show-current"])
    head_hash, _, _ = run_git(["rev-parse", "HEAD"])
    remote_out, _, _ = run_git(["remote", "-v"])
    tags_out, _, _ = run_git(["tag", "-l"])
    log_out, _, _ = run_git(["log", "--oneline", "-10"])
    tracked_files_out, _, _ = run_git(["ls-files"])
    tracked_files = [f for f in tracked_files_out.splitlines() if f.strip()]
    
    # 1. Capture worktree_snapshot.md
    print("Writing worktree_snapshot.md...")
    
    key_dirs = [
        "load-adaptive-iir",
        "load-adaptive-iir/data/raw",
        "load-adaptive-iir/data/processed",
        "load-adaptive-iir/data",
        "Isolated-Backend",
        "React-Frontend",
        "load-adaptive-iir/results",
        ".git",
        "project",
        "factory",
        "source"
    ]
    
    dir_sizes = {}
    for kd in key_dirs:
        dir_sizes[kd] = get_dir_size(REPO_ROOT / kd)
    
    total_workspace_size = get_dir_size(REPO_ROOT)
    
    tracked_size = sum(
        (REPO_ROOT / tf).stat().st_size
        for tf in tracked_files
        if (REPO_ROOT / tf).exists() and not (REPO_ROOT / tf).is_dir()
    )
    
    # Parse git status lines
    modified_files = []
    deleted_files = []
    untracked_files = []
    
    for line in status_out.splitlines():
        if not line or line.startswith("##"):
            continue
        code = line[:2]
        path = line[3:].strip()
        if "M" in code:
            modified_files.append(path)
        elif "D" in code:
            deleted_files.append(path)
        elif "??" in code:
            untracked_files.append(path)

    snapshot_content = f"""# FlowGate Legacy Worktree Snapshot
**Captured Date:** 2026-09-01
**Contract ID:** C01-01
**Purpose:** Forensic record of starting working tree state before rehabilitation.

---

## 1. Git Repository State

- **Current Branch:** `{branch_out.strip()}`
- **HEAD Commit Hash:** `{head_hash.strip()}`
- **Remote URLs:**
```
{remote_out.strip()}
```
- **Tags:** `{tags_out.strip() or "None"}`
- **Tracked File Count:** {len(tracked_files)}
- **Total Tracked Files Size:** {tracked_size} bytes ({format_size(tracked_size)})
- **Total Workspace Size:** {total_workspace_size} bytes ({format_size(total_workspace_size)})

### Recent Git Log (Last 10 Commits)
```
{log_out.strip()}
```

### Git Status (`git status --short --branch`)
```
{status_out.strip()}
```

---

## 2. Directory-Level Size Breakdown

| Directory Path | Size (Bytes) | Human-Readable Size | Description / Role |
|---|---|---|---|
| `.git/` | {dir_sizes[".git"]} | {format_size(dir_sizes[".git"])} | Git repository database & objects |
| `load-adaptive-iir/` | {dir_sizes["load-adaptive-iir"]} | {format_size(dir_sizes["load-adaptive-iir"])} | Legacy Python project root |
| `load-adaptive-iir/data/raw/` | {dir_sizes["load-adaptive-iir/data/raw"]} | {format_size(dir_sizes["load-adaptive-iir/data/raw"])} | Raw Binance trade archives (ZIP) |
| `load-adaptive-iir/data/processed/` | {dir_sizes["load-adaptive-iir/data/processed"]} | {format_size(dir_sizes["load-adaptive-iir/data/processed"])} | Legacy processed Parquet datasets |
| `load-adaptive-iir/results/` | {dir_sizes["load-adaptive-iir/results"]} | {format_size(dir_sizes["load-adaptive-iir/results"])} | Legacy generated experiment results & plots |
| `Isolated-Backend/` | {dir_sizes["Isolated-Backend"]} | {format_size(dir_sizes["Isolated-Backend"])} | Legacy Node.js backend server |
| `React-Frontend/` | {dir_sizes["React-Frontend"]} | {format_size(dir_sizes["React-Frontend"])} | Legacy React web frontend |
| `project/` | {dir_sizes["project"]} | {format_size(dir_sizes["project"])} | Factory project directory (nested repo) |
| `factory/` | {dir_sizes["factory"]} | {format_size(dir_sizes["factory"])} | Software Factory v2.2.0 machinery |
| `source/` | {dir_sizes["source"]} | {format_size(dir_sizes["source"])} | Authoritative source directory (to be populated) |

---

## 3. Working Tree Status Summary

- **Modified Tracked Files ({len(modified_files)}):**
"""
    for mf in modified_files:
        snapshot_content += f"- `{mf}`\n"
    
    snapshot_content += f"\n- **Deleted Tracked Files ({len(deleted_files)}):**\n"
    for df in deleted_files:
        snapshot_content += f"- `{df}`\n"
        
    snapshot_content += f"\n- **Untracked Paths Count:** {len(untracked_files)}\n"
    
    with open(LEGACY_INTAKE / "worktree_snapshot.md", "w", encoding="utf-8") as f:
        f.write(snapshot_content)

    # 2. Extract Diffs
    print("Extracting diffs for modified tracked files...")
    diff_index = []
    for mf in modified_files:
        diff_out, _, _ = run_git(["diff", mf])
        safe_name = mf.replace("/", "_").replace(".", "_") + ".diff"
        diff_path = DIFFS_DIR / safe_name
        with open(diff_path, "w", encoding="utf-8") as f:
            f.write(diff_out)
        diff_index.append((mf, safe_name, len(diff_out.splitlines())))
    
    for df in deleted_files:
        diff_out, _, _ = run_git(["diff", df])
        safe_name = "DELETED_" + df.replace("/", "_").replace(".", "_") + ".diff"
        diff_path = DIFFS_DIR / safe_name
        with open(diff_path, "w", encoding="utf-8") as f:
            f.write(diff_out)
        diff_index.append((df + " (DELETED)", safe_name, len(diff_out.splitlines())))

    # Write diffs README
    with open(DIFFS_DIR / "README.md", "w", encoding="utf-8") as f:
        f.write("# Legacy Intake Modified File Diffs\n\n")
        f.write("| Original File | Diff File | Line Count |\n|---|---|---|\n")
        for orig, dfile, lcount in diff_index:
            f.write(f"| `{orig}` | [`{dfile}`](./{dfile}) | {lcount} |\n")

    # 3. Build Asset Ledger
    print("Building asset_ledger.csv...")
    ledger_rows = []
    asset_counter = 1
    
    for tf in sorted(tracked_files):
        p = REPO_ROOT / tf
        if not p.exists():
            git_st = "deleted"
            size = 0
            hval = "DELETED"
            hstrat = "none"
        else:
            git_st = "modified" if tf in modified_files else "tracked"
            size = p.stat().st_size
            if size > 10 * 1024 * 1024:
                hstrat = "sha256-first-1mb"
                hval = sha256_file(p, max_bytes=1024*1024)
            else:
                hstrat = "sha256-file"
                hval = sha256_file(p)

        atype = "unknown"
        if tf.endswith(".py"):
            atype = "test" if "test" in tf else "source"
        elif tf.endswith(".md") or tf.endswith(".tex"):
            atype = "document"
        elif tf.endswith(".json") or tf.endswith(".yaml") or tf.endswith(".yml") or tf.endswith(".toml"):
            atype = "config"
        elif tf.endswith(".csv") or tf.endswith(".parquet"):
            atype = "result" if "result" in tf else "processed-data"
        elif tf.endswith(".js") or tf.endswith(".jsx") or tf.endswith(".html") or tf.endswith(".css"):
            atype = "application"
        elif tf.endswith(".sh"):
            atype = "config"
        elif tf.endswith(".ipynb"):
            atype = "document"

        auth_state = "unverified-authentic"
        pub_auth = "legacy-only"
        disp = "quarantine-legacy-intake"
        h_dec = "no"
        notes = "Legacy tracked file."

        if tf.startswith("factory/"):
            pub_auth = "transient"
            disp = "retain-as-is"
            notes = "Software Factory machinery (pinned v2.2.0)"
            auth_state = "verified-authentic"
        elif tf.startswith("project/"):
            pub_auth = "transient"
            disp = "retain-as-is"
            notes = "Factory project governance artifact"
            auth_state = "verified-authentic"
        elif tf.startswith("source/"):
            pub_auth = "authoritative"
            disp = "retain-as-is"
            notes = "Authoritative product source"
        elif tf.startswith("load-adaptive-iir/src/"):
            if any(k in tf for k in ["demo_signals", "anomaly_injection", "queue_simulator", "experiment_", "fp_paradox", "multi_seed", "run_all"]):
                pub_auth = "forbidden-evidence"
                disp = "quarantine-legacy-intake"
                auth_state = "generated"
                notes = "Contains synthetic generators, simulated load, or pseudo-replication. Strictly forbidden from authoritative evidence."
            else:
                pub_auth = "candidate"
                disp = "migrate-to-source"
                notes = "Core DSP code staged for C01-04 migration with known defects marked."
        elif tf.startswith("load-adaptive-iir/tests/"):
            pub_auth = "candidate"
            disp = "migrate-to-source"
            notes = "Legacy test suite staged for migration and classification in C01-07."
        elif tf.startswith("load-adaptive-iir/results/"):
            pub_auth = "forbidden-evidence"
            disp = "quarantine-legacy-intake"
            auth_state = "generated"
            notes = "Legacy generated results; not certified."
        elif tf in ["rehabilitation_plan.md"]:
            pub_auth = "legacy-only"
            disp = "retain-as-is"
            notes = "Master rehabilitation plan."
        elif tf in ["build_mega_context.py", "dsp_project_build_prompt.md", "fix1.md", "mega_report_context.md", "project_context.md", "study.md", "load_adaptive_iir_literature_review.md", "report_v2.tex", "ku_format.md"]:
            pub_auth = "legacy-only"
            disp = "quarantine-legacy-intake"
            notes = "Quarantine to project/legacy_intake per rehabilitation plan §10."
        elif tf.startswith("Isolated-Backend/") or tf.startswith("React-Frontend/"):
            pub_auth = "candidate"
            disp = "retain-as-is"
            notes = "Legacy UI/backend demonstration. Retained in place pending Chunk 10 entry gate."
        elif tf == "load-adaptive-iir/notebooks/01_full_pipeline.ipynb" and git_st == "deleted":
            h_dec = "yes"
            notes = "Deleted legacy notebook. Decision requested on whether to preserve deletion or restore for quarantine."

        aid = f"AST-TRK-{asset_counter:04d}"
        asset_counter += 1
        ledger_rows.append({
            "asset_id": aid,
            "original_path": tf,
            "git_state": git_st,
            "asset_type": atype,
            "size_bytes": size,
            "hash_strategy": hstrat,
            "hash_value": hval,
            "authenticity_state": auth_state,
            "publication_authority": pub_auth,
            "proposed_disposition": disp,
            "human_decision_required": h_dec,
            "decision_notes": notes,
            "final_migrated_path": ""
        })

    # Grouped untracked files
    raw_dir = REPO_ROOT / "load-adaptive-iir" / "data" / "raw"
    if raw_dir.exists():
        raw_zips = sorted(list(raw_dir.glob("*.zip")))
        raw_size = sum(z.stat().st_size for z in raw_zips)
        sample_hash = sha256_file(raw_zips[0], max_bytes=1024*1024) if raw_zips else "NONE"
        aid = f"AST-GRP-{asset_counter:04d}"
        asset_counter += 1
        ledger_rows.append({
            "asset_id": aid,
            "original_path": "load-adaptive-iir/data/raw/*.zip (155 files)",
            "git_state": "untracked",
            "asset_type": "raw-data",
            "size_bytes": raw_size,
            "hash_strategy": "sha256-first-1mb-sample",
            "hash_value": f"sample_first_file_hash:{sample_hash}",
            "authenticity_state": "unverified-authentic",
            "publication_authority": "legacy-only",
            "proposed_disposition": "untrack-ignore",
            "human_decision_required": "no",
            "decision_notes": "155 daily Binance aggregate trade ZIP archives across 5 symbols (Jan 2024). Quarantined in place.",
            "final_migrated_path": ""
        })

    proc_dir = REPO_ROOT / "load-adaptive-iir" / "data" / "processed"
    if proc_dir.exists():
        proc_files = sorted(list(proc_dir.glob("*.parquet")))
        proc_size = sum(p.stat().st_size for p in proc_files)
        sample_hash = sha256_file(proc_files[0], max_bytes=1024*1024) if proc_files else "NONE"
        aid = f"AST-GRP-{asset_counter:04d}"
        asset_counter += 1
        ledger_rows.append({
            "asset_id": aid,
            "original_path": "load-adaptive-iir/data/processed/*.parquet (5 files)",
            "git_state": "untracked",
            "asset_type": "processed-data",
            "size_bytes": proc_size,
            "hash_strategy": "sha256-first-1mb-sample",
            "hash_value": f"sample_first_file_hash:{sample_hash}",
            "authenticity_state": "unverified-authentic",
            "publication_authority": "forbidden-evidence",
            "proposed_disposition": "untrack-ignore",
            "human_decision_required": "no",
            "decision_notes": "Legacy processed Parquet files (~73.8M rows). Discarded identity fields; non-certified.",
            "final_migrated_path": ""
        })

    nm_dir = REPO_ROOT / "React-Frontend" / "node_modules"
    if nm_dir.exists():
        nm_size = get_dir_size(nm_dir)
        aid = f"AST-GRP-{asset_counter:04d}"
        asset_counter += 1
        ledger_rows.append({
            "asset_id": aid,
            "original_path": "React-Frontend/node_modules/**",
            "git_state": "untracked",
            "asset_type": "environment",
            "size_bytes": nm_size,
            "hash_strategy": "count-only",
            "hash_value": "DIRECTORY_GROUP",
            "authenticity_state": "not-applicable",
            "publication_authority": "transient",
            "proposed_disposition": "untrack-ignore",
            "human_decision_required": "no",
            "decision_notes": "Node.js dependencies for legacy React frontend. Excluded via .gitignore.",
            "final_migrated_path": ""
        })

    for cache_name in [".pytest_cache", "Isolated-Backend/__pycache__"]:
        cdir = REPO_ROOT / cache_name
        if cdir.exists():
            csize = get_dir_size(cdir)
            aid = f"AST-GRP-{asset_counter:04d}"
            asset_counter += 1
            ledger_rows.append({
                "asset_id": aid,
                "original_path": f"{cache_name}/**",
                "git_state": "untracked",
                "asset_type": "cache",
                "size_bytes": csize,
                "hash_strategy": "count-only",
                "hash_value": "DIRECTORY_GROUP",
                "authenticity_state": "not-applicable",
                "publication_authority": "transient",
                "proposed_disposition": "untrack-ignore",
                "human_decision_required": "no",
                "decision_notes": "Python/pytest cache directory. Excluded via .gitignore.",
                "final_migrated_path": ""
            })

    other_untracked = [
        "load-adaptive-iir/notebooks/.DS_Store",
        "load-adaptive-iir/results/tables/paired_ttest_results.csv",
        "load-adaptive-iir/tests/test_anomaly_injection.py",
        "load-adaptive-iir/tests/test_detection.py",
        "load-adaptive-iir/tests/test_filter_stability.py",
        "load-adaptive-iir/tests/test_statistical_tests.py"
    ]
    for ou in other_untracked:
        p = REPO_ROOT / ou
        if p.exists():
            size = p.stat().st_size
            hstrat = "sha256-file"
            hval = sha256_file(p)
            aid = f"AST-UNT-{asset_counter:04d}"
            asset_counter += 1
            ledger_rows.append({
                "asset_id": aid,
                "original_path": ou,
                "git_state": "untracked",
                "asset_type": "result" if "result" in ou else ("test" if "test" in ou else "cache"),
                "size_bytes": size,
                "hash_strategy": hstrat,
                "hash_value": hval,
                "authenticity_state": "generated" if "result" in ou else "unverified-authentic",
                "publication_authority": "forbidden-evidence" if "result" in ou else "candidate",
                "proposed_disposition": "quarantine-legacy-intake" if "result" in ou else "migrate-to-source",
                "human_decision_required": "no",
                "decision_notes": "Untracked legacy file recorded in forensic intake.",
                "final_migrated_path": ""
            })

    csv_path = LEGACY_INTAKE / "asset_ledger.csv"
    fieldnames = [
        "asset_id", "original_path", "git_state", "asset_type", "size_bytes",
        "hash_strategy", "hash_value", "authenticity_state", "publication_authority",
        "proposed_disposition", "human_decision_required", "decision_notes", "final_migrated_path"
    ]
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(ledger_rows)
    
    print(f"Asset ledger written to {csv_path} ({len(ledger_rows)} entries).")

if __name__ == "__main__":
    main()
