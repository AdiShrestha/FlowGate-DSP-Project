import os
import sys
import shutil
import hashlib
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[4]
PROJECT_DIR = REPO_ROOT / "project"
LEGACY_INTAKE = PROJECT_DIR / "legacy_intake"

def sha256_file(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

quarantine_copies = [
    ("build_mega_context.py", "tools/build_mega_context.py", "tools", "One-off context builder; historical tool"),
    ("dsp_project_build_prompt.md", "requirements/dsp_project_build_prompt.md", "requirements", "Historical LLM build prompt and specification"),
    ("fix1.md", "notes/fix1.md", "notes", "Legacy repair instructions / notes"),
    ("mega_report_context.md", "documents/mega_report_context.md", "documents", "Generated context document with stale metrics"),
    ("project_context.md", "documents/project_context.md", "documents", "Legacy claims and metrics document"),
    ("study.md", "reviews/study.md", "reviews", "Legacy adversarial analysis and suggestions"),
    ("load_adaptive_iir_literature_review.md", "literature/load_adaptive_iir_literature_review.md", "literature", "Literature review search lead (unverified citations)"),
    ("report_v2.tex", "manuscripts/report_v2.tex", "manuscripts", "Legacy IEEE LaTeX manuscript draft"),
    ("ku_format.md", "venue_inputs/ku_format.md", "venue_inputs", "KU formatting reference notes"),
    ("load-adaptive-iir/README.md", "documents/legacy_README.md", "documents", "Legacy package README with simulated claims"),
    ("load-adaptive-iir/requirements.txt", "requirements/legacy_requirements.txt", "requirements", "Legacy unpinned dependencies specification")
]

print("Executing quarantine copies...")
index_rows = []
for src_rel, dst_rel, cat, rationale in quarantine_copies:
    src_p = REPO_ROOT / src_rel
    dst_p = LEGACY_INTAKE / dst_rel
    dst_p.parent.mkdir(parents=True, exist_ok=True)
    
    src_hash = sha256_file(src_p)
    shutil.copy2(src_p, dst_p)
    dst_hash = sha256_file(dst_p)
    
    if src_hash != dst_hash:
        print(f"FATAL: Hash mismatch on {src_rel} -> {dst_rel}!")
        sys.exit(1)
        
    print(f"  OK: {src_rel} -> {dst_rel} ({dst_p.stat().st_size} bytes, sha256:{src_hash[:8]}...)")
    index_rows.append({
        "original_path": src_rel,
        "quarantined_path": f"project/legacy_intake/{dst_rel}",
        "rel_link": dst_rel,
        "category": cat,
        "size_bytes": dst_p.stat().st_size,
        "sha256": src_hash,
        "authority": "LEGACY — NON-AUTHORITATIVE",
        "rationale": rationale
    })

# 1. Write quarantine_index.md
quarantine_index_content = """# FlowGate Legacy Intake: Quarantine Index

**Captured Date:** 2026-09-01
**Contract ID:** C01-03
**Owner:** Architect
**Authority Statement:** Every file listed below is preserved strictly for forensic and historical audit purposes. None of these files are authoritative, and no claim, number, or implementation detail in them may enter the authoritative research evidence package without passing through the full Software Factory evidence lifecycle.

---

## Quarantined Assets Inventory

| Original Path | Quarantined Path | Category | Size (B) | SHA-256 Hash | Authority Status | Audit Rationale |
|---|---|---|---|---|---|---|
"""
for r in index_rows:
    orig = r["original_path"]
    qpath = r["quarantined_path"]
    rlink = r["rel_link"]
    cat = r["category"]
    sb = r["size_bytes"]
    shash = r["sha256"]
    auth = r["authority"]
    rat = r["rationale"]
    quarantine_index_content += f"| `{orig}` | [`{qpath}`](./{rlink}) | `{cat}` | {sb} | `{shash}` | `{auth}` | {rat} |\n"

quarantine_index_content += """
---

## Summary of Quarantined Categories
- `tools/`: 1 file (one-off scripts)
- `requirements/`: 2 files (historical prompts and unpinned deps)
- `notes/`: 1 file (legacy fix notes)
- `documents/`: 3 files (legacy README, project contexts)
- `reviews/`: 1 file (legacy adversarial study)
- `literature/`: 1 file (unverified literature notes)
- `manuscripts/`: 1 file (legacy IEEE draft)
- `venue_inputs/`: 1 file (KU format reference)
"""

(LEGACY_INTAKE / "quarantine_index.md").write_text(quarantine_index_content)
print("Wrote quarantine_index.md")

# 2. Write migration_staging.md
filters_hash = sha256_file(REPO_ROOT / "load-adaptive-iir/src/filters.py")
numba_hash = sha256_file(REPO_ROOT / "load-adaptive-iir/src/numba_filters.py")
zdomain_hash = sha256_file(REPO_ROOT / "load-adaptive-iir/src/zdomain_analysis.py")
shedding_hash = sha256_file(REPO_ROOT / "load-adaptive-iir/src/load_shedding.py")
visualize_hash = sha256_file(REPO_ROOT / "load-adaptive-iir/src/visualize.py")

migration_staging_content = f"""# FlowGate Legacy Intake: Migration Staging

**Captured Date:** 2026-09-01
**Contract ID:** C01-03
**Target Contract:** C01-04 (Authoritative Source Scaffold and Migration)

---

## 1. Core Source Staging Matrix

The following legacy source files are approved for migration to `source/src/load_adaptive_iir/` under Contract C01-04. Behaviour must be preserved initially, with known semantic defects explicitly tagged with comments (`# KNOWN DEFECT [CHUNK-04]: ...`) and repaired only in subsequent chunks.

| Legacy Source Path | Authoritative Destination | Target Subsystem | SHA-256 (Source) | Known Defects / Migration Directives |
|---|---|---|---|---|
| `load-adaptive-iir/src/filters.py` | `source/src/load_adaptive_iir/core/filters.py` | Core DSP | `{filters_hash}` | 1. Zero-state vs warm-start initial condition semantics undefined.<br>2. Fixed EMA alpha parameter confusing pole vs smoothing constant.<br>3. Butterworth uses arbitrary `fs=100.0Hz` without timebase justification.<br>4. KAMA first-update warm-up missing.<br>5. Preserve behavior; mark defects. |
| `load-adaptive-iir/src/numba_filters.py` | `source/src/load_adaptive_iir/core/numba_filters.py` | Core DSP (Optimised) | `{numba_hash}` | 1. Dependency unpinned (requires NumPy <=2.4 on Numba 0.60).<br>2. Add optional import guard; migrate for parity verification in Chunk 04. |
| `load-adaptive-iir/src/zdomain_analysis.py` | `source/src/load_adaptive_iir/core/zdomain.py` | Core Analytical | `{zdomain_hash}` | 1. Frozen-time pole claims presented as time-varying global stability proofs.<br>2. Remove import-time matplotlib side effects.<br>3. Migrate pure mathematical analysis functions. |
| `load-adaptive-iir/src/load_shedding.py` | `source/src/load_adaptive_iir/runtime/shedding.py` | Runtime Shedding | `{shedding_hash}` | 1. Shedding policy logic to be decoupled from synthetic load generation.<br>2. Re-anchor to measured telemetry in Chunk 05. |
| `load-adaptive-iir/src/visualize.py` | `source/src/load_adaptive_iir/reporting/figures.py` | Reporting | `{visualize_hash}` | 1. Remove hardcoded paths and legacy result plotting.<br>2. Refactor as pure artifact-consuming plotting utility in Chunk 11. |

---

## 2. Test Suite Staging Matrix

| Legacy Test Path | Proposed Categorised Destination | Test Class | Migration Notes |
|---|---|---|---|
| `load-adaptive-iir/tests/test_filters.py` | `source/tests/unit/test_filters.py` | Unit | Update imports; retain deterministic filter response checks. |
| `load-adaptive-iir/tests/test_numba_equivalence.py` | `source/tests/unit/test_numba_equivalence.py` | Unit | Guard with numba import check. |
| `load-adaptive-iir/tests/test_filter_stability.py` | `source/tests/semantic/test_filter_stability.py` | Semantic | Retain analytical pole & impulse bounds. |
| `load-adaptive-iir/tests/test_shedding.py` | `source/tests/unit/test_shedding.py` | Unit | Retain record dropping logic tests. |
| `load-adaptive-iir/tests/test_zdomain.py` | `source/tests/semantic/test_zdomain.py` | Semantic | Retain z-transform calculations. |
| `load-adaptive-iir/tests/test_statistical_tests.py` | `source/tests/scientific/test_statistical_tests.py` | Scientific | Mark precision loss / identical-array tests with xfail pending Chunk 06 protocol. |
| `load-adaptive-iir/tests/test_bandwidth_calibration.py` | `source/tests/scientific/test_bandwidth_calibration.py` | Scientific | Remove network download dependency; mark xfail. |
| `load-adaptive-iir/tests/test_harness.py` | `source/tests/integration/test_harness.py` | Integration | Refactor to mock authentic replay. |
| `load-adaptive-iir/tests/test_detection.py` | `source/tests/scientific/test_detection.py` | Scientific | Mark xfail pending Chunk 02 real-label feasibility. |
| `load-adaptive-iir/tests/test_anomaly_injection.py` | `source/tests/scientific/test_anomaly_injection.py` | Retired / Invalid | Synthetic injection test — candidate for retirement in C01-07. |
| `load-adaptive-iir/tests/test_queue_stability_sanity.py` | `source/tests/integration/test_queue_stability.py` | Integration | Quarantine from evidence; migrate harness sanity. |
| `load-adaptive-iir/tests/test_downstream.py` | `source/tests/integration/test_downstream.py` | Integration | Pure pipeline flow checks. |
| `load-adaptive-iir/tests/test_data_pipeline.py` | `source/tests/integration/test_data_pipeline.py` | Integration | Update to reflect fail-closed transform interfaces. |
| `load-adaptive-iir/tests/test_delong.py` | `source/tests/unit/test_delong.py` | Unit | Mathematical verification of DeLong matrix algebra. |
"""

(LEGACY_INTAKE / "migration_staging.md").write_text(migration_staging_content)
print("Wrote migration_staging.md")

# 3. Write forbidden_evidence.md
forbidden_evidence_content = """# FlowGate Legacy Intake: Forbidden Evidence Inventory

**Captured Date:** 2026-09-01
**Contract ID:** C01-03
**Authority:** Invariant INV-DATA-001 (No Fabricated Empirical Evidence)

---

## 1. Strictly Forbidden Legacy Modules

The following files contain synthetic data generators, simulated backpressure mechanisms, synthetic anomaly injectors, or pseudo-replication runners. **THEY MUST NEVER BE IMPORTED BY OR MIGRATED TO `source/` OR USED TO GENERATE EVIDENCE FOR PUBLICATION.**

| Forbidden Legacy File | Primary Violation | Reason for Absolute Bar |
|---|---|---|
| `load-adaptive-iir/src/demo_signals.py` | Synthetic Data Generation | Implements `generate_synthetic_signal` (random walks, sine-noise mixtures). INV-DATA-001 violation. |
| `load-adaptive-iir/src/anomaly_injection.py` | Synthetic Anomaly Injection | Injects artificial spikes/bursts into data streams. INV-DATA-001 violation. |
| `load-adaptive-iir/src/queue_simulator.py` | Queue/Load Simulation | Implements `simulate_backpressure` and synthetic queue dynamics. INV-DATA-001 violation. |
| `load-adaptive-iir/src/experiment_a_compute_cost.py` | Synthetic Fallback / Uncontrolled Timing | Uses synthetic fallbacks and uncalibrated timing loops. |
| `load-adaptive-iir/src/experiment_b_throughput_stability.py` | Simulated Throughput Model | Simulates arrival queues rather than measuring real OS processes. |
| `load-adaptive-iir/src/experiment_c_pareto.py` | Synthetic Anomaly Pareto Curve | Computes ROC-AUC curves over synthetically injected anomalies. |
| `load-adaptive-iir/src/fp_paradox.py` | Simulated False Positive Paradox | Simulates trade frequencies and synthetic alert distributions. |
| `load-adaptive-iir/src/multi_seed_evaluation.py` | Pseudo-Replication Runner | Re-evaluates identical data with 150 random seeds and claims N=150 independent trials. |
| `load-adaptive-iir/src/run_all.py` | Monolithic Demo Runner | Orchestrates execution of all synthetic experiment scripts and overwrites results. |

---

## 2. Forbidden Legacy Result Artifacts

All files located in `load-adaptive-iir/results/` (including all subdirectories: `plots/`, `tables/`, `runs/`) are classified as `forbidden-evidence`.

- **Total legacy result files:** 42 files
- **Violations:**
  - Contradictory metric values across `paired_ttest_results.csv`, `delong_results.csv`, and markdown summaries.
  - Metrics computed over generated/simulated signals.
  - Non-standard ROC-AUC calculations and statistical cancellation warnings.
- **Enforcement:**
  - Tracked in `project/legacy_intake/results_manifest/` for historical provenance.
  - Barred from entering `key_facts.md`, `source/artifacts/release/`, or publication manuscripts.
"""

(LEGACY_INTAKE / "forbidden_evidence.md").write_text(forbidden_evidence_content)
print("Wrote forbidden_evidence.md")

# 4. Inventory legacy results in results_manifest/
res_manifest_dir = LEGACY_INTAKE / "results_manifest"
res_manifest_dir.mkdir(parents=True, exist_ok=True)

legacy_res_dir = REPO_ROOT / "load-adaptive-iir" / "results"
res_files = []
if legacy_res_dir.exists():
    for root, dirs, files in os.walk(legacy_res_dir):
        for f in files:
            fp = Path(root) / f
            rel = fp.relative_to(REPO_ROOT)
            res_files.append((str(rel), fp.stat().st_size, sha256_file(fp)))

res_manifest_content = """# FlowGate Legacy Intake: Results Manifest

**Captured Date:** 2026-09-01
**Contract ID:** C01-03
**Classification:** `LEGACY — NON-AUTHORITATIVE / FORBIDDEN EVIDENCE`

---

## Inventory of Legacy Results

| Path | Size (Bytes) | SHA-256 Hash | Status |
|---|---|---|---|
"""
for rpath, rsize, rhash in sorted(res_files):
    res_manifest_content += f"| `{rpath}` | {rsize} | `{rhash}` | `forbidden-evidence` |\n"

(res_manifest_dir / "legacy_results_manifest.md").write_text(res_manifest_content)
print("Wrote results_manifest/legacy_results_manifest.md")
