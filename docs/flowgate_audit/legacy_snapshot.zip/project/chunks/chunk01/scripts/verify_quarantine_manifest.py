#!/usr/bin/env python3
"""
Verification Script for Contract C01-03: Legacy Quarantine and Disposition
Verifies:
1. All required C01-03 artifacts exist and are non-empty.
2. Every quarantined file in quarantine_index.md exists and matches recorded SHA-256 hash.
3. Every file in quarantine_index.md is labeled LEGACY — NON-AUTHORITATIVE.
4. Forbidden evidence files are listed and none are staged for migration in migration_staging.md.
5. Staged migration files exist and hashes match source.
6. Legacy results manifest accounts for all results/ files.
7. Zero legacy files deleted from working tree.
"""

import os
import sys
import hashlib
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[4]
PROJECT_DIR = REPO_ROOT / "project"
LEGACY_INTAKE = PROJECT_DIR / "legacy_intake"

REQUIRED_ARTIFACTS = [
    LEGACY_INTAKE / "quarantine_index.md",
    LEGACY_INTAKE / "migration_staging.md",
    LEGACY_INTAKE / "forbidden_evidence.md",
    LEGACY_INTAKE / "results_manifest" / "legacy_results_manifest.md",
]

FORBIDDEN_FILES = [
    "load-adaptive-iir/src/demo_signals.py",
    "load-adaptive-iir/src/anomaly_injection.py",
    "load-adaptive-iir/src/queue_simulator.py",
    "load-adaptive-iir/src/experiment_a_compute_cost.py",
    "load-adaptive-iir/src/experiment_b_throughput_stability.py",
    "load-adaptive-iir/src/experiment_c_pareto.py",
    "load-adaptive-iir/src/fp_paradox.py",
    "load-adaptive-iir/src/multi_seed_evaluation.py",
    "load-adaptive-iir/src/run_all.py",
]

def sha256_file(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def main():
    print("Running C01-03 Verification: Legacy Quarantine & Disposition Integrity...")
    failures = []

    # 1. Check required artifacts
    print("\n[1/6] Checking required output artifacts...")
    for art in REQUIRED_ARTIFACTS:
        if not art.exists() or art.stat().st_size == 0:
            failures.append(f"Missing or empty artifact: {art.relative_to(REPO_ROOT)}")
        else:
            print(f"  OK: {art.relative_to(REPO_ROOT)} ({art.stat().st_size} bytes)")

    # 2. Check quarantined files hashes
    print("\n[2/6] Verifying quarantined copies and SHA-256 hashes...")
    qindex_path = LEGACY_INTAKE / "quarantine_index.md"
    content = qindex_path.read_text(encoding="utf-8")
    
    # Parse markdown table
    lines = [l.strip() for l in content.splitlines() if l.strip().startswith("| `")]
    print(f"  Found {len(lines)} quarantined file entries in quarantine_index.md")
    
    for line in lines:
        parts = [p.strip() for p in line.split("|")[1:-1]]
        if len(parts) < 7:
            continue
        orig_rel = parts[0].strip("`")
        qpath_cell = parts[1]
        # extract relative link
        qpath_rel = qpath_cell.split("`")[1] if "`" in qpath_cell else ""
        expected_hash = parts[4].strip("`")
        authority = parts[5].strip("`")
        
        # Check file exists in quarantine
        qfile_path = REPO_ROOT / qpath_rel
        if not qfile_path.exists():
            failures.append(f"Quarantined file missing on disk: {qpath_rel}")
            continue
            
        actual_hash = sha256_file(qfile_path)
        if actual_hash != expected_hash:
            failures.append(f"Hash mismatch for {qpath_rel}: expected {expected_hash}, got {actual_hash}")
        else:
            print(f"  Verified hash OK: {qpath_rel}")
            
        # Check authority label
        if "LEGACY — NON-AUTHORITATIVE" not in authority:
            failures.append(f"Missing non-authoritative label for {qpath_rel}: {authority}")

    # 3. Check forbidden evidence vs migration staging
    print("\n[3/6] Verifying forbidden evidence quarantine...")
    staging_content = (LEGACY_INTAKE / "migration_staging.md").read_text(encoding="utf-8")
    for ff in FORBIDDEN_FILES:
        if ff in staging_content:
            failures.append(f"CRITICAL VIOLATION: Forbidden file staged for migration: {ff}")
        else:
            print(f"  OK: Forbidden file barred from migration staging: {ff}")

    # 4. Check migration staging source files exist and hashes match
    print("\n[4/6] Verifying staged migration candidates...")
    staged_sources = [
        "load-adaptive-iir/src/filters.py",
        "load-adaptive-iir/src/numba_filters.py",
        "load-adaptive-iir/src/zdomain_analysis.py",
        "load-adaptive-iir/src/load_shedding.py",
        "load-adaptive-iir/src/visualize.py"
    ]
    for ss in staged_sources:
        p = REPO_ROOT / ss
        if not p.exists():
            failures.append(f"Staged source candidate missing: {ss}")
        else:
            h = sha256_file(p)
            if h not in staging_content:
                failures.append(f"Hash mismatch in staging document for {ss}")
            else:
                print(f"  Staged candidate verified: {ss} ({h[:8]}...)")

    # 5. Check results manifest
    print("\n[5/6] Verifying legacy results manifest...")
    res_manifest = (LEGACY_INTAKE / "results_manifest" / "legacy_results_manifest.md").read_text(encoding="utf-8")
    res_lines = [l for l in res_manifest.splitlines() if l.strip().startswith("| `")]
    print(f"  Legacy results inventoried: {len(res_lines)} files")
    if len(res_lines) < 20:
        failures.append(f"Results manifest count ({len(res_lines)}) suspiciously low")

    # 6. Check that original legacy files remain preserved (no deletion)
    print("\n[6/6] Verifying zero original files were deleted...")
    for line in lines:
        parts = [p.strip() for p in line.split("|")[1:-1]]
        orig_rel = parts[0].strip("`")
        if not (REPO_ROOT / orig_rel).exists():
            failures.append(f"Original legacy file missing (improper deletion): {orig_rel}")
            
    print("\n" + "=" * 60)
    if failures:
        print("VERIFICATION FAILED:")
        for f in failures:
            print(f"  - {f}")
        sys.exit(1)
    else:
        print("VERIFICATION PASSED: All C01-03 quarantine and disposition checks satisfied.")
        sys.exit(0)

if __name__ == "__main__":
    main()
