# Contract Report — C01-03

## Contract Information
- **Contract ID:** C01-03
- **Chunk ID:** chunk01
- **Objective (quoted verbatim):** "Separate what informs rehabilitation from what is allowed to ship. Apply the disposition matrix from the rehabilitation plan to every legacy file, preserving useful audit material in `project/legacy_intake/` while staging reusable code for migration in C01-04. No file is deleted; no legacy result enters the authoritative surface."
- **Risk Tier:** High
- **Scientific Claim Tier:** NONE
- **Implementation Owner:** Architect
- **Model Identifier:** Antigravity / Gemini 3.7 Flash

## Scope / Inputs / Outputs

### Scope:
Execution of the legacy quarantine and file-by-file disposition matrix. Preservation of audit documents, literature, legacy manuscripts, and notes in `project/legacy_intake/`. Generation of the quarantine index with exact SHA-256 matches, staging of reusable core source and tests for C01-04 migration, cataloguing of forbidden evidence modules, and verification that no legacy files were deleted from the working tree.

### Inputs:
- Asset Ledger (`project/legacy_intake/asset_ledger.csv`) from C01-01
- Rehabilitation plan §10 disposition matrix
- Current working tree (all legacy documents, tools, manuscripts, and results)

### Outputs:
1. `project/legacy_intake/quarantine_index.md` (4.2 KB) — Hash-backed index of all 11 preserved legacy files across 8 categories with `LEGACY — NON-AUTHORITATIVE` labels.
2. `project/legacy_intake/tools/build_mega_context.py` (3.3 KB) — Quarantined historical context tool.
3. `project/legacy_intake/requirements/dsp_project_build_prompt.md` (23.1 KB) & `legacy_requirements.txt` (90 B) — Quarantined specifications.
4. `project/legacy_intake/notes/fix1.md` (16.0 KB) — Quarantined historical fix notes.
5. `project/legacy_intake/documents/` (`mega_report_context.md`, `project_context.md`, `legacy_README.md`) — Quarantined legacy narrative and README documents.
6. `project/legacy_intake/reviews/study.md` (52.7 KB) — Quarantined adversarial analysis.
7. `project/legacy_intake/literature/load_adaptive_iir_literature_review.md` (21.3 KB) — Quarantined literature summary.
8. `project/legacy_intake/manuscripts/report_v2.tex` (46.8 KB) — Quarantined legacy IEEE draft.
9. `project/legacy_intake/venue_inputs/ku_format.md` (38.7 KB) — Quarantined formatting notes.
10. `project/legacy_intake/migration_staging.md` (4.8 KB) — Approved migration targets and defect directives for C01-04.
11. `project/legacy_intake/forbidden_evidence.md` (2.7 KB) — Comprehensive bar on synthetic generators, simulators, and result files.
12. `project/legacy_intake/results_manifest/legacy_results_manifest.md` (7.4 KB) — Provenance inventory of 43 legacy result files.
13. `project/chunks/chunk01/scripts/verify_quarantine_manifest.py` — Automated verification script.

## Files Modified
| File | Purpose | Reason Modified | Major Changes |
|---|---|---|---|
| `project/legacy_intake/quarantine_index.md` | Quarantine Index | Contract Deliverable | Indexed 11 quarantined files with SHA-256 & non-authoritative labels |
| `project/legacy_intake/migration_staging.md` | Migration Staging | Contract Deliverable | Staged 5 core modules and 14 tests for C01-04 with defect tags |
| `project/legacy_intake/forbidden_evidence.md` | Forbidden Evidence | Contract Deliverable | Catalogued 9 forbidden modules and 43 forbidden results |
| `project/legacy_intake/results_manifest/legacy_results_manifest.md` | Results Manifest | Contract Deliverable | Hashed and inventoried 43 legacy result files |
| `project/legacy_intake/tools/*` | Quarantine Directory | Contract Deliverable | Preserved historical context builder |
| `project/legacy_intake/requirements/*` | Quarantine Directory | Contract Deliverable | Preserved historical build prompt & requirements |
| `project/legacy_intake/notes/*` | Quarantine Directory | Contract Deliverable | Preserved legacy fix notes |
| `project/legacy_intake/documents/*` | Quarantine Directory | Contract Deliverable | Preserved mega context, project context, and README |
| `project/legacy_intake/reviews/*` | Quarantine Directory | Contract Deliverable | Preserved study.md |
| `project/legacy_intake/literature/*` | Quarantine Directory | Contract Deliverable | Preserved literature review |
| `project/legacy_intake/manuscripts/*` | Quarantine Directory | Contract Deliverable | Preserved report_v2.tex |
| `project/legacy_intake/venue_inputs/*` | Quarantine Directory | Contract Deliverable | Preserved ku_format.md |
| `project/chunks/chunk01/scripts/verify_quarantine_manifest.py` | Verification Script | Contract Verification | Reconciled quarantine hashes and invariants |

## Verification Summary

### Script 1: `python3 project/chunks/chunk01/scripts/verify_quarantine_manifest.py`
```text
Running C01-03 Verification: Legacy Quarantine & Disposition Integrity...

[1/6] Checking required output artifacts...
  OK: project/legacy_intake/quarantine_index.md (4205 bytes)
  OK: project/legacy_intake/migration_staging.md (4826 bytes)
  OK: project/legacy_intake/forbidden_evidence.md (2701 bytes)
  OK: project/legacy_intake/results_manifest/legacy_results_manifest.md (7375 bytes)

[2/6] Verifying quarantined copies and SHA-256 hashes...
  Found 11 quarantined file entries in quarantine_index.md
  Verified hash OK: project/legacy_intake/tools/build_mega_context.py
  Verified hash OK: project/legacy_intake/requirements/dsp_project_build_prompt.md
  Verified hash OK: project/legacy_intake/notes/fix1.md
  Verified hash OK: project/legacy_intake/documents/mega_report_context.md
  Verified hash OK: project/legacy_intake/documents/project_context.md
  Verified hash OK: project/legacy_intake/reviews/study.md
  Verified hash OK: project/legacy_intake/literature/load_adaptive_iir_literature_review.md
  Verified hash OK: project/legacy_intake/manuscripts/report_v2.tex
  Verified hash OK: project/legacy_intake/venue_inputs/ku_format.md
  Verified hash OK: project/legacy_intake/documents/legacy_README.md
  Verified hash OK: project/legacy_intake/requirements/legacy_requirements.txt

[3/6] Verifying forbidden evidence quarantine...
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/demo_signals.py
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/anomaly_injection.py
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/queue_simulator.py
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/experiment_a_compute_cost.py
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/experiment_b_throughput_stability.py
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/experiment_c_pareto.py
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/fp_paradox.py
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/multi_seed_evaluation.py
  OK: Forbidden file barred from migration staging: load-adaptive-iir/src/run_all.py

[4/6] Verifying staged migration candidates...
  Staged candidate verified: load-adaptive-iir/src/filters.py (2afa89b2...)
  Staged candidate verified: load-adaptive-iir/src/numba_filters.py (8e45a70f...)
  Staged candidate verified: load-adaptive-iir/src/zdomain_analysis.py (4dc438df...)
  Staged candidate verified: load-adaptive-iir/src/load_shedding.py (b56f34a8...)
  Staged candidate verified: load-adaptive-iir/src/visualize.py (1792bd8a...)

[5/6] Verifying legacy results manifest...
  Legacy results inventoried: 43 files

[6/6] Verifying zero original files were deleted...

============================================================
VERIFICATION PASSED: All C01-03 quarantine and disposition checks satisfied.
```
**Result:** PASS

## Definition of Done
1. **Quarantine index complete — every moved file hashed and verified**: Satisfied (11 files preserved and SHA-256 verified).
2. **Migration staging list created — every file proposed for C01-04 with destination and known defects**: Satisfied (`migration_staging.md` explicitly lists destinations and defect directives).
3. **Forbidden-evidence list explicit — files that must never enter authoritative surface**: Satisfied (`forbidden_evidence.md` details 9 code modules and 43 result files).
4. **No original file deleted**: Satisfied (all working tree source and legacy files remain intact).
5. **No legacy result labelled authoritative**: Satisfied (all result files tagged `forbidden-evidence` / `LEGACY — NON-AUTHORITATIVE`).
6. **All Human decisions resolved or explicitly pending**: Satisfied.
7. **Contract report submitted**: Satisfied.

## Invariant Status
- **INV-DATA-001 (No Fabricated Evidence):** Upheld. Synthetic generators, backpressure simulators, and result files quarantined and permanently barred from authoritative migration.
- **INV-HIST-001 (Legacy Material Quarantine):** Upheld. Quarantined copies are clearly indexed and labeled `LEGACY — NON-AUTHORITATIVE`.
- **INV-CLAIM-001 (Claim-Ledger Governance):** Upheld. Legacy result metrics barred from entering key facts or claim ledger.

## Predicted Failure Modes
- **Missing Human decision for ambiguous file:** Checked and resolved. Decisions 1, 2, and 3 from C01-01 confirmed and executed.
- **Hash mismatch after copy:** Checked. All 11 files verified with bit-for-bit SHA-256 equality.
- **Mixed authentic/generated result:** Quarantined as a whole in `results_manifest/`.
- **File unreadable/locked:** All files successfully read and verified.

## Self Review History
- **Attempt 1:** All quarantine artifacts generated, verified, and reconciled with 100% pass rate.

## Final Status
`COMPLETE`

## Remaining Risks
- The Implementor must strictly follow `migration_staging.md` in C01-04 and mark all noted semantic defects with comments rather than attempting premature fixes.

## Repository State
- Quarantined legacy assets and indices committed to nested `project/` repository.
- Outer working tree files remain preserved.

## Plain-Language Summary
Contract C01-03 successfully implemented the full legacy quarantine. Eleven historical planning, review, prompt, and manuscript documents have been preserved with verified SHA-256 checksums in `project/legacy_intake/` and labeled non-authoritative. A clear migration staging list was established for C01-04 with known defect directives, and all synthetic generator scripts and legacy result tables were permanently categorized as forbidden evidence.
