# Contract Report — C01-01

## Contract Information
- **Contract ID:** C01-01
- **Chunk ID:** chunk01
- **Objective (quoted verbatim):** "Create a trustworthy, lossless description of the repository's starting state so that later cleanup cannot erase user work or turn legacy outputs into unexplained artefacts. This is the forensic baseline for the entire rehabilitation."
- **Risk Tier:** Medium
- **Scientific Claim Tier:** T-DESC
- **Implementation Owner:** Implementor
- **Model Identifier:** Antigravity / Gemini 3.7 Flash

## Scope / Inputs / Outputs

### Scope:
Forensic intake and inventory of legacy repository state. Comprehensive classification of all tracked, modified, deleted, and untracked files, generation of text diffs for all modified files, test baseline record, Gatekeeper audit baseline, secret/path scan, and explicit human decision requests.

### Inputs:
- Current working tree (125 tracked files, 17 modified/deleted files, 155 raw ZIP archives, processed Parquet files, legacy directories)
- Git history and branch status (`git status`, `git log`, `git ls-files`, `git diff`)
- Legacy test suite in `load-adaptive-iir/tests/`
- Factory v2.2.0 audit machinery (`gatekeeper.py self-check`, `acquisition-audit`, `lint-contract`)

### Outputs:
1. `project/legacy_intake/worktree_snapshot.md` (26.9 KB) — Full Git status, branch, HEAD commit, recent commits, directory-level size breakdown.
2. `project/legacy_intake/asset_ledger.csv` (39.3 KB, 136 rows) — Comprehensive asset ledger mapping every tracked file and grouped untracked asset to its type, hash strategy, SHA-256 hash, authority, and proposed disposition.
3. `project/legacy_intake/diffs/` (17 diff files + README.md) — Exact text diffs for all 17 modified/deleted tracked files.
4. `project/legacy_intake/test_baseline.md` (3.1 KB) — Test baseline capturing 97 tests collected, 96 passed, 1 failed (offline sandbox network block), and 5 exact scipy.stats catastrophic cancellation warnings.
5. `project/legacy_intake/factory_audit_baseline.md` (4.3 KB) — Audit baseline recording Gatekeeper self-check (0 drift, 9 heuristic warnings), acquisition-audit (2 data-generation failures, 7 warnings), and lint-contract (9 swallowed exception failures).
6. `project/legacy_intake/secret_scan.md` (5.5 KB) — Secret and path scan confirming zero exposed API keys/tokens, with local machine path references catalogued for sanitisation.
7. `project/legacy_intake/human_decisions_required.md` (2.3 KB) — Staged decisions on deleted notebook (`01_full_pipeline.ipynb`), modified experiment files, and untracked analysis documents.
8. `project/chunks/chunk01/scripts/verify_ledger_counts.py` — Verification script for asset ledger and intake integrity.

## Files Modified
| File | Purpose | Reason Modified | Major Changes |
|---|---|---|---|
| `project/legacy_intake/worktree_snapshot.md` | Worktree Snapshot | Contract Deliverable | Captured full Git metadata and directory sizes |
| `project/legacy_intake/asset_ledger.csv` | Asset Ledger | Contract Deliverable | 136 asset rows with hashes, dispositions, and authority |
| `project/legacy_intake/diffs/*` | Diffs Directory | Contract Deliverable | 17 text diffs and index table for modified files |
| `project/legacy_intake/test_baseline.md` | Test Baseline | Contract Deliverable | Documented test counts, failure cause, and warnings |
| `project/legacy_intake/factory_audit_baseline.md` | Factory Audit | Contract Deliverable | Documented Gatekeeper self-check, acquisition-audit, and lint |
| `project/legacy_intake/secret_scan.md` | Secret Scan | Contract Deliverable | Catalogued secrets and path leaks across repository |
| `project/legacy_intake/human_decisions_required.md` | Human Decisions | Contract Deliverable | Formulated explicit requests for ambiguous files |
| `project/chunks/chunk01/scripts/inventory.py` | Inventory Script | Automation Script | Generates snapshot, diffs, and ledger |
| `project/chunks/chunk01/scripts/build_intake_artifacts.py` | Artifact Builder | Automation Script | Generates baseline and audit intake documents |
| `project/chunks/chunk01/scripts/verify_ledger_counts.py` | Verification Script | Contract Verification | Reconciles ledger with Git and filesystem |

## Verification Summary

### Script 1: `python3 project/chunks/chunk01/scripts/verify_ledger_counts.py`
```text
Running C01-01 Verification: Asset Ledger & Intake Integrity...

[1/5] Checking required output artifacts...
  OK: project/legacy_intake/worktree_snapshot.md (26939 bytes)
  OK: project/legacy_intake/asset_ledger.csv (39319 bytes)
  OK: project/legacy_intake/diffs/README.md (3714 bytes)
  OK: project/legacy_intake/test_baseline.md (3058 bytes)
  OK: project/legacy_intake/factory_audit_baseline.md (4322 bytes)
  OK: project/legacy_intake/secret_scan.md (5534 bytes)
  OK: project/legacy_intake/human_decisions_required.md (2347 bytes)

[2/5] Validating asset_ledger.csv structure and rows...
  Total ledger rows: 136

[3/5] Reconciling Git tracked files against ledger...
  All 125 tracked files accounted for in ledger.

[4/5] Checking diff coverage for modified/deleted files...
  Modified/deleted paths: 17, Generated diff files: 17
  All 17 modified/deleted files have diff artifacts.

[5/5] Checking that no frozen files were modified...
  Read-only verification passed.

============================================================
VERIFICATION PASSED: All C01-01 integrity checks satisfied.
```
**Result:** PASS

## Definition of Done
1. **All 7 output artefacts exist in `project/legacy_intake/` and `project/chunks/chunk01/reports/C01-01/`**: Satisfied (all verified present and non-empty).
2. **Ledger covers every meaningful path; aggregate counts reconcile with Git/filesystem**: Satisfied (136 rows in `asset_ledger.csv`, covering all 125 tracked files and all untracked groups).
3. **No existing file was modified, deleted, or moved**: Satisfied (all operations were strictly read-only against legacy files).
4. **Human decision requests are explicit and complete**: Satisfied (detailed in `human_decisions_required.md`).
5. **Secret scan completed with no uncontained findings**: Satisfied (zero active secrets/keys found).
6. **Contract report submitted**: Satisfied.

## Invariant Status
- **INV-HIST-001 (Legacy Material Quarantine):** Preserved. All legacy files catalogued, hashed, and tagged `LEGACY — NON-AUTHORITATIVE` or `forbidden-evidence` in `asset_ledger.csv`.
- **INV-SEC-001 (No Secrets in Release):** Preserved. Secret scan executed across entire tree; no secrets exposed in reports.

## Predicted Failure Modes
- **Hash/read failure on large files:** Prevented. Large data directories hashed using `sha256-first-1mb` sample strategy.
- **Secret discovered:** Checked. No active API keys or credentials discovered.
- **Cannot distinguish user work from generated output:** Handled. Marked ambiguous items as `pending-human-decision` in `human_decisions_required.md`.
- **Path count mismatch:** Prevented and verified by `verify_ledger_counts.py`.

## Self Review History
- **Attempt 1:** All intake artifacts generated, verified, and reconciled with 100% pass rate.

## Final Status
`COMPLETE`

## Remaining Risks
- The sandbox environment cannot perform live internet downloads to Binance; this confirms the absolute necessity of Chunk 03's authentic acquisition and Reality Gate.
- Global Python 3.12 environment currently has NumPy 2.5 which conflicts with unpinned Numba in legacy tree; resolved in C01-04/C01-07 by pinned dependencies and isolated builds.

## Repository State
- Clean working tree under `project/` with all forensic intake artifacts in place.
- Outer repository working tree remains unchanged and preserved.

## Plain-Language Summary
Contract C01-01 successfully established a forensic baseline and complete asset ledger for the FlowGate repository. All 125 tracked files, 17 modified/deleted files, and large data archives are fully accounted for, hashed, and categorized without modifying any legacy files. Audit baselines, test behavior, and human decision requests are documented and ready for quarantine in C01-03.
