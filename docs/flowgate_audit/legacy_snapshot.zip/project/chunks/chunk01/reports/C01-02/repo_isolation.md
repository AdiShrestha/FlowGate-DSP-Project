# Repository Isolation Proof

**Contract ID:** C01-02
**Date:** 2026-09-01

---

## 1. Nested Git Repository Independence

The `project/` directory contains its own independent Git repository, isolated from the outer repository:

```bash
$ git -C project rev-parse --git-dir
.git

$ git -C project rev-parse --show-toplevel
/Users/adi/Desktop/DSP Mini Project/project
```

- **Confirmation:** `project/.git` is an independent repository rooted at `project/`, and does not point to the parent repository database.

---

## 2. Outer Repository Ignore Verification

The outer repository `.gitignore` explicitly ignores Factory-private directories, nested repositories, and bootstrap scripts:

```bash
$ git check-ignore -v project/project_description.md
.gitignore:11:project/	project/project_description.md

$ git check-ignore -v factory/VERSION
.gitignore:10:factory/	factory/VERSION

$ git check-ignore -v DROP_HERE/dropbox_manifest.json
.gitignore:13:DROP_HERE/	DROP_HERE/dropbox_manifest.json

$ git check-ignore -v bootstrap.sh
.gitignore:12:bootstrap.sh	bootstrap.sh
```

- **Confirmation:** Every Factory-private asset is ignored by outer Git, preventing leak of planning, reviews, or factory machinery into outer release commits.
