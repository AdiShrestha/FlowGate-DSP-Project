# Invariants

Status: Frozen File. Created at Project Initialization. Amended only via Architecture Amendment.

---

## Data Integrity

### INV-DATA-001 — No Fabricated Empirical Evidence

**Description:** No publication result, calibration value, benchmark, demonstration presented as evidence, or manuscript conclusion may be derived from generated random walks, generated sine/noise mixtures, injected anomalies, simulated queue depth/backpressure, bootstrapped pseudo-observations, duplicated real observations presented as independent, arbitrary self-referential labels, fallback datasets after authentic-source failure, placeholder results carried forward, or hand-edited values.

**Reason:** The legacy repository's central scientific defect is contamination of evidence by synthetic/simulated data presented as authentic research results. This invariant is the firewall.

**Verification method:**
- Static non-fabrication audit (`gatekeeper.py acquisition-audit`) on all authoritative source — zero hard failures
- Prohibited-terminology gate scanning authoritative Python, JS/TS, shell, notebooks, and manuscript scripts
- Import-boundary test proving `source/` does not import legacy generators
- Release-boundary test proving experiment/report commands cannot load test fixtures
- Negative tests for every prohibited fallback/substitution path

**Failure impact:** CRITICAL — any violation invalidates all downstream evidence. Contract fails immediately; no workaround permitted.

---

### INV-DATA-002 — Fail-Closed External Dependencies

**Description:** External-source failure (network unavailability, checksum mismatch, schema mismatch, missing archive, partial decompression) produces a typed `BlockedExternalDependency` failure state mapped to `BLOCKED — HUMAN ACTION REQUIRED`. It never produces a synthetic substitute, a partial success, or a swallowed exception that allows downstream processing to continue.

**Reason:** Silent substitution is the mechanism by which fabricated data enters the pipeline undetected.

**Verification method:**
- Typed outcome returns from all acquisition/validation functions
- Negative tests for every failure mode (unavailable network, missing archive, checksum mismatch, missing day, schema mismatch, partial decompression, duplicate-identity conflict)
- `lint-contract` zero hard failures for swallowed exceptions in evidence paths

**Failure impact:** CRITICAL — downstream experiments use unverified or fabricated input.

---

## Provenance

### INV-PROV-001 — Input Provenance Chain

**Description:** Every input file used in evidence is traceable to: source URL, acquisition event (timestamp, HTTP status, byte count), expected official checksum, observed checksum, raw schema, and transformation (code version, config hash, exclusion reasons, input/output hashes, row-count accounting).

**Reason:** A checksum of a fabricated file does not make the content authentic. Provenance requires evidence of the acquisition event itself.

**Verification method:**
- `acquisition_provenance.json` and `data_manifest.json` schemas validated
- Reality Gate checks (source/authenticity, schema/properties, coverage, provenance)
- Human spot-checks against official URLs/checksums

**Failure impact:** HIGH — unprovenanced data cannot pass Reality Gate; experiments blocked.

---

### INV-PROV-002 — Output Provenance Chain

**Description:** Every reported value is traceable to: unique run ID, input manifest, code commit (clean), config hash, environment lock hash, and raw metric artifact path/hash.

**Reason:** A result disconnected from its inputs and code is not reproducible.

**Verification method:**
- Run manifest schema validation (minimum fields per §14.1 of rehabilitation plan)
- `evidence-check` command verifying manifest completeness
- Independent recomputation from sealed raw artifacts

**Failure impact:** HIGH — unprovenanced results cannot enter the claim ledger.

---

## Timebase

### INV-TIME-001 — Explicit Timebase Declaration

**Description:** Every analysis declares whether its discrete index represents event count or physical time. Physical frequency claims (Hz, seconds, Nyquist) require a valid, documented physical sampling model. `fs=1` or `fs=100` without domain justification is invalid.

**Reason:** Irregular trade arrivals have no inherent fixed sample rate. Applying fixed-rate DSP concepts requires an explicit aggregation or time-aware coefficient strategy.

**Verification method:**
- Code review + test that no filter/analysis path uses a hardcoded arbitrary `fs`
- Timebase declaration in all experiment configurations
- Chunk 04 semantic tests enforce chosen strategy

**Failure impact:** HIGH — frequency/time claims are meaningless without a valid timebase.

---

## Evaluation

### INV-EVAL-001 — Temporal Partition Non-Overlap

**Description:** Calibration, training, and hyperparameter-tuning intervals never overlap with the evaluation (test) interval. Cross-validation, if used, must respect time ordering and grouped experimental units.

**Reason:** Overlap causes optimistic evaluation through information leakage.

**Verification method:**
- Protocol code rejects configurations with overlapping interval definitions
- Scientific tests verify partition boundaries
- Chunk 06 protocol freeze includes explicit interval specifications

**Failure impact:** HIGH — evaluation results are unreliable; comparative claims invalidated.

---

### INV-EVAL-002 — Experimental Unit Integrity

**Description:** Experimental units and their dependencies are explicitly defined before execution. Each unit has a globally unique ID. Duplicated real observations, resampled rows, or multiple random seeds applied to the same input are never counted as independent experimental units.

**Reason:** Pseudo-replication inflates apparent sample size and deflates variance estimates, making non-significant effects appear significant.

**Verification method:**
- Unit-ID uniqueness and completeness checks in run manifests
- Pairing-key validation (dataset_version / asset / date / interval / replay_factor / repetition_block)
- Statistical model specification includes repeated-measures structure

**Failure impact:** HIGH — statistical conclusions are invalid; sample-size claims are fraudulent.

---

## Statistical

### INV-STAT-001 — Non-Significance ≠ Equivalence

**Description:** Failure to reject a null hypothesis of difference is never reported as evidence of equivalence or "zero quality cost." Equivalence or non-inferiority claims require a pre-specified practical margin, an appropriate statistical test or confidence-interval procedure, and adequate power analysis.

**Reason:** The legacy project treated p ≈ 0.67 as "zero quality cost." This is a fundamental statistical error.

**Verification method:**
- Claim-ledger review: any equivalence/non-inferiority claim must reference a named test and pre-specified margin
- Title/claim audit: phrases like "no quality cost" blocked without supporting equivalence test
- Multiplicity corrections applied to secondary outcomes

**Failure impact:** HIGH — publication contains a false statistical claim.

---

## Claims

### INV-CLAIM-001 — Claim-Ledger Governance

**Description:** No public claim (abstract, results, README, UI, caption, table) exists without a corresponding row in the claim ledger. Each row specifies: exact approved wording, prohibited stronger wording, supporting run/artifact IDs, statistical method, point estimate with units and CI, claim tier, population scope, independent unit count, recomputation status, caveats, and status (approved/descriptive-only/exploratory/rejected/superseded).

**Reason:** Disconnecting claims from evidence is how legacy narrative contradictions arose.

**Verification method:**
- `release-check` against `key_facts.md` and claim-ledger entries
- `evidence-check` for cross-contract consistency
- Manual title/claim audit at chunk review

**Failure impact:** HIGH — publication contains unsupported claims.

---

## Artefacts

### INV-ART-001 — Run Output Immutability

**Description:** Generated results are immutable per run ID. Reruns receive new unique run IDs and never overwrite existing evidence artifacts. Failed or unfavourable runs are preserved with their failure metadata.

**Reason:** Overwriting evidence destroys the audit trail and enables cherry-picking.

**Verification method:**
- Run-manifest schema requires unique run ID + attempt ID
- Filesystem/write-mode checks: results paths opened in write mode only with a run ID
- All attempts in run history (favourable and unfavourable)

**Failure impact:** MEDIUM — audit trail is compromised; reproducibility claim weakened.

---

## Reproducibility

### INV-REPRO-001 — Clean-Room Reproducibility

**Description:** The release reproduces from a clean clone using only tracked source plus declared authentic external artifacts. No ignored local file, untracked environment, ambient cache, or undeclared dependency may be required.

**Reason:** A result that only works inside the original 4.8 GB workspace is not independently reproducible.

**Verification method:**
- Clean-clone install and test in CI
- Reproduction script execution in a fresh temporary environment
- No imports from legacy directories or untracked paths

**Failure impact:** HIGH — release fails the reproduction gate; cannot be published.

---

## Documentation

### INV-DOC-001 — Document Consistency

**Description:** README, manuscript, tables, figures, UI labels, and machine-readable results cannot disagree on a metric value, scope statement, sample count, or claim. All public-facing numbers originate from the same verified aggregate source.

**Reason:** The legacy project has multiple contradictory result files and narrative claims.

**Verification method:**
- `release-check` against `key_facts.md`
- Figure/table generation scripts consume only verified aggregates
- Manuscript sentence generation from claim-ledger wording

**Failure impact:** MEDIUM — reviewer identifies contradictions; credibility destroyed.

---

## Security

### INV-SEC-001 — No Secrets or Personal Data in Release

**Description:** Credentials, API keys, local filesystem paths, machine identity (hostname, MAC address), email placeholders (`yourname@ku.edu.np`), and permissive development-only security settings (disabled TLS, `CORS *` with credentials) do not enter release artifacts.

**Reason:** Security and privacy baseline for any public release.

**Verification method:**
- Secret/local-path scan in CI and at release
- Release-check scans for placeholder patterns
- Clean-clone test with no environment-specific paths

**Failure impact:** MEDIUM — security vulnerability or privacy breach in public release.

---

## History

### INV-HIST-001 — Legacy Material Quarantine

**Description:** Legacy material (code, results, documents, prompts) is preserved for audit in `project/legacy_intake/` and clearly marked `LEGACY — NON-AUTHORITATIVE`. Migration history is not falsified. No legacy result enters `source/artifacts/release/` or the claim ledger without passing through the full evidence pipeline (acquisition → Reality Gate → experiment → recomputation → claim registration).

**Reason:** The purpose of rehabilitation is honest recovery, not concealment.

**Verification method:**
- `project/legacy_intake/` index with non-authoritative labels
- Import-boundary test: `source/` cannot import legacy paths
- Release tree audit: no Factory-private or legacy material in public clone

**Failure impact:** MEDIUM — legacy contamination enters the release; rehabilitation integrity compromised.
