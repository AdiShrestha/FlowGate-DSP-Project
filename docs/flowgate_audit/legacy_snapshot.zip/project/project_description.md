# Project Description

Status: Frozen File. Created at Project Initialization. Amended only via Architecture Amendment.

---

## Executive Summary

FlowGate is a controlled in-place rehabilitation of an existing DSP research project that investigates **load-driven time-varying single-pole IIR filtering under measured stream backpressure** applied to authentic financial market data streams. The project begins from a legacy codebase that contains genuine DSP implementation work mixed with fabricated evidence, simulated load, non-standard metrics, and stale publication claims. The rehabilitation's purpose is to produce a publication-ready, independently reproducible research package whose empirical evidence comes only from authentic observed data and measured runtime behaviour.

The project is **not** a greenfield implementation. It is a disciplined recovery of a useful core idea — adapting IIR filter coefficients based on actual processing-queue state — under the governance of Software Factory v2.2.0, with all legacy material preserved for audit but quarantined from the evidence pipeline.

## Motivation

Real-time streaming systems face a fundamental tension: signal-processing fidelity versus computational throughput under variable load. A fixed-coefficient IIR low-pass filter provides stable smoothing but cannot adapt to changing backpressure conditions. When queue depth grows, the system must either shed records or tolerate unbounded latency. The hypothesis is that a load-driven adaptive coefficient — one that widens the effective smoothing window under high backpressure — can provide a principled mechanism for graceful degradation, distinct from both signal-driven adaptation (e.g., KAMA) and naive load shedding.

Whether this hypothesis holds is an empirical question. The legacy project attempted to answer it but contaminated the evidence with synthetic data, simulated queues, and non-standard metrics. This rehabilitation exists to answer the question honestly, even if the answer is negative.

## Objectives

### Functional Requirements

| ID | Requirement | Priority | Verification |
|---|---|---|---|
| FR-001 | Implement fixed single-pole EMA with explicit zero-state and warm-start semantics | High | Canonical impulse/step/constant tests (Chunk 04) |
| FR-002 | Implement load-adaptive EMA with queue-depth-driven coefficient and slew-rate limiting | High | Canonical tests + load-trace response tests (Chunk 04) |
| FR-003 | Implement KAMA baseline with correct first-update and efficiency-ratio warm-up | High | Canonical tests + reference parity (Chunk 04) |
| FR-004 | Implement at least one conventional baseline (e.g., Butterworth) with fair comparison parameterisation | Medium | Canonical tests + order/cutoff matching rationale (Chunk 04) |
| FR-005 | Acquire authentic Binance aggregate trade data with provenance, checksums, and fail-closed error handling | High | Reality Gate (Chunk 03) |
| FR-006 | Transform raw data to analysis-ready form with full record accounting and deterministic reproducibility | High | Row-count balance + content-addressed outputs (Chunk 03) |
| FR-007 | Implement bounded-queue replay pipeline with actual execution telemetry | High | Real queue-depth/lag measurement + open-loop replay (Chunk 05) |
| FR-008 | Implement pre-registered evaluation protocol with temporal partitioning and correct experimental units | High | Protocol freeze + leakage checks (Chunk 06) |
| FR-009 | Produce independently recomputable results with immutable run manifests | High | Independent recomputation agreement (Chunk 09) |
| FR-010 | Generate manuscript and report from verified claim-ledger entries only | High | Claim/document consistency check (Chunk 11) |

### Non-Functional Requirements

| ID | Requirement | Verification |
|---|---|---|
| NFR-001 | Clean-room reproducibility: build, test, and reproduce from a clean clone with locked dependencies | CI + clean-clone test (Chunk 07/12) |
| NFR-002 | No fabricated evidence in any authoritative path | Static non-fabrication audit (continuous) |
| NFR-003 | Fail-closed error handling: no broad `except: pass/continue` in evidence paths | Lint-contract + negative tests (Chunk 01) |
| NFR-004 | Evidence immutability: run outputs are write-once per run ID | Run-manifest schema enforcement (Chunk 05+) |
| NFR-005 | Publication-quality documentation: README, reproduction guide, data-rights statement | Release check (Chunk 12) |

### Research Objectives

| ID | Question | Tier | Contingency |
|---|---|---|---|
| RQ1 | Under an explicit timebase, how do fixed and load-driven single-pole filters differ in smoothing, delay, and response on authentic observations? | T-DESC | Always answerable with authentic data |
| RQ2 | In a real bounded streaming implementation, how do adaptation and load-shedding policies affect queue stability, latency, throughput, CPU time, peak memory, and record retention? | T-COMP | Requires measured telemetry (Chunk 05) |
| RQ3 | Does any measured runtime benefit remain within a predeclared fidelity margin on a downstream task? | T-COMP | Contingent on real labels or independently defined outcome (Chunk 02 gate) |
| RQ4 | Which component — coefficient adaptation, shedding, or interaction — explains any observed change? | T-CAUSAL | Requires ≥3 baselines + ablations (Chunk 06) |

## Scope

### Included

- Single-pole IIR (first-order) filter variants: fixed EMA, load-adaptive EMA, KAMA
- At least one conventional baseline (Butterworth or equivalent, with fair parameterisation)
- Authentic Binance public aggregate trade data (January 2024, 5 symbols)
- Measured runtime behaviour using bounded-queue replay on actual processes
- Pre-registered evaluation and statistical analysis protocol
- KU project report as primary deliverable
- Journal of Institute of Science and Technology (JIST) as target venue

### Excluded from current scope

- Higher-order adaptive filter designs
- Multi-market or multi-exchange data
- Real-time production deployment
- Anomaly detection claims (contingent on Chunk 02 label-feasibility gate)
- Web application / dashboard (deferred to optional Chunk 10)
- Live data streaming (all evidence uses historical replay)

### Future extension points (post-release)

- Extension to multi-pole adaptive filters
- Cross-market generalisation study
- Production-grade streaming deployment with live telemetry
- Web-based historical replay visualisation (if Chunk 10 proceeds)

## Constraints

| ID | Constraint | Source |
|---|---|---|
| CON-001 | Software Factory v2.2.0 governance throughout | Rehabilitation plan §1 |
| CON-002 | No fabricated empirical evidence (invariant INV-DATA-001) | Constitution + rehabilitation plan §3.1 |
| CON-003 | Fail-closed external dependencies (invariant INV-DATA-002) | Rehabilitation plan §3.3 |
| CON-004 | Claims follow evidence, never the reverse (invariant INV-CLAIM-001) | Rehabilitation plan §3.4 |
| CON-005 | JIST formatting: 4,000–7,000 words, Times New Roman, British English, A4 | Venue author guidelines |
| CON-006 | Python-based implementation; specific version and OS scope TBD in Chunk 01 | Rehabilitation plan §21 |
| CON-007 | Binance data redistribution rights require separate review | Rehabilitation plan §18.5 |

## Success Criteria

The project is complete when all of the following are satisfied:

1. **Repository:** clean tracked tree; Factory v2.2.0 operational; `source/` is sole authoritative surface; legacy quarantined.
2. **Data integrity:** every empirical byte is authentic-source traceable; Reality Gate PASS for release dataset; no synthetic/simulated/injected contributions.
3. **DSP correctness:** timebase explicit; reference and optimised implementations agree; statistical metrics match independent calculations.
4. **Experimental validity:** protocol frozen before final results; experimental units correct; independent recomputation agrees; negative/null outcomes reported honestly.
5. **Publication integrity:** every claim has a verified claim-ledger row; title/abstract within evidence ceiling; no placeholders, local paths, or secrets.
6. **Release:** clean-clone reproduction works; large artifacts archived with persistent identifiers where permitted; Factory certification passes.

Until all criteria are met, the following phrases are prohibited: "100% complete," "publication-ready," "zero quality cost," "real-time live anomaly detection," "Factory-certified."
