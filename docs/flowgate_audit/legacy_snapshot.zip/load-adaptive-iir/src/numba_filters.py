"""
numba_filters.py — Numba-JIT-compiled IIR filter kernels.

All four filters (Fixed EMA, Load-Adaptive EMA, KAMA, Butterworth) are routed
through these kernels so every timing comparison in Experiments A/B is
apples-to-apples (no compiled-C vs Python-loop confound).

Warm-up is performed at module import time so JIT compilation latency is never
counted as algorithmic cost in any timed region.
"""

import numpy as np
from numba import njit


# ---------------------------------------------------------------------------
# Kernel 1: Fixed-coefficient Direct Form II Transposed IIR
# ---------------------------------------------------------------------------

@njit(cache=True)
def fixed_iir_direct_form_ii(
    x: np.ndarray, b: np.ndarray, a: np.ndarray, z0: np.ndarray
) -> np.ndarray:
    """
    Generic fixed-coefficient Direct Form II Transposed IIR filter.

    Matches scipy.signal.lfilter's algorithm exactly (a[0] assumed 1.0;
    normalise b, a by a[0] before calling if necessary).

    Used for: Butterworth (any order), and as a validation path for Fixed EMA.

    Parameters
    ----------
    x  : 1-D float64 array   Input signal.
    b  : 1-D float64 array   Numerator coefficients.
    a  : 1-D float64 array   Denominator coefficients (a[0] == 1.0).
    z0 : 1-D float64 array   Initial delay-line state, length = max(len(a), len(b)) - 1.
                              Pass np.zeros(order) for filters where cold-start doesn't
                              matter.  For Butterworth, compute via scipy.signal.lfilter_zi
                              scaled to the first sample (see butterworth_lowpass in
                              filters.py) to eliminate the start-up transient.

    Returns
    -------
    y : 1-D float64 array   Filtered output, same length as x.
    """
    order = max(len(a), len(b)) - 1
    # Copy z0 so we don't mutate the caller's array
    z = z0.copy()
    y = np.empty(len(x))

    # Zero-pad to length order+1
    b_pad = np.zeros(order + 1)
    a_pad = np.zeros(order + 1)
    for i in range(len(b)):
        b_pad[i] = b[i]
    for i in range(len(a)):
        a_pad[i] = a[i]

    for n in range(len(x)):
        y[n] = b_pad[0] * x[n] + (z[0] if order > 0 else 0.0)
        for i in range(order - 1):
            z[i] = b_pad[i + 1] * x[n] + z[i + 1] - a_pad[i + 1] * y[n]
        if order > 0:
            z[order - 1] = b_pad[order] * x[n] - a_pad[order] * y[n]

    return y


# ---------------------------------------------------------------------------
# Kernel 2: Time-varying first-order EMA
# ---------------------------------------------------------------------------

@njit(cache=True)
def time_varying_first_order_ema(x: np.ndarray, alpha_trace: np.ndarray) -> np.ndarray:
    """
    First-order IIR with a per-sample, precomputed alpha[n].

    Used for: Fixed EMA (constant alpha_trace), KAMA (sc_trajectory as alpha),
    and Load-Adaptive EMA (slew-rate-limited alpha_trace).

    Only the unavoidable recursive accumulation runs inside the njit loop;
    all vectorisable coefficient computation is done outside before calling.

    Parameters
    ----------
    x           : 1-D float64 array   Input signal.
    alpha_trace : 1-D float64 array   Per-sample smoothing factor, same length as x.

    Returns
    -------
    y : 1-D float64 array   Filtered output, same length as x.
    """
    n = len(x)
    y = np.empty(n)
    y[0] = x[0]
    for i in range(1, n):
        a = alpha_trace[i]
        y[i] = a * x[i] + (1.0 - a) * y[i - 1]
    return y


# ---------------------------------------------------------------------------
# Kernel 3: Load-Adaptive EMA alpha computation (slew-rate-limited)
# ---------------------------------------------------------------------------

@njit(cache=True)
def compute_load_adaptive_alpha(
    L: np.ndarray,
    alpha_min: float,
    alpha_max: float,
    d_alpha_max: float,
) -> np.ndarray:
    """
    Compute the slew-rate-limited alpha trace for load_adaptive_ema.

    This is the unavoidable sequential dependency (alpha[n] depends on
    alpha[n-1]), so it must run inside a JIT loop — vectorising it would
    change the math.

    Parameters
    ----------
    L           : 1-D float64 array   Normalised backpressure in [0, 1].
    alpha_min   : float               Minimum smoothing factor.
    alpha_max   : float               Maximum smoothing factor.
    d_alpha_max : float               Maximum per-step change in alpha.

    Returns
    -------
    alpha : 1-D float64 array   Per-sample alpha values.
    """
    n = len(L)
    alpha = np.empty(n)

    a_init = alpha_max - (alpha_max - alpha_min) * L[0]
    # clip to [1e-4, 1-1e-4]
    a_init = max(1e-4, min(1.0 - 1e-4, a_init))
    alpha[0] = a_init

    for i in range(1, n):
        target_a = alpha_max - (alpha_max - alpha_min) * L[i]
        diff = target_a - alpha[i - 1]
        # slew-rate clamp
        if diff > d_alpha_max:
            diff = d_alpha_max
        elif diff < -d_alpha_max:
            diff = -d_alpha_max
        a = alpha[i - 1] + diff
        # clip
        if a < 1e-4:
            a = 1e-4
        elif a > 1.0 - 1e-4:
            a = 1.0 - 1e-4
        alpha[i] = a

    return alpha


# ---------------------------------------------------------------------------
# Kernel 4: Load Shedding deterministic stride mask
# ---------------------------------------------------------------------------

@njit(cache=True)
def compute_processing_mask_kernel(L: np.ndarray, shed_max_skip: int) -> np.ndarray:
    """
    JIT-compiled loop for compute_processing_mask.
    """
    n = len(L)
    process = np.zeros(n, dtype=np.bool_)
    ticks_since_processed = shed_max_skip

    for i in range(n):
        target_skip = int(np.round(shed_max_skip * L[i]))
        if ticks_since_processed >= target_skip:
            process[i] = True
            ticks_since_processed = 0
        else:
            ticks_since_processed += 1

    return process


# ---------------------------------------------------------------------------
# Kernel 5: KAMA efficiency ratio and SC trajectory
# ---------------------------------------------------------------------------

@njit(cache=True)
def compute_kama_sc(x: np.ndarray, er_period: int, fastSC: float, slowSC: float) -> np.ndarray:
    """
    JIT-compiled loop for Kaufman's Adaptive Moving Average SC trajectory computation.
    """
    n_samples = len(x)
    sc_trajectory = np.zeros(n_samples)
    sc_trajectory[:er_period] = slowSC

    change = np.zeros(n_samples)
    for i in range(1, n_samples):
        change[i] = abs(x[i] - x[i - 1])

    for n in range(er_period, n_samples):
        dir_change = abs(x[n] - x[n - er_period])
        
        volatility = 0.0
        for i in range(n - er_period + 1, n + 1):
            volatility += change[i]

        er = dir_change / volatility if volatility != 0.0 else 0.0
        sc = (er * (fastSC - slowSC) + slowSC) ** 2
        sc_trajectory[n] = sc

    return sc_trajectory


@njit(cache=True)
def apply_shedding_forward_fill_y(process_mask: np.ndarray, y_sub: np.ndarray, first_x: float) -> np.ndarray:
    """
    JIT-compiled forward-fill for shedding. Scatter processed values into
    the full-length array and forward-fill the gaps.
    """
    n = len(process_mask)
    y = np.empty(n, dtype=np.float64)
    last_val = first_x
    sub_idx = 0
    for i in range(n):
        if process_mask[i]:
            last_val = y_sub[sub_idx]
            sub_idx += 1
        y[i] = last_val
    return y


# ---------------------------------------------------------------------------
# Module-level warm-up — runs once at import time so JIT compile cost is
# never inside a timed region.
# ---------------------------------------------------------------------------

def _warmup():
    _dummy = np.ones(16, dtype=np.float64)
    _b = np.array([0.5, 0.5], dtype=np.float64)
    _a = np.array([1.0, -0.5], dtype=np.float64)
    # fixed_iir_direct_form_ii now requires an explicit z0 initial-state array.
    # Pass zeros here — warmup only needs to trigger JIT compilation.
    _order = max(len(_a), len(_b)) - 1
    _z0 = np.zeros(_order, dtype=np.float64)
    fixed_iir_direct_form_ii(_dummy, _b, _a, _z0)

    time_varying_first_order_ema(_dummy, _dummy)

    _L = np.full(16, 0.5, dtype=np.float64)
    compute_load_adaptive_alpha(_L, 0.02, 0.30, 0.01)

    _mask = compute_processing_mask_kernel(_L, 4)
    compute_kama_sc(_dummy, 10, 0.2, 0.01)
    apply_shedding_forward_fill_y(_mask, _dummy[:len(np.where(_mask)[0])], 0.0)


_warmup()
